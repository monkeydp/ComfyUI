﻿import os
from swlutils.ipc import retrieve_json, comm_manager_available, CommManager
from swlutils.exception import capture_exception

from swlpatches.warnings import patch_warnings
from swlpatches.well_known_mimetypes import anchor_mimetypes

ee_opts_id = os.getenv("SITE_ENHANCED_EXPERIENCE_OPTS")
# depth = int(os.getenv("EE_DEPTH_REF", "0"))
fork_type = None

ee_opts = None
if ee_opts_id:
    ee_opts = retrieve_json(ee_opts_id)
    fork_type = ee_opts["fork_type"]

patch_warnings()
anchor_mimetypes()

if ee_opts_id:
    import sys
    from swlutils.a1111scripts import install as script_handler_install
    from swlpatches.extension_index import patch_extension_index_a1111, patch_extension_index_comfyui_manager
    from swlpatches.automatic1111.cloud_localization import patch_cloud_localization_legacy as patch_cloud_localization_a1111_legacy, patch_cloud_localization_modern as patch_cloud_localization_a1111_modern
    from swlpatches.torch_save_encoding import patch_torch_save_encoding
    from swlpatches.managed_settings import patch_managed_settings
    from swlpatches.automatic1111.checkpoint_verification import patch_checkpoint_verification as patch_checkpoint_verification_a1111
    from swlpatches.vladmandic.logger import patch_vladmandic_logger
    from swlpatches.clip_model_path import patch_clip_model_path
    from swlpatches.automatic1111.restart import patch_restart as patch_restart_a1111
    from swlpatches.hfmirror import apply_hf_mirror
    from swlpatches.pip_skip_requirements import patch_pip_req_file_get_file_content
    from swlpatches.hotfix import patch as patch_hotfix
    from swlpatches.automatic1111.html_resources_patcher import patch as patch_html_resources_a1111
    from swlpatches.shutil import patch_rmtree
    from swlpatches.aiohttp import patch as patch_aiohttp
    from swlpatches.zluda_companion import apply_zluda_library, apply_zluda_compat
    from swlpatches.torchvision_fallback import patch as patch_torchvision_fallback
    from swlpatches.pkg_resource_fallback import patch as patch_pkg_resource_fallback
    from swlpatches.ipex_compat import patch as patch_ipex_compat
    from swlpatches.pip_skip_packages import patch as patch_pip_skip_packages
    from swlpatches.apply_dll_search_paths import apply as apply_dll_search_paths
    from swlpatches.triton_windows_msvc import patch as patch_triton_windows_msvc

    for module in ee_opts["import_blacklist"]:
        # noinspection PyTypeChecker
        sys.modules[module] = None

    try:
        from swlutils.exception import init_sentry
        from swlpatches.sentry_error_integration import patch_sentry_error_integration

        if init_sentry(ee_opts):
            patch_sentry_error_integration(fork_type)
    except:
        if os.getenv("EE_DEBUG") == "1":
            raise
        pass

    patch_clip_model_path()
    patch_pip_req_file_get_file_content()
    patch_rmtree()
    patch_aiohttp()
    patch_torchvision_fallback()
    patch_pkg_resource_fallback()
    patch_ipex_compat()

    if ee_opts["dll_paths"] is not None:
        apply_dll_search_paths(ee_opts["dll_paths"])

    if ee_opts['zluda'] is not None:
        if ee_opts['zluda']['compat']:
            apply_zluda_compat()
        if ee_opts['zluda']['path']:
            apply_zluda_library(ee_opts['zluda']['path'])

    fix_torch_save_encoding_mode = ee_opts['fix_torch_save_encoding']
    if fix_torch_save_encoding_mode > 0:
        patch_torch_save_encoding(fix_torch_save_encoding_mode)

    if 'hf_mirror' in ee_opts:
        hf_mirror_spec = ee_opts['hf_mirror']
        if hf_mirror_spec is not None:
            apply_hf_mirror(hf_mirror_spec)

    if 'fork_type' in ee_opts and fork_type in ['automatic1111', 'vladmandic', 'forge']:
        patch_html_resources_a1111()
        script_handler_install()

        if 'extension_index_url' in ee_opts:
            extension_index_url = ee_opts['extension_index_url']
            if extension_index_url is not None:
                patch_extension_index_a1111(extension_index_url)

        if 'use_cloud_localization' in ee_opts:
            USE_CLOUD_LOCALIZATION = ee_opts['use_cloud_localization']
            if USE_CLOUD_LOCALIZATION == 1:
                patch_cloud_localization_a1111_legacy()
            elif USE_CLOUD_LOCALIZATION == 2:
                patch_cloud_localization_a1111_modern(fork_type)

        if 'managed_settings' in ee_opts and ee_opts['managed_settings'] is not None:
            patch_managed_settings(ee_opts["managed_settings"])

        patch_checkpoint_verification_a1111()

        if fork_type == 'vladmandic':
            patch_vladmandic_logger()

        patch_restart_a1111()

    if fork_type in ['comfyui']:
        from swlpatches.comfyui.html_resources_patcher import patch as patch_html_resources_comfyui
        from swlpatches.comfyui.cloud_localization import patch as patch_cloud_localization_comfyui
        from swlpatches.comfyui.extensions import patch as patch_extensions

        patch_html_resources_comfyui()

        USE_CLOUD_LOCALIZATION = ee_opts['use_cloud_localization']
        if USE_CLOUD_LOCALIZATION == 2:
            patch_cloud_localization_comfyui()

        if 'extension_index_url' in ee_opts and ee_opts['extension_index_url'] is not None:
            patch_extension_index_comfyui_manager()

        patch_extensions()

    if 'enabled_hotfixes' in ee_opts and len(ee_opts['enabled_hotfixes']) > 0:
        patch_hotfix(ee_opts['enabled_hotfixes'])

    patch_pip_skip_packages(
        ee_opts["pip_skip_packages"],
        ee_opts["pip_replace_packages"],
        ee_opts["pip_replace_packages_pre"],
        ee_opts["pip_remove_packages_extra"],
    )
    
    patch_triton_windows_msvc()

if comm_manager_available():
    from swlutils.progressbar import ProgressBarManager, Progress
    from swlutils.webbrowser import WebBrowser
    from swlpatches.webbrowser import patch_webbrowser
    from swlpatches.progress import patch_progress_packages
    from swlutils.fileoperation import FileOperation
    from swlutils.faulthandler import install_faulthandler

    try:
        with CommManager() as comm_manager:
            progress_manager = ProgressBarManager.from_comm_manager(comm_manager)
            if progress_manager is not None:
                Progress.manager = progress_manager
                patch_progress_packages(progress_manager, fork_type)
            managed_browser = WebBrowser.from_comm_manager(comm_manager)
            if managed_browser is not None:
                patch_webbrowser(managed_browser)
            FileOperation.attach_comm_manager(comm_manager)
            install_faulthandler(comm_manager)
            if ee_opts is not None and ee_opts.get('audit_filter', None) is not None and len(ee_opts['audit_filter']) > 0:
                from swlpatches.audit import setup_audit
                setup_audit(comm_manager, ee_opts['audit_filter'])
    except Exception:
        capture_exception()
