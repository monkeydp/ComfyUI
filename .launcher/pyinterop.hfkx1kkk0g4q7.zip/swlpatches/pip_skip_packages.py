import logging
from itertools import product
from functools import wraps
from swlutils.hook import monkey_zoo
from swlutils.exception import capture_exception


def spec_has_intersection(this, other):
    try:
        from pip._vendor.packaging.version import Version
        op1, version1 = this._canonical_spec
        op2, version2 = other._canonical_spec
        pversion1, pversion2 = Version(version1), Version(version2)
        if op1 == op2:
            if op1 in ["<=", "<", ">=", ">", "!="]:
                return True
            elif op1 in ["==", "===", "~="]:
                return this._get_operator(op1)(pversion2, version1)
            elif op1 == "~=":
                return this._get_operator("==")(pversion2, version1)
        else:
            if op1 == "<":
                if op2 in [">", "==", ">=", "~=", "==="]:
                    return this._get_operator("<")(pversion2, version1)
                elif op2 in ["<=", "!="]:
                    return True
            elif op1 == "<=":
                if op2 in ["==", ">=", "~=", "==="]:
                    return this._get_operator(">=")(pversion2, version1)
                elif op2 == ">":
                    return this._get_operator(">")(pversion2, version1)
                elif op2 in ["<", "!="]:
                    return True
            elif op1 == ">":
                if op2 in ["==", "<=", "~=", "==="]:
                    return this._get_operator("<")(pversion2, version1)
                elif op2 in [">=", "!="]:
                    return True
            elif op1 == ">=":
                if op2 in ["==", "<", "~=", "==="]:
                    return this._get_operator("<=")(pversion2, version1)
                elif op2 == "<":
                    return this._get_operator("<")(pversion2, version1)
                elif op2 in [">", "!="]:
                    return True
            elif op1 == "!=":
                if op2 in ["==", "==="]:
                    return this._get_operator("!=")(pversion2, version1)
                return True
            elif op1 in ["==", "~=", "==="]:
                return this._get_operator(op2)(pversion1, version2)    
        raise ValueError(f"Unsupported version comparison: {this} and {other}")
    except Exception:
        capture_exception()
    return None


def test_specset(this_spec, target_spec):
    if this_spec is None:
        return True
    from pip._vendor.packaging.specifiers import SpecifierSet
    target_spec = SpecifierSet(target_spec)
    for ts, rs in product(
        this_spec._specs,
        target_spec._specs
    ):
        if not spec_has_intersection(ts, rs):
            return False
    return True


def match_constraint(constraints, name, spec):
    for constraint in constraints:
        if name.casefold() == constraint['name'].casefold():
            if constraint["spec"] is None:
                if constraint["type"] == 0:
                    return True
                elif constraint["type"] == 1:
                    return False
            spec_test_result = test_specset(spec, constraint['spec'])
            if spec_test_result is not None:
                if constraint["type"] == 0:
                    return spec_test_result
                elif constraint["type"] == 1:
                    return not spec_test_result
    return False


def match_replace_packages(replace_packages, name):
    if replace_packages is None:
        return None
    for prename, postname in replace_packages.items():
        if name.casefold() == prename.casefold():
            return postname
    return None

def match_replace_packages_pre(replace_packages, name):
    if replace_packages is None:
        return None
    
    parts = name.split(';')
    name = parts[0]
    name = ''.join(name.split())

    for prename, postname in replace_packages.items():
        if name.casefold() == prename.casefold():
            if len(parts) > 1:
                return f"{postname} ; {parts[1]}"
            return postname
    return None


def patch(skip_packages, replace_packages, replace_packages_pre, removes_extra):
    with monkey_zoo("pip._internal.req.req_set") as monkey:
        def patch_add_named_requirement(module):
            if 'RequirementSet' not in module.__dict__:
                capture_exception(KeyError("RequirementSet not found in req_set"))
                return
            if module.RequirementSet.__dict__.get('add_named_requirement') is None:
                capture_exception(KeyError("add_named_requirement not found in RequirementSet"))
                return

            old_add_named_requirement = module.RequirementSet.__dict__.get('add_named_requirement')

            @wraps(old_add_named_requirement)
            def new_add_named_requirement(self, install_req):
                if skip_packages is not None and match_constraint(skip_packages, install_req.name, install_req.specifier):
                    print(f"Skipping package {install_req.name} due to policy constraint")
                    return
                return old_add_named_requirement(self, install_req)

            setattr(module.RequirementSet, 'add_named_requirement', new_add_named_requirement)
        monkey.patch_module(patch_add_named_requirement)

    with monkey_zoo("pip._vendor.resolvelib.resolvers") as monkey:
        def patch_resolution(module):
            if 'Resolution' not in module.__dict__:
                capture_exception(KeyError("Resolution not found in resolvers"))
                return

            logger = logging.getLogger("pip._internal.operations.prepare")

            if module.Resolution.__dict__.get("_add_to_criteria") is not None:
                old_add_to_criteria = module.Resolution.__dict__.get("_add_to_criteria")

                module.logged_skip_packages = set()

                @wraps(old_add_to_criteria)
                def new_add_to_criteria(self, criteria, requirement, *args, **kwargs):
                    spec = getattr(requirement, "_ireq", None)
                    spec = getattr(spec, "specifier", None) if spec is not None else None

                    if skip_packages is not None and match_constraint(skip_packages, requirement.project_name, spec):
                        if (
                            requirement.project_name.casefold()
                            not in module.logged_skip_packages
                        ):
                            module.logged_skip_packages.add(requirement.project_name.casefold())
                            logger.info(
                                "Requirement %s: %s", "skipped by policy constraint", requirement
                            )
                        return
                    return old_add_to_criteria(
                        self, criteria, requirement, *args, **kwargs
                    )

                setattr(module.Resolution, "_add_to_criteria", new_add_to_criteria)
            elif module.Resolution.__dict__.get("_merge_into_criterion") is not None:
                # hard to patch
                pass
            else:
                capture_exception(KeyError("add_to_criteria or merge_into_criterion not found in Resolution"))
                return

        monkey.patch_module(patch_resolution)

    with monkey_zoo("pip._vendor.packaging.requirements") as monkey:
        def patch_requirement_init(module):
            if 'Requirement' not in module.__dict__:
                capture_exception(KeyError("Requirement not found in requirements"))
                return

            replace_log_cache = set()

            old_init = module.Requirement.__dict__.get('__init__')
            @wraps(old_init)
            def new_init(self, requirement_string, *args, **kwargs):
                nonlocal replace_log_cache
                
                replace_pre_name = match_replace_packages_pre(replace_packages_pre, requirement_string)
                if replace_pre_name is not None:
                    if requirement_string not in replace_log_cache:
                        print(f"Replacing package {requirement_string} with {replace_pre_name}")
                        replace_log_cache.add(requirement_string)
                    requirement_string = replace_pre_name
                    
                result = old_init(self, requirement_string, *args, **kwargs)
                
                replace_name = match_replace_packages(replace_packages, self.name)
                if replace_name is not None:
                    if self.name not in replace_log_cache:
                        print(f"Replacing package {self.name} with {replace_name}")
                        replace_log_cache.add(self.name)
                    self.name = replace_name
                    
                if self.name is not None and self.name.casefold() in removes_extra:
                    to_remove_extra = set()
                    case_insensitive_extras = {e.casefold(): e for e in self.extras}
                    
                    removes_extra_list = removes_extra[self.name]
                
                    for item in removes_extra_list:
                        if item.casefold() in case_insensitive_extras:
                            to_remove_extra.add(case_insensitive_extras[item.casefold()])

                    for item in to_remove_extra:
                        if f"{self.name}[{item}]" not in replace_log_cache:
                            print(f"Removing extra {item} from package {self.name}")
                            replace_log_cache.add(f"{self.name}[{item}]")
                        self.extras.remove(item)

                return result

            setattr(module.Requirement, '__init__', new_init)
        monkey.patch_module(patch_requirement_init)
