﻿import functools
import sys
from swlutils.hook import register_hook


def patch_rich_progress(manager):
    def _hooked_progress(orig, module):
        class ProgressSwl(orig):
            def __init__(self, *args, **kwargs):
                kwargs['auto_refresh'] = False
                super(ProgressSwl, self).__init__(*args, **kwargs)
                self.swl_task_sp_cache = dict()

            def __del__(self, *_, **__):
                self.stop()

            def start(self, *_, **__):
                pass

            def stop(self, *_, **__):
                with self._lock:
                    for task in self.tasks:
                        clsid = id(task)
                        try:
                            manager.remove_progress(clsid)
                        except:
                            pass

            def remove_task(self, task_id, *args, **kwargs):
                with self._lock:
                    try:
                        clsid = id(self._tasks[task_id])
                        manager.remove_progress(clsid)
                        del self.swl_task_sp_cache[clsid]
                    except:
                        pass
                super(ProgressSwl, self).remove_task(task_id, *args, **kwargs)

            def update(self, *args, **kwargs):
                kwargs['refresh'] = True
                return super(ProgressSwl, self).update(*args, **kwargs)

            def refresh(self, *_, **__):
                from rich.text import Text
                from rich.progress import BarColumn
                with self._lock:
                    for task in self.tasks:
                        clsid = id(task)
                        if clsid in self.swl_task_sp_cache:
                            sp = self.swl_task_sp_cache[clsid]
                        else:
                            sp = (None, 0, 0, 0, 0)

                        visible = task.visible
                        indeterminate = task.total is None
                        max_step = task.total or 0

                        ltext = ""
                        rtext = ""
                        left = True

                        for col in list(self.columns):
                            if isinstance(col, str):
                                if left:
                                    ltext += col + ' '
                                else:
                                    rtext += ' ' + col
                            elif isinstance(col, BarColumn):
                                left = False
                            else:
                                rendered = col.render(task)
                                if isinstance(rendered, str):
                                    if left:
                                        ltext += rendered + ' '
                                    else:
                                        rtext += ' ' + rendered
                                elif isinstance(rendered, Text):
                                    if left:
                                        ltext += rendered.plain + ' '
                                    else:
                                        rtext += ' ' + rendered.plain

                        try:
                            if sp[0] != visible:
                                if visible:
                                    manager.set_progress(clsid, indeterminate, max_step, '')
                                else:
                                    manager.remove_progress(clsid)
                            if sp[1] != hash((indeterminate, max_step)):
                                manager.set_progress(clsid, indeterminate, max_step, '')
                            if sp[2] != task.completed:
                                manager.set_progress_value(clsid, task.completed)
                            if sp[3] != hash(ltext):
                                manager.set_left_text(clsid, ltext)
                            if sp[4] != hash(rtext):
                                manager.set_right_text(clsid, rtext)
                            self.swl_task_sp_cache[clsid] = (visible, hash((indeterminate, max_step)),
                                                             task.completed, hash(ltext), hash(rtext))
                        except:
                            pass

        return ProgressSwl

    register_hook('rich.progress', 'Progress', _hooked_progress)


# noinspection PyProtectedMember
def patch_rich_progress_pip_vendored(manager):
    def _hooked_progress(orig, module):
        class ProgressSwl(orig):
            def __init__(self, *args, **kwargs):
                kwargs['auto_refresh'] = False
                super(ProgressSwl, self).__init__(*args, **kwargs)
                self.swl_task_sp_cache = dict()

            def __del__(self, *_, **__):
                self.stop()

            def start(self, *_, **__):
                pass

            def stop(self, *_, **__):
                with self._lock:
                    for task in self.tasks:
                        clsid = id(task)
                        try:
                            manager.remove_progress(clsid)
                        except:
                            pass

            def remove_task(self, task_id, *args, **kwargs):
                with self._lock:
                    try:
                        clsid = id(self._tasks[task_id])
                        manager.remove_progress(clsid)
                        del self.swl_task_sp_cache[clsid]
                    except:
                        pass
                super(ProgressSwl, self).remove_task(task_id, *args, **kwargs)

            def update(self, *args, **kwargs):
                kwargs['refresh'] = True
                return super(ProgressSwl, self).update(*args, **kwargs)

            def refresh(self, *_, **__):
                from pip._vendor.rich.text import Text
                from pip._vendor.rich.progress import BarColumn
                with self._lock:
                    for task in self.tasks:
                        clsid = id(task)
                        if clsid in self.swl_task_sp_cache:
                            sp = self.swl_task_sp_cache[clsid]
                        else:
                            sp = (None, 0, 0, 0, 0)

                        visible = task.visible
                        indeterminate = task.total is None
                        max_step = task.total or 0

                        ltext = ""
                        rtext = ""
                        left = True

                        for col in list(self.columns):
                            if isinstance(col, str):
                                if left:
                                    ltext += col + ' '
                                else:
                                    rtext += ' ' + col
                            elif isinstance(col, BarColumn):
                                left = False
                            else:
                                rendered = col.render(task)
                                if isinstance(rendered, str):
                                    if left:
                                        ltext += rendered + ' '
                                    else:
                                        rtext += ' ' + rendered
                                elif isinstance(rendered, Text):
                                    if left:
                                        ltext += rendered.plain + ' '
                                    else:
                                        rtext += ' ' + rendered.plain

                        try:
                            if sp[0] != visible:
                                if visible:
                                    manager.set_progress(clsid, indeterminate, max_step, '')
                                else:
                                    manager.remove_progress(clsid)
                            if sp[1] != hash((indeterminate, max_step)):
                                manager.set_progress(clsid, indeterminate, max_step, '')
                            if sp[2] != task.completed:
                                manager.set_progress_value(clsid, task.completed)
                            if sp[3] != hash(ltext):
                                manager.set_left_text(clsid, ltext)
                            if sp[4] != hash(rtext):
                                manager.set_right_text(clsid, rtext)
                            self.swl_task_sp_cache[clsid] = (visible, hash((indeterminate, max_step)),
                                                             task.completed, hash(ltext), hash(rtext))
                        except:
                            pass

        return ProgressSwl

    register_hook('pip._vendor.rich.progress', 'Progress', _hooked_progress)
