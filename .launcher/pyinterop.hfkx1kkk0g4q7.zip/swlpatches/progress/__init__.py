from swlutils.progressbar import ProgressBarManager
from .launch import patch_extension_installer, patch_run_pip
from .timer import patch_timer
from .tqdm import patch_tqdm
from .rich import patch_rich_progress, patch_rich_progress_pip_vendored


def patch_progress_packages(progress_manager, fork_type):
    try:
        patch_tqdm(progress_manager)
        patch_rich_progress(progress_manager)
        patch_rich_progress_pip_vendored(progress_manager)

        if fork_type in ['vladmandic', 'automatic1111']:
            patch_timer(progress_manager)
            patch_extension_installer(progress_manager)
            patch_run_pip(progress_manager)
    except:
        pass
