﻿import functools
from os.path import relpath

from swlutils.hook import register_hook

def patch_extension_installer(manager = None):
    if manager is None:
        return
    try:
        def _hooked_extension_installer(func, module):
            @functools.wraps(func)
            def wrapped_extension_installer(extension_dir, *args, **kwargs):
                clsid = id(extension_dir)
                try:
                    from modules.paths_internal import extensions_dir
                    reldir = relpath(extension_dir, extensions_dir)
                    desc = u'\u6B63\u5728\u5B89\u88C5\u6269\u5C55\u4F9D\u8D56'
                    manager.set_progress(clsid, True, 0, desc)
                    manager.set_left_text(clsid, reldir)
                except:
                    pass
                try:
                    return func(extension_dir, *args, **kwargs)
                finally:
                    try:
                        manager.remove_progress(clsid)
                    except:
                        pass
            return wrapped_extension_installer
        register_hook('modules.launch_utils', 'run_extension_installer', _hooked_extension_installer)
    except:
        pass

def patch_run_pip(manager = None):
    if manager is None:
        return
    try:
        def _hooked_run_pip(func, module):
            @functools.wraps(func)
            def wrapped_run_pip(command, *args, **kwargs):
                clsid = id(command)
                try:
                    desc = u'\u6B63\u5728\u8FD0\u884C pip'
                    manager.set_progress(clsid, True, 0, desc)
                    manager.set_left_text(clsid, command)
                except:
                    pass
                try:
                    return func(command, *args, **kwargs)
                finally:
                    try:
                        manager.remove_progress(clsid)
                    except:
                        pass
            return wrapped_run_pip
        register_hook('modules.launch_utils', 'run_pip', _hooked_run_pip)
    except:
        pass