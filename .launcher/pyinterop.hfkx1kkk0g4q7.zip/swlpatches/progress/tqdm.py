import re
import sys
from swlutils.hook import register_hook


def stripchar(s, substr):
    if s.startswith(substr):
        s = s[len(substr):]
    if s.endswith(substr):
        s = s[:-len(substr)]
    return s


def patch_tqdm(manager):
    try:
        from tqdm.std import tqdm as std_tqdm
        class tqdm_swl(std_tqdm):
            def __init__(self, *args, **kwargs):
                kwargs = kwargs.copy()
                kwargs['gui'] = True
                kwargs['disable'] = bool(kwargs.get('disable', False))
                super(tqdm_swl, self).__init__(*args, **kwargs)

                if self.disable:
                    return
                if not self.disable:
                    self.display(check_delay=False)
                self.sp_hash = 0

            def close(self):
                if self.disable:
                    return

                self.disable = True

                try:
                    manager.remove_progress(id(self))
                except:
                    pass

                try:
                    with self.get_lock():
                        self._instances.remove(self)
                except:
                    pass

            def clear(self, *_, **__):
                pass

            def display(self, *_, **__):
                clsid = id(self)
                indeterminate = self.total is None
                desc = self.desc[:-2] if self.desc.endswith(': ') else self.desc
                bar_format = self.bar_format or "{l_bar}{bar}{r_bar}"
                format_dict = self.format_dict
                format_dict['prefix'] = ''
                bar_format = bar_format.replace('{desc}: ', '')
                bar_format_list = re.split(r'\{bar(?::.+?)?\}', bar_format, 1)
                bar_format_fallback_list = bar_format.split('|')
                if len(bar_format_list) == 2:
                    left_bar_format = bar_format_list[0]
                    right_bar_format = bar_format_list[1]
                elif '{r_bar}' in bar_format:
                    left_bar_format = bar_format.replace('{r_bar}', '')
                    right_bar_format = '{r_bar}'
                elif len(bar_format_fallback_list) >= 2:
                    left_bar_format = bar_format_fallback_list[0]
                    right_bar_format = '|'.join(bar_format_fallback_list[1:])
                else:
                    left_bar_format = bar_format
                    right_bar_format = ''
                left_bar_format = left_bar_format.strip()
                right_bar_format = right_bar_format.strip()

                left_bar_format_dict = format_dict.copy()
                left_bar_format_dict['bar_format'] = left_bar_format
                left_bar_text = self.format_meter(**left_bar_format_dict)
                left_bar_text = stripchar(left_bar_text, '|').strip()

                right_bar_format_dict = format_dict.copy()
                right_bar_format_dict['bar_format'] = right_bar_format
                right_bar_text = self.format_meter(**right_bar_format_dict)
                right_bar_text = stripchar(right_bar_text, '|').strip()

                if right_bar_text.count('[') == 1 and right_bar_text.count(']') == 1 and \
                        right_bar_text[0] == '[' and right_bar_text[-1] == ']':
                    right_bar_text = stripchar(right_bar_text, '[')
                    right_bar_text = stripchar(right_bar_text, ']')

                try:
                    new_sp_hash = hash((indeterminate, self.total, desc))
                    if new_sp_hash != self.sp_hash:
                        manager.set_progress(clsid, indeterminate, self.total, desc)
                        self.sp_hash = new_sp_hash
                    manager.set_progress_value(clsid, self.n)
                    manager.set_left_text(clsid, left_bar_text)
                    manager.set_right_text(clsid, right_bar_text)
                except:
                    pass

        def tsrange(*args, **kwargs):
            """
            A shortcut for tqdm(xrange(*args), **kwargs).
            On Python3+ range is used instead of xrange.
            """
            from tqdm.utils import _range
            return tqdm_swl(_range(*args), **kwargs)

    except:
        return

    del sys.modules['tqdm']
    del sys.modules['tqdm.std']

    def _hooked_tqdm(orig, module):
        return tqdm_swl

    def _hooked_trange(orig, module):
        return tsrange

    register_hook('tqdm', 'tqdm', _hooked_tqdm)
    register_hook('tqdm', 'trange', _hooked_trange)
    register_hook('tqdm.auto', 'tqdm', _hooked_tqdm)
    register_hook('tqdm.auto', 'trange', _hooked_trange)
