﻿import functools

from swlutils.hook import register_hook

def patch_timer(manager = None):
    if manager is None:
        return
    try:
        def _hooked_timer_handler(cls, module):
            _original_record = cls.record
            _original_summary = cls.summary
            _original_cleanup = getattr(cls, '__del__', None)

            @functools.wraps(cls.record)
            def wrapped_record(self, category, *args, **kwargs):
                clsid = id(self)
                result = _original_record(self, category, *args, **kwargs)
                try:
                    base_category = getattr(self, 'base_category', '')
                    category_name = base_category + category
                    desc = u'\u6b63\u5728\u52a0\u8f7d'
                    manager.set_progress(clsid, True, 0, desc)
                    time = self.records.get(category_name, self.records.get(category, 0))
                    prevtext = f"{category_name} - {time:.3f}s"
                    manager.set_left_text(clsid, prevtext)
                except:
                    pass
                return result

            @functools.wraps(cls.summary)
            def wrapped_summary(self, *args, **kwargs):
                result = _original_summary(self, *args, **kwargs)
                try:
                    manager.remove_progress(id(self))
                except:
                    pass
                return result

            def cleanup(self, *args, **kwargs):
                try:
                    manager.remove_progress(id(self))
                except:
                    pass
                if _original_cleanup is not None:
                    return _original_cleanup(self, *args, **kwargs)

            cls.record = wrapped_record
            cls.summary = wrapped_summary
            cls.__del__ = cleanup
            return cls
        register_hook('modules.timer', 'Timer', _hooked_timer_handler)
    except:
        pass