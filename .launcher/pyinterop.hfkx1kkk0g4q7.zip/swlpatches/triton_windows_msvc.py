﻿# patch until https://github.com/woct0rdho/triton-windows/issues/106

from os import getenv
from swlutils.hook import monkey_zoo
from functools import wraps
from pathlib import Path


def patch():
    with monkey_zoo('triton.windows_utils') as monkey:
        def wrap_find_msvc_vswhere(func, module):
            @wraps(func)
            def wrapper(*args, **kwargs):
                msvc_path = getenv('VCToolsInstallDir')
                msvc_version = getenv('VCToolsVersion')
                if msvc_path and msvc_version:
                    msvc_base_path = Path(msvc_path).parent.absolute()
                    return Path(msvc_base_path), msvc_version
                return func(*args, **kwargs)
            return wrapper

        monkey.patch_function('find_msvc_vswhere', wrap_find_msvc_vswhere)
        
        def wrap_find_winsdk_registry(func, module):
            @wraps(func)
            def wrapper(*args, **kwargs):
                winsdk_path = getenv('WindowsSdkDir')
                winsdk_version = getenv('WindowsSDKVersion')
                if winsdk_path and winsdk_version:
                    winsdk_version = winsdk_version.strip('/\\')
                    return Path(winsdk_path), winsdk_version
                return func(*args, **kwargs)
            return wrapper
    
        monkey.patch_function('find_winsdk_registry', wrap_find_winsdk_registry)
        