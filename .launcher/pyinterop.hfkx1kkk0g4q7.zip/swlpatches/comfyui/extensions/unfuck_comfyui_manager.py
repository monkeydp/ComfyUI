from swlutils.hook import monkey_zoo


def patch():
    def patch_set_preview_method(code_object):
        code_object.co_consts.replace_method_noop("set_preview_method")

    with monkey_zoo("ComfyUI-Manager") as monkey:
        monkey.patch_bytecode(patch_set_preview_method)

    with monkey_zoo('ComfyUI-Manager-main') as monkey:
        monkey.patch_bytecode(patch_set_preview_method)
