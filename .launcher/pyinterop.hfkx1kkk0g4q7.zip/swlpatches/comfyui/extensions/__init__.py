﻿from .unfuck_mixlab_init import patch as unfuck_mixlab_init
from .unfuck_comfyui_manager import patch as unfuck_comfyui_manager


def patch():
    unfuck_mixlab_init()
    unfuck_comfyui_manager()
    