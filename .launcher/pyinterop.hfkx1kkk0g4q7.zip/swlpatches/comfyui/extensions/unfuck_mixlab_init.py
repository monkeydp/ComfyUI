﻿from swlutils.resource import get_last_changed_time, open_resource_context
from swlutils.hook import monkey_zoo
from swlutils.htmlresources import appends_styles


def debloat_mixlab_init_source(source, filename):
    source = source.replace("aiohttp.ClientSession._request = ", "# aiohttp.ClientSession._request = ")
    # source = source.replace("PromptServer.start", "# PromptServer.start")
    source = source.replace("PromptServer.add_routes", "# PromptServer.add_routes")
    source = source.replace("routes = web.RouteTableDef()", "routes = PromptServer.instance.routes")
    return source

def patch():

    with monkey_zoo("comfyui-mixlab-nodes") as monkey:
        monkey.patch_sources(debloat_mixlab_init_source)

    with monkey_zoo("comfyui-mixlab-nodes-main") as monkey:
        monkey.patch_sources(debloat_mixlab_init_source)

    with open_resource_context() as ctx:
        adblocker_last_update = get_last_changed_time(ctx, "comfyui/remove-mixlab-ad.css")
        appends_styles.append(
            f'<link rel="stylesheet" type="text/css" '
            f'href="/launcher/assets/comfyui/remove-mixlab-ad.css?{adblocker_last_update}">'
        )
