﻿import functools
import os
from swlutils.hook import monkey_zoo
from swlutils.resource import open_resource_context, get_last_changed_time
from swlutils.htmlresources import prepends_scripts, appends_scripts
from swlutils.exception import capture_exception


def ui_script_patcher_factory(server):
    from aiohttp import web

    @web.middleware
    async def ui_script_patcher(request, handler):
        response = await handler(request)

        if isinstance(response, web.FileResponse):
            try:
                path = os.path.relpath(response._path, server.web_root)
                if path == 'scripts\\ui.js':
                    new_response = web.StreamResponse(status=response.status)
                    new_response.content_type = 'application/javascript; charset=utf-8'
                    new_response.headers.extend(response.headers)
                    new_response.headers['Cache-Control'] = 'no-store'
                    await new_response.prepare(request)
                    with open(response._path, 'r') as f:
                        for line in f:
                            if line == '\treturn element;\n':
                                line = '\twindow._lc_hooks&&window._lc_hooks.ui_el&&window._lc_hooks.ui_el(element);return element;\n'
                            await new_response.write(line.encode('utf-8'))
                    await new_response.write_eof()
                    return new_response
            except ValueError:
                pass
            except Exception:
                capture_exception()
        return response
    return ui_script_patcher


def patch():
    prepends_scripts.append('<link rel="dns-prefetch" href="https://langs-v2.oystermercury.top/">')
    prepends_scripts.append('<link rel="preconnect" href="https://langs-v2.oystermercury.top/" crossorigin>')
    with open_resource_context() as ctx:
        sdk_last_update = get_last_changed_time(ctx, 'tolgee-sdk.js')
        prepends_scripts.append(
            f'<script type="text/javascript" src="/launcher/assets/tolgee-sdk.js?{sdk_last_update}"></script>')
        localization_last_update = get_last_changed_time(ctx, 'comfyui/localization.js')
        appends_scripts.append(
            f'<script type="text/javascript" '
            f'src="/launcher/assets/comfyui/localization.js?{localization_last_update}"></script>')

    with monkey_zoo('server') as monkey:
        def hook_server_init(func):
            @functools.wraps(func)
            def wrapper(self, *args, **kwargs):
                result = func(self, *args, **kwargs)
                if self.app is not None:
                    self.app.middlewares.append(ui_script_patcher_factory(self))
                return result
            return wrapper

        def hook_server_module(module):
            if 'PromptServer' not in module.__dict__:
                return
            module.PromptServer.__init__ = hook_server_init(module.PromptServer.__init__)

        monkey.patch_module(hook_server_module)
