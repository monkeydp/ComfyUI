﻿from swlutils.hook import monkey_zoo
from swlutils.htmlresources import prepends_scripts, appends_scripts, prepends_styles, appends_styles
from swlutils.resource import open_resource, get_last_changed_time, open_resource_context
from swlutils.exception import capture_exception
import os
import functools
import mimetypes
import datetime


def http_resource_injector_factory(server):
    from aiohttp import web

    before_style = '\n'.join(prepends_styles) + '\n'
    after_style = '\n'.join(appends_styles) + '\n'
    before_script = '\n'.join(prepends_scripts) + '\n'
    after_script = '\n'.join(appends_scripts) + '\n'

    @web.middleware
    async def http_resource_injector(request, handler):
        nonlocal before_style, after_style, before_script, after_script
        style_injected = False
        in_style_block = False
        script_injected = False
        in_script_block = False
        response = await handler(request)

        if isinstance(response, web.FileResponse):
            try:
                path = os.path.relpath(response._path, server.web_root)
                if path == 'index.html':
                    new_response = web.StreamResponse(status=response.status)
                    new_response.content_type = 'text/html'
                    new_response.headers.extend(response.headers)
                    new_response.headers['Cache-Control'] = 'no-store'
                    await new_response.prepare(request)
                    with open(response._path, 'r') as f:
                        for line in f:
                            if not style_injected:
                                if not in_style_block and '<link rel="stylesheet" type="text/css"' in line:
                                    in_style_block = True
                                    await new_response.write(before_style.encode('utf-8'))
                                elif in_style_block and '<link rel="stylesheet" type="text/css"' not in line:
                                    in_style_block = False
                                    await new_response.write(after_style.encode('utf-8'))
                                    style_injected = True

                            if not script_injected:
                                if not in_script_block and '<script type="text/javascript"' in line:
                                    in_script_block = True
                                    await new_response.write(before_script.encode('utf-8'))
                                elif in_script_block and '<script type="text/javascript"' not in line:
                                    in_script_block = False
                                    await new_response.write(after_script.encode('utf-8'))
                                    script_injected = True

                            if len(prepends_scripts) > 0 or len(appends_scripts) > 0:
                                if line == '\t\t\tawait app.setup();\n':
                                    line = "\t\t\twindow.addEventListener('load', async () => {window.document.dispatchEvent(new Event('comfyui-app-loading'));await app.setup();window.document.dispatchEvent(new Event('comfyui-app-loaded'));});\n"

                            # if line == '\t\t<script type="module">\n':
                            #     line = '\t\t<script type="module" defer>\n'
                            await new_response.write(line.encode('utf-8'))
                    await new_response.write_eof()
                    return new_response
            except ValueError:
                pass
            except Exception:
                capture_exception()
        return response
    return http_resource_injector


def create_static_handler():
    from aiohttp.web import RouteTableDef, StreamResponse, HTTPNotFound, HTTPInternalServerError, HTTPNotModified

    routes = RouteTableDef()

    @routes.get('/launcher/assets/{url_in_archive:.*}')
    async def launcher_resource_handler(request):
        url_in_archive = request.match_info['url_in_archive']

        try:
            mime_type, _ = mimetypes.guess_type(url_in_archive)

            with open_resource_context() as ctx:
                last_updated = get_last_changed_time(ctx, url_in_archive)

                # Check If-Modified-Since header
                if 'if-modified-since' in request.headers:
                    header_date = request.headers['if-modified-since']
                    header_date = datetime.datetime.strptime(header_date, '%a, %d %b %Y %H:%M:%S GMT')
                    header_timestamp = header_date.timestamp()

                    # If the resource has not been modified since the date in the header
                    if header_timestamp - last_updated > 1:
                        raise HTTPNotModified()

                res = StreamResponse()
                res.content_type = mime_type
                res.headers['Cache-Control'] = 'no-cache'
                res.headers['Last-Modified'] = datetime.datetime.fromtimestamp(last_updated, tz=datetime.timezone.utc) \
                    .strftime('%a, %d %b %Y %H:%M:%S GMT')

                await res.prepare(request)

                with open_resource(ctx, url_in_archive) as gen:
                    while chunk := gen.read(1024 * 1024):
                        await res.write(chunk)

                await res.write_eof()

                return res

        except HTTPNotModified:
            raise
        except (KeyError, ValueError):
            capture_exception()
            raise HTTPNotFound()
        except:
            capture_exception()
            raise HTTPInternalServerError()

    return routes


def patch():
    with monkey_zoo('server') as monkey:
        def hook_server_init(func):
            @functools.wraps(func)
            def wrapper(self, *args, **kwargs):
                result = func(self, *args, **kwargs)
                if self.app is not None:
                    self.app.middlewares.append(http_resource_injector_factory(self))
                    self.app.add_routes(create_static_handler())
                return result
            return wrapper

        def hook_server_module(module):
            if 'PromptServer' not in module.__dict__:
                return
            module.PromptServer.__init__ = hook_server_init(module.PromptServer.__init__)

        monkey.patch_module(hook_server_module)
