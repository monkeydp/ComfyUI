﻿from functools import wraps
from .common import get_filename_by_sha256, extract_sha256_from_path
from swlutils.hook import monkey_zoo
import sys
import re
import ast


def try_load_safetensors(archive, framework='np'):
    # noinspection PyBroadException
    try:
        from safetensors import safe_open
        with safe_open(archive, framework):
            pass
        return True
    except:
        return False


def is_torch_archive_safetensors(archive):
    if archive.endswith('.safetensors'):
        return True
    if (archive.endswith('.pt') or archive.endswith('.pth') or archive.endswith('.ckpt')
            or archive.endswith('.bin') or archive.endswith('.pkl')):
        return False

    sha256 = extract_sha256_from_path(str(archive))
    if sha256 is not None:
        filename = get_filename_by_sha256(sha256)
        if filename is not None:
            if filename.endswith('.safetensors'):
                return True
            if (filename.endswith('.pt') or filename.endswith('.pth') or filename.endswith('.ckpt')
                    or filename.endswith('.bin') or filename.endswith('.pkl')):
                return False
            # to be changed
            return try_load_safetensors(archive)
            # archive = filename
        else:
            # not in file spec. lingering?
            return False
    # not a cache file
    return try_load_safetensors(archive)


def fix_load_state_dict():
    def is_endswith_source_patch(source, filename):
        return re.sub(r"([0-9a-zA-Z_]+)\.endswith\([\"\']\.safetensors[\"\']\)",
                      lambda x: f'swl_is_torch_archive_safetensors({x.group(1)})', source)

    with monkey_zoo('transformers.modeling_utils') as monkey:
        monkey.patch_sources(is_endswith_source_patch)
        monkey.inject_import(__name__, "is_torch_archive_safetensors",
                             "swl_is_torch_archive_safetensors")
    with monkey_zoo('transformers.modeling_tf_utils') as monkey:
        monkey.patch_sources(is_endswith_source_patch)
        monkey.inject_import(__name__, "is_torch_archive_safetensors",
                             "swl_is_torch_archive_safetensors")
    with monkey_zoo('diffusers.loaders') as monkey:
        monkey.patch_sources(is_endswith_source_patch)
        monkey.inject_import(__name__, "is_torch_archive_safetensors",
                             "swl_is_torch_archive_safetensors")
    with monkey_zoo('diffusers.pipelines.pipeline_utils') as monkey:
        monkey.patch_sources(is_endswith_source_patch)
        monkey.inject_import(__name__, "is_torch_archive_safetensors",
                             "swl_is_torch_archive_safetensors")
    with monkey_zoo('accelerate.utils.modeling') as monkey:
        monkey.patch_sources(is_endswith_source_patch)
        monkey.inject_import(__name__, "is_torch_archive_safetensors",
                             "swl_is_torch_archive_safetensors")