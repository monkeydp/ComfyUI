﻿import re
from functools import wraps
from .common import get_file, link_or_copy
from swlutils.hook import monkey_zoo
from swlutils.exception import capture_exception


def apply_mirror():
    with monkey_zoo("ComfyUI-WD14-Tagger.pysssss") as monkey:
        def download_to_file_wrapper(func, module):
            def download_to_file_wrapper_inner(url, dst, *args, **kwargs):
                match = re.fullmatch(r"^https://huggingface\.co/(.+?)/resolve/(.+?)/(.+)", url, flags=re.IGNORECASE)
                if match is None:
                    # not a hf url
                    return func(url, dst, *args, **kwargs)
                repo_id, revision, filename = match.groups()
                try:
                    # attempt to query mirror
                    mirror_spec = get_file(repo_id,
                                           filename,
                                           revision)
                    if mirror_spec is not None:
                        link_or_copy(mirror_spec, dst)
                        return
                except Exception:
                    capture_exception()
                return func(url, dst, *args, **kwargs)

            @wraps(func)
            async def download_to_file_wrapper_inner_async(url, dst, *args, **kwargs):
                import asyncio
                coro = asyncio.to_thread(download_to_file_wrapper_inner, url, dst, *args, **kwargs)
                task = asyncio.create_task(coro)
                await asyncio.sleep(0)
                await task
                return task.result()

            return download_to_file_wrapper_inner_async
        monkey.patch_function("download_to_file", download_to_file_wrapper)
