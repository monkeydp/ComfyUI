﻿import logging
from functools import wraps
from .common import get_file
from swlutils.hook import monkey_zoo
from swlutils.exception import capture_exception


def apply_mirror():
    with monkey_zoo("huggingface_hub.file_download") as monkey:
        def hf_hub_download_wrapper(func, module):
            @wraps(func)
            def hf_hub_download_wrapper_inner(repo_id, filename, *args, **kwargs):
                # skip files need authentication
                if kwargs.get("token", None) is not None:
                    # logger.info("Skipping %s due to token", filename)
                    return func(repo_id, filename, *args, **kwargs)
                # skip when there is custom endpoint
                if kwargs.get("endpoint", None) is not None:
                    # logger.info("Skipping %s due to custom endpoint", filename)
                    return func(repo_id, filename, *args, **kwargs)
                # skip when huggingface already has the file
                try:
                    kwargs_copy = kwargs.copy()
                    kwargs_copy["local_files_only"] = True
                    res = func(repo_id, filename, *args, **kwargs_copy)
                    if res is not None:
                        # logger.info("Skipping %s due to existing local files", filename)
                        return res
                except:
                    pass

                try:
                    readonly = kwargs.get("local_files_only", False)
                    # attempt to query mirror
                    mirror_file = get_file(repo_id,
                                           filename,
                                           revision=kwargs.get("revision", None),
                                           subfolder=kwargs.get("subfolder", None),
                                           readonly=readonly)
                    if mirror_file is not None:
                        return mirror_file
                except Exception:
                    capture_exception()

                # logger.info("Falling back to original %s due to missing file or error", filename)
                # fallback to original function
                return func(repo_id, filename, *args, **kwargs)
            return hf_hub_download_wrapper_inner

        monkey.patch_function('hf_hub_download', hf_hub_download_wrapper)
