﻿from functools import wraps
from .common import get_filename_by_sha256, extract_sha256_from_path
from swlutils.hook import monkey_zoo


def fix_model_type():
    with monkey_zoo('ultralytics.nn.autobackend') as monkey:
        def autobackend_wrapper(cls, module):
            def _model_type_wrapper(func):
                # noinspection PyShadowingNames,PyDecorator
                @staticmethod
                @wraps(func)
                def _model_type_wrapper_inner(p, *args, **kwargs):
                    sha256 = extract_sha256_from_path(p)
                    if sha256 is None:
                        return func(p, *args, **kwargs)
                    filename = get_filename_by_sha256(sha256)
                    if filename is None:
                        return func(p, *args, **kwargs)
                    return func(filename, *args, **kwargs)
                return _model_type_wrapper_inner
            setattr(cls, '_model_type', _model_type_wrapper(cls.__dict__['_model_type']))
            return cls
        monkey.patch_function('AutoBackend', autobackend_wrapper)
