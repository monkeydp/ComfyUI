﻿import re
from functools import wraps
from .common import get_file, link_or_copy
from swlutils.hook import monkey_zoo
from swlutils.exception import capture_exception


def apply_mirror():
    with monkey_zoo("torchvision.datasets.utils") as monkey:
        def _urlretrieve_wrapper(func, module):
            @wraps(func)
            def _urlretrieve(url, fpath, *args, **kwargs):
                match = re.fullmatch(r"^https://huggingface\.co/(.+?)/resolve/(.+?)/(.+)", url, flags=re.IGNORECASE)
                if match is None:
                    # not a hf url
                    return func(url, fpath, *args, **kwargs)
                repo_id, revision, filename = match.groups()
                try:
                    # attempt to query mirror
                    mirror_spec = get_file(repo_id,
                                           filename,
                                           revision)
                    if mirror_spec is not None:
                        link_or_copy(mirror_spec, fpath)
                        return
                except Exception:
                    capture_exception()
                return func(url, fpath, *args, **kwargs)
            return _urlretrieve
        monkey.patch_function("_urlretrieve", _urlretrieve_wrapper)
