﻿from .common import set_spec, ensure_hf_transfer
from .huggingface_hub import apply_mirror as hfhub_mirror
from .torchhub import apply_mirror as torchhub_mirror
from .torchvision import apply_mirror as torchvision_mirror
from .ultralytics import fix_model_type as ultralytics_fix_model_type
from .endswithpatch import fix_load_state_dict
from .vaeapprox import apply_mirror as vaeapprox_mirror
from .comfyui_wd14_tagger import apply_mirror as comfyui_wd14_tagger_mirror


def apply_hf_mirror(mirror_spec):
    # ensure_hf_transfer()
    set_spec(mirror_spec)
    hfhub_mirror()
    torchhub_mirror()
    torchvision_mirror()
    comfyui_wd14_tagger_mirror()
    # ultralytics_fix_model_type()
    # fix_load_state_dict()
    vaeapprox_mirror()
