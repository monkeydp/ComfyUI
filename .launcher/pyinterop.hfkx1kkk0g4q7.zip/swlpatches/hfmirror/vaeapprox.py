﻿from swlutils.hook import monkey_zoo


def apply_mirror():
    with monkey_zoo("modules.sd_vae_approx") as monkey:
        def patch_vae_approx_address(code_object):
            code_object.co_consts.replace_primitive('https://github.com/AUTOMATIC1111/stable-diffusion-webui/releases/download/v1.0.0-pre/', 'https://modelscope.cn/api/v1/models/hanamizukiai/stable-diffusion-webui-vae-approx/repo?Revision=master&FilePath=')
        monkey.patch_bytecode(patch_vae_approx_address)
