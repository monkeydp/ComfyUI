﻿import json
import os
import sys
import math
import subprocess
import tempfile
import logging
import hashlib
import importlib.util
import shutil
import random
import functools
import time
from swlutils.progressbar import Progress

depth = int(os.environ.get("EE_DEPTH_REF", "0"))
debug = os.getenv("EE_DEBUG") == "1"

logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG if debug else logging.CRITICAL)

cache_base_path = os.getenv("HFMIRROR_HOME")
os.makedirs(cache_base_path, exist_ok=True)
os.makedirs(os.path.join(cache_base_path, "blob"), exist_ok=True)
os.makedirs(os.path.join(cache_base_path, "refs"), exist_ok=True)
os.makedirs(os.path.join(cache_base_path, "spec"), exist_ok=True)

HF_MIRROR_LOOKUP_TABLES = {}
HF_MIRROR_BLOB_TABLES = {}


def is_installed(package):
    try:
        spec = importlib.util.find_spec(package)
    except ModuleNotFoundError:
        return False

    return spec is not None


def ensure_hf_transfer():
    global depth
    if depth > 1:
        return
    if is_installed("hf_transfer"):
        logger.debug("hf_transfer already installed")
        return
    if os.getenv("HF_HUB_ENABLE_HF_TRANSFER") == "0":
        logger.debug("hf_transfer explicitly disabled")
        return
    try:
        logger.info("Trying to install hf_transfer")
        this_env = os.environ.copy()
        this_env['EE_DEPTH_REF'] = str(depth+1)
        subprocess.run([sys.executable, "-m", "pip", "install", "-U", "hf_transfer"],
                       shell=False, check=True, env=this_env)
        os.environ.setdefault("HF_HUB_ENABLE_HF_TRANSFER", "1")
    except Exception as e:
        if debug:
            logger.warning("Failed to install hf_transfer: %s", e)
        pass


REMOTE_SPEC_CACHE = {}


def fetch_remote_spec(repo_id, revision="main"):
    import requests
    spec = None 
    etag = None
    exp = None

    try:
        with open(os.path.join(cache_base_path, "spec", repo_id.casefold(), revision.casefold() + ".json"), "r") as f:
            spec = json.load(f)
    except Exception as e:
        pass

    if (repo_id.casefold(), revision.casefold()) in REMOTE_SPEC_CACHE:
        spec, etag, exp = REMOTE_SPEC_CACHE[(repo_id.casefold(), revision.casefold())]
        if exp > int(time.time()):
            logger.debug("cache hit: %s", exp)
            return spec
        else:
            logger.debug("cache revalidate: %s", exp)
    url = f"https://hfredir.oystermercury.top/{repo_id}/{revision}.json"
    try:
        headers = {}
        if etag is not None:
            headers['If-None-Match'] = etag
        with requests.get(url, headers=headers, timeout=15) as r:
            if r.status_code == 304:
                logger.debug("requests succeeded: %s", r.status_code)
                new_exp = int(time.time()) + 3600
                REMOTE_SPEC_CACHE[(repo_id.casefold(), revision.casefold())] = (spec, etag, new_exp)
                return spec
            elif r.status_code == 200:
                logger.debug("requests succeeded: %s", r.status_code)
                spec = r.json()
                etag = r.headers.get('Etag', None)
                exp = int(time.time()) + 3600
                REMOTE_SPEC_CACHE[(repo_id.casefold(), revision.casefold())] = (spec, etag, exp)
                try:
                    os.makedirs(os.path.join(cache_base_path, "spec", repo_id.casefold()), exist_ok=True)
                    with open(os.path.join(cache_base_path, "spec", repo_id.casefold(), revision.casefold() + ".json"), "w") as f:
                        json.dump(spec, f)
                except Exception as e:
                    logger.debug("cache save failed: %s", e)
                return spec
            else:
                logger.debug("requests failed: %s", r.status_code)
                REMOTE_SPEC_CACHE[(repo_id.casefold(), revision.casefold())] = (None, None, int(time.time()) + 600)
                return spec
    except Exception as e:
        logger.debug("requests failed: %s", e)
        return spec


def set_spec(spec):
    global HF_MIRROR_LOOKUP_TABLES, HF_MIRROR_BLOB_TABLES
    for item in spec['lookup']:
        repo_id = item['repo_id'].casefold()
        HF_MIRROR_LOOKUP_TABLES[repo_id] = {}
        for file in item['items']:
            HF_MIRROR_LOOKUP_TABLES[repo_id][
                (file["filename"].casefold(), file["revision"].casefold())
            ] = {"sha256": file["sha256"], "size": file["size"]}
    HF_MIRROR_BLOB_TABLES = spec['blobs']


def link_or_copy(src, dst):
    try:
        if os.path.exists(dst):
            if os.path.samefile(src, dst):
                return
            os.remove(dst)
        try:
            os.link(src, dst)
        except OSError:
            shutil.copyfile(src, dst)
    except shutil.SameFileError:
        pass


def temp_path(sha256):
    return os.path.join(cache_base_path, "blob", sha256)


def exists_file(path):
    try:
        return os.path.exists(path)
    except:
        return False


def download(url, size):
    with tempfile.NamedTemporaryFile(mode="w+b", delete=False) as tmp:
        temppath = tmp.name
        try:
            import requests
            with Progress("正在通过镜像下载模型文件", size, indeterminate=True) as progress:
                trimmed_url = url[:25] + " ...... " + url[-25:] if len(url) > 50 else url
                progress.left = trimmed_url
                step = math.ceil(size / 10000 / 65536) * 65536
                with requests.get(url, stream=True, headers={'accept-encoding': 'identity'}) as r:
                    progress.indeterminate = False
                    fsrc_read = r.raw.read
                    fdst_write = tmp.write
                    while buf := fsrc_read(step):
                        progress.value += len(buf)
                        fdst_write(buf)
            return temppath
        except Exception as e:
            logger.debug("requests failed: %s", e)
            pass
    if temppath is not None and exists_file(temppath):
        os.unlink(temppath)
    return False


def verify_file(path, sha256, size):
    try:
        if os.path.getsize(path) != size:
            return False

        s256 = hashlib.sha256()
        with open(path, 'rb') as file:
            for chunk in iter(lambda: file.read(4096), b''):
                s256.update(chunk)
        return s256.hexdigest() == sha256
    except:
        return False


def download_and_verify(url, sha256, size):
    logger.debug("Attempting to download %s via %s", sha256, url)
    tmp_path = download(url, size)
    if tmp_path is False:
        return False
    if not verify_file(tmp_path, sha256, size):
        logger.warning("Downloaded file %s does not match sha256 %s size %d", url, sha256, size)
        os.unlink(tmp_path)
        return False
    return tmp_path


def download_and_move(sha256, size, candidates):
    for candidate in random.sample(candidates, len(candidates)):
        try:
            tmp_path = download_and_verify(candidate, sha256, size)
            if tmp_path is False:
                continue
            # os.rename(tmp_path, temp_path(sha256))
            shutil.move(tmp_path, temp_path(sha256))
            return True
        except Exception as e:
            logger.debug("Download %s from candidate %s failed: %s", sha256, candidate, e)
            pass
    return False


def query_file_old(repo_id, filename, revision=None):
    global HF_MIRROR_LOOKUP_TABLES
    repospec = HF_MIRROR_LOOKUP_TABLES.get(repo_id.casefold(), None)
    if repospec is None:
        return None

    filespec = repospec.get((filename.casefold(), revision.casefold()), None)
    if filespec is None:
        return None
    candidates = HF_MIRROR_BLOB_TABLES.get(filespec['sha256'], None)
    if candidates is None:
        logger.warning("%s has no mirror candidates", filespec['sha256'])
        return None
    filespec = filespec.copy()
    filespec['resources'] = candidates
    return filespec


def query_file(repo_id, filename, revision=None, subfolder=None):
    if subfolder == "":
        subfolder = None
    if subfolder is not None:
        filename = subfolder + "/" + filename
    if revision is None:
        revision = "main"

    remote_spec = fetch_remote_spec(repo_id, revision)
    if remote_spec is not None:
        for item in remote_spec:
            if item["filename"].casefold() == filename.casefold():
                logger.debug("Found remotespec file %s from repo %s revision %s", filename, repo_id, revision)
                return item
    
    local_spec = query_file_old(repo_id, filename, revision)
    if local_spec is not None:
        logger.debug("Found localspec file %s from repo %s revision %s", filename, repo_id, revision)
        return local_spec
    
    return None


def get_filepath_from_refs(repo_id, filename, revision=None, subfolder=None):
    if revision is None:
        revision = "main"

    if subfolder == "":
        subfolder = None

    if subfolder is not None:
        filename = subfolder + "/" + filename

    repo_id = repo_id.replace("/", os.path.sep)
    ref_path = os.path.join(cache_base_path, "refs", repo_id, revision, filename)
    os.makedirs(os.path.dirname(ref_path), exist_ok=True)
    return ref_path


def get_file(repo_id, filename, revision=None, subfolder=None, verify=False, readonly=False):
    logger.debug("Fetching file %s from repo %s revision %s", filename, repo_id, revision)

    ref_path = get_filepath_from_refs(repo_id, filename, revision, subfolder)
    filespec = query_file(repo_id, filename, revision, subfolder)

    if filespec is not None:
        sha256 = filespec['sha256']
        size = filespec['size']
        filepath = temp_path(sha256)
        if exists_file(filepath):
            logger.debug("File %s from repo %s revision %s from cache", filename, repo_id, revision)
            if verify:
                if not verify_file(filepath, sha256, size):
                    logger.warning("File %s from repo %s revision %s from cache does not match sha256 %s size %d", filename,
                                   repo_id, revision, sha256, size)
                    if exists_file(ref_path) and os.path.samefile(filepath, ref_path):
                        os.remove(ref_path)
                    os.remove(filepath)
                if exists_file(ref_path) and verify_file(ref_path, sha256, size):
                    link_or_copy(ref_path, filepath)
                    return ref_path
            else:
                if exists_file(ref_path):
                    return ref_path
                link_or_copy(filepath, ref_path)
                return ref_path

        if exists_file(ref_path):
            if verify_file(ref_path, sha256, size):
                link_or_copy(ref_path, filepath)
                return ref_path
            else:
                os.remove(ref_path)
    
        if not readonly:
            logger.info("Missing file %s from repo %s revision %s from cache", filename, repo_id, revision)
            candidates = filespec['resources']
            if download_and_move(sha256, size, candidates):
                link_or_copy(filepath, ref_path)
                return ref_path

    if exists_file(ref_path):
        logger.debug(
            "File %s from repo %s revision %s from refs", filename, repo_id, revision
        )
        return ref_path

    return None


@functools.cache
def get_filename_by_sha256(sha256):
    global HF_MIRROR_LOOKUP_TABLES
    for repo in HF_MIRROR_LOOKUP_TABLES:
        for (filename, revision), filespec in HF_MIRROR_LOOKUP_TABLES[repo].items():
            if filespec['sha256'] == sha256:
                return filename
    return None


def extract_sha256_from_path(path):
    if not path.startswith(os.path.join(cache_base_path, "blob")):
        return None
    return os.path.basename(path)
