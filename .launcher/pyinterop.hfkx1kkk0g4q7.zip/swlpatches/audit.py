import sys
from swlutils.audithandler import AuditHandler


def create_audit_hook(filters, handler):
    def perform_audit(event, args):
        nonlocal filters, handler
        if event in filters:
            handler.report(event, args)
    return perform_audit

def setup_audit(
    comm_manager, filters
):
    handler = AuditHandler.from_comm_manager(comm_manager)
    if handler is None:
        return
    sys.addaudithook(create_audit_hook(filters, handler))
