import functools
from swlutils.hook import monkey_zoo
from swlutils.exception import capture_exception


def patch_webbrowser(managed_browser):
    with monkey_zoo("webbrowser") as monkey:
        def _hook_open(func, module):
            try:
                @functools.wraps(func)
                def _wrapper_open(url, *args, **kwargs):
                    try:
                        managed_browser.open(url)
                    except Exception:
                        capture_exception()
                        func(url, *args, **kwargs)
                return _wrapper_open
            except Exception:
                capture_exception()
                return func

        monkey.patch_function("open", _hook_open)
