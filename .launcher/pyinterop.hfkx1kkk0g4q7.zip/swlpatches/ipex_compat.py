from functools import wraps
from swlutils.hook import monkey_zoo
from swlutils.funcinspect import FuncArgAnalyzer


def patch():
    with monkey_zoo("intel_extension_for_pytorch.frontend") as monkey:
        def wrap_optimize(func, module):
            sig = FuncArgAnalyzer(func)
            @wraps(func)
            def wrapper(*args, **kwargs):
                if 'graph_mode' in kwargs and not sig.has_arg('graph_mode'):
                    del kwargs['graph_mode']
                return func(*args, **kwargs)
            return wrapper
        monkey.patch_function('optimize', wrap_optimize)
