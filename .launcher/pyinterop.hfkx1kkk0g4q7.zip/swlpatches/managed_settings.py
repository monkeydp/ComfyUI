﻿import functools
from swlutils.hook import register_hook


def patch_managed_settings(managed_settings):
    def shared_options_hook(cls, module):
        _original_set = cls.__dict__.get('set', None)
        _original_setattr = cls.__dict__.get('__setattr__', None)
        _original_getattr = cls.__dict__.get('__getattr__', None)
        _original_reorder = cls.__dict__.get('reorder', None)

        if _original_set is not None:
            @functools.wraps(_original_set)
            def checked_write(self, key, value, *args, **kwargs):
                if key in managed_settings:
                    return False
                return _original_set(self, key, value, *args, **kwargs)

            setattr(cls, 'set', checked_write)

        if _original_setattr is not None:
            @functools.wraps(_original_setattr)
            def checked_write(self, key, value, *args, **kwargs):
                if key in managed_settings:
                    return
                return _original_setattr(self, key, value, *args, **kwargs)

            setattr(cls, '__setattr__', checked_write)

        if _original_getattr is not None:
            @functools.wraps(_original_getattr)
            def checked_read(self, key, *args, **kwargs):
                if key in managed_settings:
                    return managed_settings[key]
                else:
                    return _original_getattr(self, key, *args, **kwargs)

            setattr(cls, '__getattr__', checked_read)

        if _original_reorder is not None:
            @functools.wraps(cls.reorder)
            def checked_reorder(self, *args, **kwargs):
                _original_reorder(self, *args, **kwargs)
                for k, info in self.data_labels.items():
                    if k in managed_settings and info is not None:
                        if info.component_args is None:
                            info.component_args = {'visible': False}
                        elif isinstance(info.component_args, dict):
                            info.component_args['visible'] = False
                        elif callable(info.component_args):
                            old_component_args = info.component_args

                            # noinspection PyShadowingNames
                            # noinspection PyCallingNonCallable
                            def new_component_args(*args, **kwargs):
                                old_data = old_component_args(*args, **kwargs)
                                if old_data is None:
                                    old_data = {'visible': False}
                                elif isinstance(old_data, dict):
                                    old_data['visible'] = False
                                return old_data

                            info.component_args = new_component_args

            setattr(cls, 'reorder', checked_reorder)

        return cls

    register_hook('modules.shared', 'Options', shared_options_hook)
    register_hook('modules.options', 'Options', shared_options_hook)

