﻿import logging
import warnings
from swlutils.hook import monkey_zoo


def patch_warnings():
    logging.getLogger("xformers").addFilter(lambda record: 'A matching Triton is not available' not in record.getMessage())
    logging.getLogger("pytorch_lightning").disabled = True
    logging.getLogger("DeepSpeed").disabled = True
    logging.getLogger("urllib3.connectionpool").addFilter(lambda record: 'Retrying' not in record.getMessage())
    logging.getLogger("swlvendors.urllib3.connectionpool").addFilter(lambda record: 'Retrying' not in record.getMessage())
    logging.getLogger('tensorflow').setLevel(logging.ERROR)
    warnings.simplefilter('ignore', category=DeprecationWarning)
    warnings.simplefilter('ignore', category=FutureWarning)
    warnings.filterwarnings('ignore', category=UserWarning, module="torchvision")
    warnings.filterwarnings('ignore', category=UserWarning, module="torchaudio")

    with monkey_zoo('gradio.deprecation') as monkey:
        def patcher(dp):
            try:
                if 'GradioDeprecationWarning' in dp.__dict__:
                    warnings.simplefilter('ignore', category=dp.GradioDeprecationWarning)

                if 'GradioUnusedKwargWarning' in dp.__dict__:
                    warnings.simplefilter('ignore', category=dp.GradioUnusedKwargWarning)
            except:
                pass

        monkey.patch_module(patcher)

    with monkey_zoo('modules.ui') as monkey:
        def patcher(_):
            try:
                from gradio.deprecation import GradioDeprecationWarning, GradioUnusedKwargWarning

                warnings.filterwarnings('ignore', category=UserWarning, module="gradio.utils")
                warnings.simplefilter('ignore', category=GradioDeprecationWarning)
                warnings.simplefilter('ignore', category=GradioUnusedKwargWarning)
            except:
                pass
        monkey.patch_module(patcher)

    with monkey_zoo('ldm.modules.diffusionmodules.model') as monkey:
        monkey.prohibit_output()

    with monkey_zoo('pip._internal.utils.deprecation') as monkey:
        def patcher(_):
            try:
                if 'PipDeprecationWarning' in dp.__dict__:
                    warnings.filterwarnings('ignore', category=dp.PipDeprecationWarning)
            except:
                pass
        monkey.patch_module(patcher)

    with monkey_zoo('starlette.websockets') as monkey:
        def patcher(module):
            try:
                if 'WebSocketDisconnect' in module.__dict__:
                    logging.getLogger("uvicorn.error").addFilter(lambda record: record.exc_info is None or not isinstance(record.exc_info, module.WebSocketDisconnect))
            except:
                pass
        monkey.patch_module(patcher)

    with monkey_zoo('h11._util') as monkey:
        def patcher(module):
            try:
                if 'LocalProtocolError' in module.__dict__:
                    logging.getLogger("uvicorn.error").addFilter(lambda record: record.exc_info is None or not isinstance(record.exc_info, module.LocalProtocolError))
            except:
                pass
        monkey.patch_module(patcher)
