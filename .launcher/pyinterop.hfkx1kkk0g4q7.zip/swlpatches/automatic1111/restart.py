﻿import functools
import os
from swlutils.hook import register_hook


def patch_restart():
    def _hook_is_restartable(func, module):
        @functools.wraps(func)
        def _wrapper_is_restartable(*args, **kwargs):
            return True
        return _wrapper_is_restartable
    
    def _hook_restart_program(func, module):
        @functools.wraps(func)
        def _wrapper_restart_program(*args, **kwargs):
            os._exit(0x1001)
        return _wrapper_restart_program

    register_hook("modules.restart", "is_restartable", _hook_is_restartable)
    register_hook("modules.restart", "restart_program", _hook_restart_program)