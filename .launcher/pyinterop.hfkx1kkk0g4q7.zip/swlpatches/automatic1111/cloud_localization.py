﻿import functools
import os
from swlutils.hook import register_hook
from swlutils.htmlresources import prepends_scripts
from swlutils.resource import open_resource_context, get_last_changed_time


def patch_cloud_localization_legacy():
    script_path = os.path.join(".launcher", 'localization.vp7h1jtr0s441kql.js')

    def _hooked_list_scripts(func, module):
        nonlocal script_path

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            nonlocal script_path
            _arg = list(args)
            result = func(*_arg, **kwargs)
            if _arg[0] != 'javascript' or _arg[1] != '.js':
                return result
            localization_loaded = False
            from modules.scripts import ScriptFile
            for i, element in enumerate(result):
                if element.filename == 'localization.js':
                    localization_loaded = True
                    if hasattr(ScriptFile, 'priority'):
                        result[i] = ScriptFile(element.basedir, element.filename,
                                               script_path,
                                               element.priority)
                    else:
                        result[i] = ScriptFile(element.basedir, element.filename,
                                               script_path)
            if not localization_loaded:
                if hasattr(ScriptFile, 'priority'):
                    result.append(
                        ScriptFile(None, None, script_path, 0))
                else:
                    result.append(ScriptFile(None, None, script_path))
            return result

        return wrapper

    register_hook("modules.scripts", "list_scripts", _hooked_list_scripts)


def patch_cloud_localization_modern(fork_type):
    def _hooked_list_scripts(func, module):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            _arg = list(args)
            result = func(*_arg, **kwargs)
            if _arg[0] != 'javascript' or _arg[1] != '.js':
                return result
            # remove the old localization.js
            for i, element in enumerate(result):
                if element.filename == 'localization.js':
                    del result[i]
                    break
            return result
        return wrapper
    register_hook("modules.scripts", "list_scripts", _hooked_list_scripts)

    prepends_scripts.append('<link rel="dns-prefetch" href="https://langs-v2.oystermercury.top/">')
    prepends_scripts.append('<link rel="preconnect" href="https://langs-v2.oystermercury.top/" crossorigin>')

    with open_resource_context() as ctx:
        sdk_last_update = get_last_changed_time(ctx, 'tolgee-sdk.js')
        prepends_scripts.append(
            f'<script type="text/javascript" src="/launcher/assets/tolgee-sdk.js?{sdk_last_update}"></script>')
        localization_last_update = get_last_changed_time(ctx, 'automatic1111/localization.js')
        prepends_scripts.append(
            f'<script type="text/javascript" data-namespace="{fork_type}" '
            f'src="/launcher/assets/automatic1111/localization.js?{localization_last_update}"></script>')
