﻿import functools
from swlutils.htmlresources import apply_scripts, apply_styles
from swlutils.hook import monkey_zoo
from swlutils.a1111scripts import on_app_started
from swlutils.resource import open_resource, get_last_changed_time, open_resource_context
from swlutils.exception import capture_exception
import mimetypes
import datetime
import time
import os


def patch():
    def inject_javascript(func, module):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            script_produced = func(*args, **kwargs)
            return apply_scripts(script_produced)

        return wrapper

    def inject_css(func, module):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            css_produced = func(*args, **kwargs)
            return apply_styles(css_produced)

        return wrapper

    with monkey_zoo('modules.ui_gradio_extensions') as monkey:
        monkey.patch_function('javascript_html', inject_javascript)
        monkey.patch_function('css_html', inject_css)

    with monkey_zoo('modules.ui') as monkey:
        monkey.patch_function('javascript_html', inject_javascript)
        monkey.patch_function('css_html', inject_css)
        # vladmandic
        monkey.patch_function('html_head', inject_javascript)
        monkey.patch_function('html_css', inject_css)

    def serve_localization_file(_, app):
        from modules.paths import script_path
        from fastapi.responses import Response, StreamingResponse
        from fastapi import HTTPException, Request

        @app.get("/launcher/assets/{url_in_archive:path}")
        def launcher_static_resources(request: Request, url_in_archive: str):
            try:
                mime_type, _ = mimetypes.guess_type(url_in_archive)

                with open_resource_context() as ctx:
                    last_updated = get_last_changed_time(ctx, url_in_archive)

                    # Check If-Modified-Since header
                    if 'if-modified-since' in request.headers:
                        header_date = request.headers['if-modified-since']
                        header_date = datetime.datetime.strptime(header_date, '%a, %d %b %Y %H:%M:%S GMT')
                        header_timestamp = header_date.timestamp()

                        # If the resource has not been modified since the date in the header
                        if header_timestamp - last_updated > 1:
                            return Response(status_code=304)

                    with open_resource(ctx, url_in_archive) as gen:
                        return Response(gen.read(), media_type=mime_type, headers={
                            'Cache-Control': 'no-cache',
                            'Last-Modified': datetime.datetime.fromtimestamp(last_updated, tz=datetime.timezone.utc)
                                                 .strftime('%a, %d %b %Y %H:%M:%S GMT'),
                        })
            except (KeyError, ValueError):
                capture_exception()
                raise HTTPException(status_code=404, detail="Not Found")
            except:
                capture_exception()
                raise HTTPException(status_code=500, detail="Internal Server Error")

    on_app_started(serve_localization_file, "ee/html_resources")
