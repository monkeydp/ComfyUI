﻿import functools
from swlutils.hook import register_hook


def patch_checkpoint_verification():
    def _hooked_get_checkpoint_state_dict(func, module):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            if "model.diffusion_model.input_blocks.0.0.weight" not in result:
                if 'encoder.down.0.block.0.norm1.weight' in result:
                    print("提示：您正在加载的模型种类错误，已取消加载。此处应加载大模型，而该模型为 VAE 模型")
                    raise RuntimeError("The model currently loading is a VAE instead of a Stable Diffusion checkpoint.")
                elif 'control_model.input_blocks' in result:
                    print("提示：您正在加载的模型种类错误，已取消加载。此处应加载大模型，而该模型为 Controlnet 模型")
                    raise RuntimeError("The model currently loading is a Controlnet model instead of a Stable Diffusion checkpoint.")

                for k in result.keys():
                    if 'lora_' in k:
                        print("提示：您正在加载的模型种类错误，已取消加载。此处应加载大模型，而该模型为 LoRA 模型")
                        raise RuntimeError("The model currently loading is a LoRA instead of a Stable Diffusion checkpoint.")
            return result
        return wrapper

    register_hook('modules.sd_models', 'get_checkpoint_state_dict', _hooked_get_checkpoint_state_dict)
