from os import add_dll_directory 


def apply(dirs):
    for dirpath in dirs:
        add_dll_directory(dirpath)
