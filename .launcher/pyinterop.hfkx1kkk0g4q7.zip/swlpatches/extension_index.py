﻿import functools
from swlutils.hook import monkey_zoo
from types import CodeType


def patch_extension_index_a1111(dest):
    with monkey_zoo('modules.ui_extensions') as monkey:
        def patch_extension_index_url(code_object):
            code_object.co_consts.replace_primitive(
                "https://raw.githubusercontent.com/wiki/AUTOMATIC1111/stable-diffusion-webui/Extensions-index.md", dest)
            code_object.co_consts.replace_primitive(
                "https://raw.githubusercontent.com/AUTOMATIC1111/stable-diffusion-webui-extensions/master/index.json",
                dest)
            code_object.co_consts.replace_primitive(
                "https://gitee.com/nightaway/automatic111-webui-exts/raw/master/Extensions-index.md", dest)
            code_object.co_consts.replace_primitive("https://vladmandic.github.io/sd-data/pages/extensions.json", dest)

        monkey.patch_bytecode(patch_extension_index_url)


def patch_extension_index_comfyui_manager():
    def patch_default_urls(code_object):
        for cache_update in code_object.co_consts.operate(
                lambda c: isinstance(c, CodeType) and c.co_name == 'default_cache_update', only_first=True):
            for get_cache in cache_update.co_consts.operate(
                    lambda c: isinstance(c, CodeType) and c.co_name == 'get_cache', only_first=True):
                get_cache.co_consts.replace_primitive(
                    'https://raw.githubusercontent.com/ltdrdata/ComfyUI-Manager/main/',
                    'https://gitcode.net/ranting8323/ComfyUI-Manager/-/raw/main/')

    def patch_get_data(func, module):
        @functools.wraps(func)
        def wrapper(uri, *args, **kwargs):
            if isinstance(uri, str) and uri.startswith(
                    'https://raw.githubusercontent.com/ltdrdata/ComfyUI-Manager/main/'):
                uri = uri.replace('https://raw.githubusercontent.com/ltdrdata/ComfyUI-Manager/main/',
                                  'https://gitcode.net/ranting8323/ComfyUI-Manager/-/raw/main/')
            return func(uri, *args, **kwargs)

        return wrapper

    with monkey_zoo('ComfyUI-Manager') as monkey:
        monkey.patch_function('get_data', patch_get_data)
        monkey.patch_bytecode(patch_default_urls)

    with monkey_zoo('ComfyUI-Manager-main') as monkey:
        monkey.patch_function('get_data', patch_get_data)
        monkey.patch_bytecode(patch_default_urls)
