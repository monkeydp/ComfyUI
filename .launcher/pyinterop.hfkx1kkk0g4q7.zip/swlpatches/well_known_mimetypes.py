﻿from mimetypes import add_type


def anchor_mimetypes():
    known_mime_types = {
        ".js": "application/javascript",
        ".mjs": "application/javascript",
        ".json": "application/json",
        ".webmanifest": "application/manifest+json",
        ".wasm": "application/wasm",
        ".css": "text/css",
        ".csv": "text/csv",
        ".html": "text/html",
        ".htm": "text/html",
        ".xml": "text/xml",
        ".mp4": "video/mp4",
        ".mpeg": "video/mpeg",
        ".mpg": "video/mpeg",
        ".webm": "video/webm",
        ".avi": "video/x-msvideo",
    }

    for extension, mimetype in known_mime_types.items():
        add_type(mimetype, extension, strict=True)
