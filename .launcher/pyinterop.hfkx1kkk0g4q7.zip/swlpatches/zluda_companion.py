from swlutils.hook import monkey_zoo
import ctypes
import os
import glob
from functools import wraps


def apply_zluda_library(library_path):
    with monkey_zoo("torch") as monkey:
        def load_zluda_module(module):
            kernel32 = ctypes.WinDLL("kernel32.dll", use_last_error=True)
            with_load_library_flags = hasattr(kernel32, "AddDllDirectory")
            prev_error_mode = kernel32.SetErrorMode(0x0001)

            kernel32.LoadLibraryW.restype = ctypes.c_void_p
            if with_load_library_flags:
                kernel32.LoadLibraryExW.restype = ctypes.c_void_p

            dll_paths = library_path
            dlls = glob.glob(os.path.join(dll_paths, "*.dll"))
            path_patched = False
            for dll in dlls:
                is_loaded = False
                if with_load_library_flags:
                    res = kernel32.LoadLibraryExW(dll, None, 0x00001100)
                    last_error = ctypes.get_last_error()
                    if res is None and last_error != 126:
                        err = ctypes.WinError(last_error)
                        err.strerror += (
                            f' Error loading "{dll}" or one of its dependencies.'
                        )
                        raise err
                    elif res is not None:
                        is_loaded = True
                if not is_loaded:
                    if not path_patched:
                        os.environ["PATH"] = ";".join(
                            [dll_paths] + [os.environ["PATH"]]
                        )
                        path_patched = True
                    res = kernel32.LoadLibraryW(dll)
                    if res is None:
                        err = ctypes.WinError(ctypes.get_last_error())
                        err.strerror += (
                            f' Error loading "{dll}" or one of its dependencies.'
                        )
                        raise err
            kernel32.SetErrorMode(prev_error_mode)
            return
        monkey.patch_premodule(load_zluda_module)


def apply_zluda_compat():
    with monkey_zoo("torch") as monkey:

        def set_torch_var(module):
            module.backends.cudnn.enabled = False
            module.backends.cuda.enable_flash_sdp(False)
            module.backends.cuda.enable_math_sdp(True)
            module.backends.cuda.enable_mem_efficient_sdp(False)

        monkey.patch_module(set_torch_var)

    with monkey_zoo("torch.backends.cuda") as monkey:
        def always_false_fn(func, module):
            @wraps(func)
            def always_false(enabled):
                return func(False)

            return always_false
        
        monkey.patch_function(
            "enable_flash_sdp", always_false_fn
        )
        monkey.patch_function(
            "enable_mem_efficient_sdp", always_false_fn
        )
