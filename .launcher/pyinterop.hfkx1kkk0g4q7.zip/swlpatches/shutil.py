﻿import os
from sys import hexversion
import shutil
from swlutils.funcinspect import FuncArgAnalyzer, FuncArgNotFound
from swlutils.hook import monkey_zoo
from swlutils.exception import capture_exception
from swlutils.fileoperation import FileOperation
from swlutils.exception import UserCanceledException


def remove_readonly(func, path, _):
    """Clear the readonly bit and reattempt the removal"""
    try:
        os.chmod(path, os.stat.S_IWRITE)
        func(path)
    except Exception:
        capture_exception(submit_report=False)


def patch_rmtree():
    def patch_rmtree_wrapper(func, module):
        def patched_rmtree(path, *args, **kwargs):
            try:
                with FileOperation() as fileop:
                    fileop.delete(path)
                    fileop.perform()
                return
            except UserCanceledException:
                pass
            except Exception:
                capture_exception(submit_report=False)
                pass
            return func(path, *args, **kwargs)
        return patched_rmtree

    shutil.rmtree = patch_rmtree_wrapper(shutil.rmtree, shutil)
    with monkey_zoo('shutil') as monkey:
        monkey.patch_function('rmtree', patch_rmtree_wrapper)
