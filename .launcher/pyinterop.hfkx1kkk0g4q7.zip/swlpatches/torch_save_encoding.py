﻿import functools
import pathlib
from swlutils.hook import register_hook


def patch_torch_save_encoding(method):
    version_constraint = True
    # try:
    #     from importlib.metadata import version  
    #     torch_version = version("torch")
    #     if torch_version.startswith("1.12.1") or torch_version.startswith("1.13.1"):
    #         version_constraint = True
    # except:
    #     pass
    
    if method == 1 and version_constraint:
        def _hooked_save(func, module):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                from ctypes import windll
                cp = windll.kernel32.GetConsoleOutputCP()
                _arg = list(args)
                if isinstance(_arg[1], str):
                    _arg[1] = str(_arg[1].encode(f"cp{cp}"))
                result = func(*_arg, **kwargs)
                return result
            return wrapper
        register_hook("torch.serialization", "save", _hooked_save)
    elif method == 2 and version_constraint:
        def _hooked_save(func, module):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                _arg = list(args)
                if isinstance(_arg[1], str) or isinstance(_arg[1], pathlib.Path):
                    _arg[1] = open(_arg[1], "wb")
                    try:
                        result = func(*_arg, **kwargs)
                    finally:
                        _arg[1].close()
                    return result
                else:
                    result = func(*_arg, **kwargs)
                    return result

            return wrapper
        register_hook("torch.serialization", "save", _hooked_save)