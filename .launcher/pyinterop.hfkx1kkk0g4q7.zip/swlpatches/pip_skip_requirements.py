﻿from swlutils.hook import monkey_zoo


def patch_pip_req_file_get_file_content():
    with monkey_zoo('pip._internal.req.req_file') as monkey:
        def _hooked_get_file_content(func, module):
            def get_file_content(url, *args, **kwargs):
                url, content, *rets = func(url, *args, **kwargs)
                if 'codeformer' in url.lower():
                    content = content.replace('tb-nightly', '# tb-nightly').replace('torch>', '# torch>').replace('torchvision', '# torchvision')
                return url, content, *rets
            return get_file_content
        monkey.patch_function('get_file_content', _hooked_get_file_content)