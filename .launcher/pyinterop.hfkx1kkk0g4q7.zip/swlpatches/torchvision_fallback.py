from swlutils.hook import monkey_zoo


def patch():
    monkey_zoo.alias_if_not_exists(
        "torchvision.transforms.functional_tensor",
        "torchvision.transforms.functional",
    )
