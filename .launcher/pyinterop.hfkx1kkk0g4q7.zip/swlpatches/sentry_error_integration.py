﻿import ast
import sys
from functools import wraps
from swlutils.hook import monkey_zoo
from swlvendors.sentry_sdk import push_scope
from swlutils.exception import capture_exception, client_capture_exception
from swlutils.htmlresources import prepends_scripts


class ComfyUiRecursiveExecuteExceptionTransformer(ast.NodeVisitor):
    def visit_FunctionDef(self, node):
        if node.name == 'recursive_execute':
            self.generic_visit(node)

    def visit_ExceptHandler(self, node):
        type = getattr(node, 'type', None)
        if type is None:
            return
        if not isinstance(type, ast.Name):
            return
        if type.id != 'Exception':
            return
        node.body.insert(0, ast.parse('swl_capture_exception()').body[0])


class ComfyUiLoadCustomNodeExceptionTransformer(ast.NodeVisitor):
    def visit_FunctionDef(self, node):
        if node.name == "load_custom_node":
            self.generic_visit(node)

    def visit_ExceptHandler(self, node):
        type = getattr(node, "type", None)
        if type is None:
            return
        if not isinstance(type, ast.Name):
            return
        if type.id != "Exception":
            return
        node.body.insert(0, ast.parse("swl_capture_exception()").body[0])


def patch_sentry_error_integration(fork_type):
    if fork_type in ['automatic1111', 'vladmandic', 'forge']:
        with monkey_zoo('modules.errors') as monkey:
            def hook_report(func, module):
                @wraps(func)
                def wrapper(message, *args, **kwargs):
                    with push_scope() as scope:
                        scope.set_context("Automatic1111", {
                            "Message": message,
                            "Extensions": get_sdwebui_extension_list() or "Failed to get extension list",
                        })
                        client_capture_exception()
                    return func(message, *args, **kwargs)

                return wrapper

            monkey.patch_function('report', hook_report)

            def hook_display(func, module):
                @wraps(func)
                def wrapper(e, task, *args, **kwargs):
                    with push_scope() as scope:
                        scope.set_context("Automatic1111", {
                            "Task": task,
                            "Extensions": get_sdwebui_extension_list() or "Failed to get extension list",
                        })
                        client_capture_exception(e)
                    return func(e, task, *args, **kwargs)

                return wrapper

            monkey.patch_function('display', hook_display)
        # install_sentry_javascript()
    elif fork_type == 'comfyui':
        with monkey_zoo('execution') as monkey:
            monkey.inject_import(__name__, 'comfyui_sentry_exception_handler', 'swl_capture_exception')
            monkey.patch_ast(ComfyUiRecursiveExecuteExceptionTransformer())

        with monkey_zoo('nodes') as monkey:
            monkey.inject_import(__name__, 'comfyui_sentry_exception_handler', 'swl_capture_exception')
            monkey.patch_ast(ComfyUiLoadCustomNodeExceptionTransformer())


def get_sdwebui_extension_list():
    try:
        if not 'modules.extensions' in sys.modules:
            return None
        ext_module = sys.modules['modules.extensions']
        if not hasattr(ext_module, 'extensions'):
            return None
        ext_list = ext_module.extensions
        if not isinstance(ext_list, list):
            return None
        exts = [f"{'A' if ext.enabled else 'I'} {ext.name} @ {getattr(ext, 'branch', 'Unknown')}/{ext.commit_hash[:8]} - {ext.remote}" for ext
                in ext_list]
        return exts
    except Exception:
        capture_exception()
        return None


def comfyui_sentry_exception_handler():
    client_capture_exception()


def install_sentry_javascript():
    prepends_scripts.insert(0, '<script>!function(n,e,t,r,i,o,a,c,u){for(var s=u,f=0;f<document.scripts.length;f++)if(document.scripts[f].src.indexOf(o)>-1){s&&"no"===document.scripts[f].getAttribute("data-lazy")&&(s=!1);break}var p=[];function d(n){return"e"in n}function l(n){return"p"in n}function _(n){return"f"in n}var v=[];function y(n){s&&(d(n)||l(n)||_(n)&&n.f.indexOf("capture")>-1||_(n)&&n.f.indexOf("showReportDialog")>-1)&&L(),v.push(n)}function h(){y({e:[].slice.call(arguments)})}function E(n){y({p:n})}function O(){try{n.SENTRY_SDK_SOURCE="loader";var e=n[i],o=e.init;e.init=function(i){n.removeEventListener(t,h),n.removeEventListener(r,E);var a=c;for(var u in i)Object.prototype.hasOwnProperty.call(i,u)&&(a[u]=i[u]);!function(n,e){var t=n.integrations||[];if(!Array.isArray(t))return;var r=t.map((function(n){return n.name}));n.tracesSampleRate&&-1===r.indexOf("BrowserTracing")&&t.push(new e.BrowserTracing);(n.replaysSessionSampleRate||n.replaysOnErrorSampleRate)&&-1===r.indexOf("Replay")&&t.push(new e.Replay);n.integrations=t}(a,e),o(a)},setTimeout((function(){return function(e){try{"function"==typeof n.sentryOnLoad&&(n.sentryOnLoad(),n.sentryOnLoad=void 0);for(var t=0;t<p.length;t++)"function"==typeof p[t]&&p[t]();p.splice(0);for(t=0;t<v.length;t++){_(o=v[t])&&"init"===o.f&&e.init.apply(e,o.a)}g()||e.init();var r=n.onerror,i=n.onunhandledrejection;for(t=0;t<v.length;t++){var o;if(_(o=v[t])){if("init"===o.f)continue;e[o.f].apply(e,o.a)}else d(o)&&r?r.apply(n,o.e):l(o)&&i&&i.apply(n,[o.p])}}catch(n){console.error(n)}}(e)}))}catch(n){console.error(n)}}var m=!1;function L(){if(!m){m=!0;var n=e.scripts[0],t=e.createElement("script");t.src=a,t.crossOrigin="anonymous",t.addEventListener("load",O,{once:!0,passive:!0}),n.parentNode.insertBefore(t,n)}}function g(){var e=n.__SENTRY__;return!(void 0===e||!e.hub||!e.hub.getClient())}n[i]=n[i]||{},n[i].onLoad=function(n){g()?n():p.push(n)},n[i].forceLoad=function(){setTimeout((function(){L()}))},["init","addBreadcrumb","captureMessage","captureException","captureEvent","configureScope","withScope","showReportDialog"].forEach((function(e){n[i][e]=function(){y({f:e,a:arguments})}})),n.addEventListener(t,h),n.addEventListener(r,E),s||setTimeout((function(){L()}))}(window,document,"error","unhandledrejection","Sentry","b64b00fb2dcf4edb0903112903b343a3","https://browser.sentry-cdn.com/7.82.0/bundle.tracing.replay.min.js",{"dsn":"https://b64b00fb2dcf4edb0903112903b343a3@sentry.oystermercury.top/10","sampleRate":0.2,"tracesSampleRate":0.005,"replaysSessionSampleRate":0.005,"replaysOnErrorSampleRate":1},!1);</script>')
