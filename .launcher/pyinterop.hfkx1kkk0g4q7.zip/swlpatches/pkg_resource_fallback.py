from swlutils.hook import monkey_zoo


def patch():
    monkey_zoo.alias_if_not_exists(
        "pkg_resources.packaging",
        "pkg_resources.extern.packaging",
    )
