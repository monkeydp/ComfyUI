﻿import functools
import os
from swlutils.hook import monkey_zoo


def expand_cache_path(path):
    cache_path = os.getenv("XDG_CACHE_HOME", os.path.expanduser('~/.cache'))
    return os.path.join(cache_path, path)


def patch_clip_model_path():
    with monkey_zoo('clip.clip') as monkey:
        def download_root_source_patch(source, filename):
            source = source.replace("os.path.expanduser(\"~/.cache/clip\")",
                                    f"expand_cache_path(\"clip\")")
            return source
        monkey.inject_import(__name__, "expand_cache_path")
        monkey.patch_sources(download_root_source_patch)
