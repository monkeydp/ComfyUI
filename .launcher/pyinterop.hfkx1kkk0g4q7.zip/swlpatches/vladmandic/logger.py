﻿import functools
from swlutils.hook import monkey_zoo


def patch_vladmandic_logger():

    with monkey_zoo('modules.errors') as monkey:
        monkey.inject_import("traceback")

        def patch_logger(source, filename):
            source = source.replace("pretty_install(", "None and pretty_install(")
            source = source.replace("traceback.install(", "None and traceback.install(")
            source = source.replace("logging.basicConfig(", "None and logging.basicConfig(")
            source = source.replace("log.error(line)", "print(line, file=sys.stderr)")
            source = source.replace("console.print_exception(", "traceback.print_exc() or None and console.print_exception(")
            return source
        monkey.patch_sources(patch_logger)

    # with monkey_zoo('modules.script_loading') as monkey:
    #     def patch_vladmandic_logger(source, filename, module):
    #         source = source.replace("setup_logging(", "# setup_logging(")
    #         return source
    #     monkey.patch_sources(patch_vladmandic_logger)

    with monkey_zoo('setup') as monkey:
        def patch_logger(source, filename):
            # source = source.replace("logging.basicConfig(", "# logging.basicConfig(")
            source = source.replace("pretty_install(", "None and pretty_install(")
            source = source.replace("traceback.install(", "None and traceback.install(")
            # source = source.replace("while log.hasHandlers() and", "while False and log.hasHandlers() and")
            source = source.replace("rh = RichHandler", "rh = logging.StreamHandler() or RichHandler")
            # source = source.replace("log.addHandler(rh)", "# log.addHandler(rh)")
            return source
        monkey.patch_sources(patch_logger)

        def patch_noop(func, module):
            def noop(*args, **kwargs):
                return
            return noop
        monkey.patch_function("check_version", patch_noop)

    with monkey_zoo('installer') as monkey:
        def patch_logger(source, filename):
            # source = source.replace("logging.basicConfig(", "# logging.basicConfig(")
            source = source.replace("pretty_install(", "None and  pretty_install(")
            source = source.replace("traceback.install(", "None and  traceback.install(")
            # source = source.replace("while log.hasHandlers() and", "while False and log.hasHandlers() and")
            source = source.replace("rh = RichHandler", "rh = logging.StreamHandler() or RichHandler")
            # source = source.replace("log.addHandler(rh)", "# log.addHandler(rh)")
            return source
        monkey.patch_sources(patch_logger)

        def patch_noop(func, module):
            def noop(*args, **kwargs):
                return
            return noop
        monkey.patch_function("check_version", patch_noop)

    # class RingBuffer(logging.StreamHandler):
    #     def __init__(self, capacity):
    #         super().__init__()
    #         self.capacity = capacity
    #         self.buffer = []
    #         self.formatter = logging.Formatter('{ "asctime":"%(asctime)s", "created":%(created)f, "facility":"%(name)s", "pid":%(process)d, "tid":%(thread)d, "level":"%(levelname)s", "module":"%(module)s", "func":"%(funcName)s", "msg":"%(message)s" }')
    # 
    #     def emit(self, record):
    #         msg = self.format(record)
    #         # self.buffer.append(json.loads(msg))
    #         self.buffer.append(msg)
    #         if len(self.buffer) > self.capacity:
    #             self.buffer.pop(0)
    # 
    #     def get(self):
    #         return self.buffer
    # 
    # def _hooked_noop(func, module):
    #     @functools.wraps(func)
    #     def wrapper(*args, **kwargs):
    #         return
    # 
    #     return wrapper
    # 
    with monkey_zoo('rich.console') as monkey:
        def _hooked_print(func, module):
            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                if not kwargs.get('no_wrap', False):
                    kwargs['no_wrap'] = True
                if kwargs.get('crop', True):
                    kwargs['crop'] = False
                return func(*args, **kwargs)
            return wrapper
        monkey.patch_function("print", _hooked_print)
    # 
    # def _hooked_logger(logger, module):
    #     logger.setLevel(logging.INFO)
    #     ch = logging.StreamHandler()
    #     ch.setLevel(logging.INFO)
    #     logger.addHandler(ch)
    #     rb = RingBuffer(100)
    #     rb.setLevel(logging.INFO)
    #     logger.addHandler(rb)
    #     logger.buffer = rb.buffer
    #     return logger
    # 
    # 
    # register_hook('setup', 'setup_logging', _hooked_noop)
    # register_hook('setup', 'log', _hooked_logger)
    # register_hook('setup', 'check_version', _hooked_noop)
    # register_hook('installer', 'setup_logging', _hooked_noop)
    # register_hook('installer', 'log', _hooked_logger)
    # register_hook('installer', 'check_version', _hooked_noop)
    # register_hook('rich.console', 'print', _hooked_print)
    # # register_hook('rich.pretty', 'install', _hooked_noop)
    # # register_hook('rich.traceback', 'install', _hooked_noop)
    # register_hook('modules.errors', 'install', _hooked_noop)