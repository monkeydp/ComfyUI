﻿from swlutils.hook import monkey_zoo
from functools import wraps


def hook_init(func):
    @wraps(func)
    def wrapper_init(*args, **kwargs):
        kwargs['trust_env'] = True
        return func(*args, **kwargs)
    return wrapper_init


def patch():
    with monkey_zoo("aiohttp.client") as monkey:
        def patch_aiohttp_client(module):
            if 'ClientSession' not in module.__dict__:
                return
            module.ClientSession.__init__ = hook_init(module.ClientSession.__init__)
        monkey.patch_module(patch_aiohttp_client)
