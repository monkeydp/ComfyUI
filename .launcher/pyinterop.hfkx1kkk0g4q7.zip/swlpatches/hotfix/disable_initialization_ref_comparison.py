﻿import sys
from functools import wraps
from swlutils.hook import monkey_zoo
from inspect import signature


class DisableInitializationRefComparisonHotFix:
    name = 'disable_initialization_ref_comparison'

    def patch(self):
        with monkey_zoo('modules.sd_disable_initialization') as monkey:
            def source_patch(source, filename):
                source = source.replace('if state_dict == sd:', 'if state_dict is sd:')
                return source

            monkey.patch_sources(source_patch)
