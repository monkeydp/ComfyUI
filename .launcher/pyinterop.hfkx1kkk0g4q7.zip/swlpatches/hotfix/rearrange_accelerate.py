from swlutils.hook import monkey_zoo
import sys

def rearrange_with_shape(shape_indicator, mutation):
    def mutator(tensor, **kwargs):
        shape = tensor.shape
        for i, s in enumerate(shape_indicator):
            if s != "_" and s not in kwargs:
                kwargs[s] = shape[i]
        return mutation(tensor, **kwargs).contiguous()
    return mutator

# rearrange_log = {}
rearrange_tensor_map = {
    "b n h d -> b n (h d)": rearrange_with_shape('bnhd', lambda t, b, n, h, d: t.view(b, n, h * d)),
    "b (h w) c -> b c h w": rearrange_with_shape('b_c', lambda t, b, c, h, w=-1: t.reshape(b, h, w, c).permute(0, 3, 1, 2)),
    "b c h w -> b (h w) c": rearrange_with_shape('', lambda t, b=None, c=None, h=None, w=None: t.permute(0, 2, 3, 1).flatten(1, 2)),
    "b n (h d) -> b n h d": rearrange_with_shape('bn', lambda t, b, n, h: t.reshape(b, n, h, -1)),
}

class RearrangeAccelerateHotfix:
    name = "rearrange_accelerate"

    def patch(self):
        with monkey_zoo('einops') as monkey:
            def rearrange_wrapper(func, module):
                def rearrange(tensor, pattern, **kwargs):
                    # global rearrange_log
                    # if pattern not in rearrange_log:
                    #     # print("rearrange", tensor.__class__.__name__, pattern, "x", 1, "l", len(rearrange_log))
                    #     rearrange_log[pattern] = 1
                    # else:
                    #     rearrange_log[pattern] += 1
                    #     # print("rearrange", tensor.__class__.__name__, pattern, "x", rearrange_log[pattern], "l", len(rearrange_log))
                    torch = sys.modules.get("torch", None)

                    if torch is not None and isinstance(tensor, torch.Tensor):
                        mutator = rearrange_tensor_map.get(pattern, None)
                        if mutator is not None:
                            return mutator(tensor, **kwargs)

                    return func(tensor, pattern, **kwargs)
                return rearrange
            monkey.patch_function("rearrange", rearrange_wrapper)
