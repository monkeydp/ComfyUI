from swlutils.hook import monkey_zoo


class FixTimestepDeviceHotfix:
    name = "fix_timestep_device"

    def patch(self):
        with monkey_zoo("ldm.modules.diffusionmodules.util") as monkey:
            def patch_timestep_device(func, module):
                def wrapper(timesteps, *args, **kwargs):
                    with timesteps.device:
                        return func(timesteps, *args, **kwargs)
                return wrapper
            monkey.patch_function("timestep_embedding", patch_timestep_device)

        with monkey_zoo("sgm.modules.diffusionmodules.util") as monkey:
            def patch_timestep_device(func, module):
                def wrapper(timesteps, *args, **kwargs):
                    with timesteps.device:
                        return func(timesteps, *args, **kwargs)
                return wrapper
            monkey.patch_function("timestep_embedding", patch_timestep_device)

        # with monkey_zoo("modules.sd_samplers_kdiffusion") as monkey:
        #     def patch_source(source, filename):
        #         source = source.replace(
        #             "sigmas = scheduler.function(n=steps, **sigmas_kwargs, device=shared.device)",
        #             "sigmas = scheduler.function(n=steps, **sigmas_kwargs)",
        #         )
        #         return source
        #     monkey.patch_sources(patch_source)
