﻿# https://github.com/TimDettmers/bitsandbytes/issues/820

import sys
import os
from pathlib import Path
from functools import wraps
from swlutils.hook import monkey_zoo


class BitsAndBytesCudaSetupHotfix:
    name = 'bitsandbytes_cudasetup'

    def patch(self):
        with monkey_zoo('bitsandbytes.cuda_setup.env_vars') as monkey:
            def fix_is_relevant_candidate_env_var(func, module):
                @wraps(func)
                def new_is_relevant_candidate_env_var(env_var: str, value: str, *args, **kwargs):
                    return (env_var.startswith('CUDA_') and ('/' in value)
                            and ('http' not in value) and ('://' not in value))

                return new_is_relevant_candidate_env_var

            monkey.patch_function('is_relevant_candidate_env_var', fix_is_relevant_candidate_env_var, 100)

        with monkey_zoo('bitsandbytes.cuda_setup.main') as monkey:
            def fix_determine_cuda_runtime_lib_path(func, module):
                @wraps(func)
                def new_determine_cuda_runtime_lib_path(*args, **kwargs):
                    if sys.modules.get('torch', None) is not None:
                        torch_lib_path = Path(sys.modules['torch'].__file__).parent / 'lib'
                        if os.path.exists(torch_lib_path):
                            torch_cuda_libs = module.find_cuda_lib_in(str(torch_lib_path))
                            if torch_cuda_libs:
                                module.warn_in_case_of_duplicates(torch_cuda_libs)
                                return next(iter(torch_cuda_libs))

                    executable_lib_path = str(Path(sys.executable).parent / 'bin')
                    if os.path.exists(executable_lib_path):
                        executable_cuda_libs = module.find_cuda_lib_in(executable_lib_path)
                        if executable_cuda_libs:
                            module.warn_in_case_of_duplicates(executable_cuda_libs)
                            return next(iter(executable_cuda_libs))

                    return func(*args, **kwargs)

                return new_determine_cuda_runtime_lib_path

            monkey.patch_function('determine_cuda_runtime_lib_path', fix_determine_cuda_runtime_lib_path, 100)

        with monkey_zoo('bitsandbytes.cextension') as monkey:
            def fix_cextension_not_catching(source, filename):
                return source.replace('except AttributeError as', 'except Exception as')

            monkey.patch_sources(fix_cextension_not_catching, 100)
