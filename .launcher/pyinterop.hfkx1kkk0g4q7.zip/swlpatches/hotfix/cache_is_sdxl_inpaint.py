from functools import wraps
from swlutils.hook import monkey_zoo
from swlutils.funcinspect import FuncArgAnalyzer, FuncArgNotFound


class CacheIsSdxlInpaintHotfix:
    name = "cache_is_sdxl_inpaint"

    def patch(self):
        # since d2ac95fa7b2a8d0bcc5361ee16dba9cbb81ff8b2 Jan 27, 2023
        with monkey_zoo('modules.sd_models') as monkey: 
            def add_is_sdxl_inpaint(func, module):
                sig = FuncArgAnalyzer(func)
                @wraps(func)
                def wrapper(*args, **kwargs):
                    result = func(*args, **kwargs)
                    model = sig.get_arg_value_by_name('model', args, kwargs)
                    state_dict = sig.get_arg_value_by_name('state_dict', args, kwargs)
                    if model is FuncArgNotFound or state_dict is FuncArgNotFound:
                        return result
                    if hasattr(model, 'is_sdxl_inpaint'):
                        return result
                    diffusion_model_input = state_dict.get('diffusion_model.input_blocks.0.0.weight', None)
                    model.is_sdxl_inpaint = (
                        getattr(model, 'is_sdxl', False) and
                        diffusion_model_input is not None and
                        diffusion_model_input.shape[1] == 9
                    )

                return wrapper

            monkey.patch_function('load_model_weights', add_is_sdxl_inpaint)

        # since 9feb034e343d6d7ef63395821658fb3774b30a24 Dec 21, 2023
        with monkey_zoo('modules.processing') as monkey:
            def source_patch(source, filename):
                source = source.replace(
                    """        sd = self.sampler.model_wrap.inner_model.model.state_dict()
        diffusion_model_input = sd.get('diffusion_model.input_blocks.0.0.weight', None)
        if diffusion_model_input is not None:
            if diffusion_model_input.shape[1] == 9:""",
                    """        # sd = self.sampler.model_wrap.inner_model.model.state_dict()
        # diffusion_model_input = sd.get('diffusion_model.input_blocks.0.0.weight', None)
        if True:
            if getattr(self.sampler.model_wrap.inner_model.model, "is_sdxl_inpaint", False):""",
                )
                source = source.replace(
                    """        sd = sd_model.model.state_dict()
        diffusion_model_input = sd.get('diffusion_model.input_blocks.0.0.weight', None)
        if diffusion_model_input is not None:
            if diffusion_model_input.shape[1] == 9:""",
                    """        # sd = sd_model.model.state_dict()
        # diffusion_model_input = sd.get('diffusion_model.input_blocks.0.0.weight', None)
        if True:
            if getattr(sd_model.model, "is_sdxl_inpaint", False):""",
                )
                return source
            monkey.patch_sources(source_patch)

        with monkey_zoo('modules.sd_models_xl') as monkey:
            def source_patch(source, filename):
                source = source.replace(
                    """    sd = self.model.state_dict()
    diffusion_model_input = sd.get('diffusion_model.input_blocks.0.0.weight', None)
    if diffusion_model_input is not None:
        if diffusion_model_input.shape[1] == 9:""",
                    """    # sd = self.model.state_dict()
    # diffusion_model_input = sd.get('diffusion_model.input_blocks.0.0.weight', None)
    if True:
        if self.is_sdxl_inpaint:""",
                )
                return source
            monkey.patch_sources(source_patch)
