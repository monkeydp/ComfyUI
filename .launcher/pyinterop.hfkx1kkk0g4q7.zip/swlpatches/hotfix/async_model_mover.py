from contextlib import contextmanager, nullcontext
from functools import wraps
from swlutils.hook import monkey_zoo


def load_smart_lowvram(module):
    import torch
    from modules import patches, devices

    stream_impl = devices.get_stream_impl()
    stream_wrapper = devices.get_stream_wrapper()

    module.use_streamlined_lowvram = (
        torch.cuda.is_available() and stream_impl is not None and stream_wrapper is not None
    )

    def is_same_device(device1, device2):
        tensor1_device_type = device1.type
        tensor2_device_type = device2.type
        tensor1_device_index = device1.index or 0
        tensor2_device_index = device2.index or 0
        return (
            tensor1_device_type == tensor2_device_type
            and tensor1_device_index == tensor2_device_index
        )

    module.is_same_device = is_same_device

    class RTTensorMoverPatches:
        def __init__(self):
            self.mover_stream = stream_impl(device=devices.device)
            self.calc_stream = stream_impl(device=devices.device)
            self.stash = {}

            self.linear_original = patches.patch(
                __name__,
                torch.nn.functional,
                "linear",
                self._wrapper_default(torch.nn.functional.linear),
            )
            self.conv2d_original = patches.patch(
                __name__,
                torch.nn.functional,
                "conv2d",
                self._wrapper_default(torch.nn.functional.conv2d),
            )
            self.conv3d_original = patches.patch(
                __name__,
                torch.nn.functional,
                "conv3d",
                self._wrapper_default(torch.nn.functional.conv3d),
            )
            self.group_norm_original = patches.patch(
                __name__,
                torch.nn.functional,
                "group_norm",
                self._wrapper_group_norm(torch.nn.functional.group_norm),
            )
            self.layer_norm_original = patches.patch(
                __name__,
                torch.nn.functional,
                "layer_norm",
                self._wrapper_layer_norm(torch.nn.functional.layer_norm),
            )

        @contextmanager
        def wrap_weight_biases(self, input, weight, bias):
            if not is_same_device(input.device, devices.device):
                yield (weight, bias)
                return

            moved = False
            before_calc_event, after_calc_event = None, None
            with stream_wrapper(stream=self.mover_stream):
                if weight is not None and not is_same_device(
                    weight.device, input.device
                ):
                    weight = weight.to(
                        device=input.device, copy=True, non_blocking=weight.is_pinned()
                    )
                    moved = True
                if bias is not None and not is_same_device(bias.device, input.device):
                    bias = bias.to(
                        device=input.device, copy=True, non_blocking=bias.is_pinned()
                    )
                    moved = True
                before_calc_event = self.mover_stream.record_event()

            if not moved:
                yield (weight, bias)
                return

            with stream_wrapper(stream=self.calc_stream):
                if before_calc_event is not None:
                    self.calc_stream.wait_event(before_calc_event)
                yield (weight, bias)
                after_calc_event = self.calc_stream.record_event()
                self.stash[id(after_calc_event)] = (weight, bias, after_calc_event)

            to_remove = []
            for k, (_, _, e) in self.stash.items():
                if e.query():
                    to_remove.append(k)

            for k in to_remove:
                del self.stash[k]

        def _wrapper_default(self, original):
            def wrapper(input, weight, bias=None, *args, **kwargs):
                with self.wrap_weight_biases(input, weight, bias) as (w, b):
                    return original(input, w, b, *args, **kwargs)

            return wrapper

        def _wrapper_group_norm(self, original):
            def wrapper(input, num_groups, weight=None, bias=None, *args, **kwargs):
                with self.wrap_weight_biases(input, weight, bias) as (w, b):
                    return original(input, num_groups, w, b, *args, **kwargs)

            return wrapper

        def _wrapper_layer_norm(self, original):
            def wrapper(input, normalized_shape, weight=None, bias=None, *args, **kwargs):
                with self.wrap_weight_biases(input, weight, bias) as (w, b):
                    return original(input, normalized_shape, w, b, *args, **kwargs)

            return wrapper

        def close(self):
            patches.undo(__name__, torch.nn.functional, "linear")
            patches.undo(__name__, torch.nn.functional, "conv2d")
            patches.undo(__name__, torch.nn.functional, "conv3d")
            patches.undo(__name__, torch.nn.functional, "group_norm")
            patches.undo(__name__, torch.nn.functional, "layer_norm")

    module.rtmover = None
    if module.use_streamlined_lowvram:
        module.rtmover = RTTensorMoverPatches()

    def calc_wrapper():
        if module.rtmover is not None:
            return stream_wrapper(stream=module.rtmover.calc_stream)
        return nullcontext()

    module.calc_wrapper = calc_wrapper

    def calc_sync():
        if module.rtmover is not None:
            return module.rtmover.calc_stream.synchronize()
        return nullcontext()

    module.calc_sync = calc_sync


class AsyncModelMoverHotfix:
    name = "async_model_mover"

    def patch(self):
        with monkey_zoo("modules.devices") as monkey:

            def get_stream_impl_wrapper(func, module):
                def get_stream_impl():
                    if module.torch.cuda.is_available():
                        return module.torch.cuda.Stream
                    if module.has_xpu():
                        return module.torch.xpu.Stream
                    return None

                return get_stream_impl

            def get_stream_wrapper_wrapper(func, module):
                def get_stream_wrapper():
                    if module.torch.cuda.is_available():
                        return module.torch.cuda.stream
                    if module.has_xpu():
                        return module.torch.xpu.stream
                    return None

                return get_stream_wrapper

            monkey.patch_function(
                "get_stream_impl", get_stream_impl_wrapper, add_if_not_exists=True
            )

            monkey.patch_function(
                "get_stream_wrapper", get_stream_wrapper_wrapper, add_if_not_exists=True
            )

        with monkey_zoo("modules.lowvram") as monkey:

            def apply_pin_memory(source, filename):
                source = (
                    source.replace(
                        "diff_model.time_embed.register_forward_pre_hook(send_me_to_gpu)",
                        "diff_model.time_embed._apply(lambda x: x.pin_memory(device=devices.device))",
                    )
                    .replace(
                        " block.register_forward_pre_hook(send_me_to_gpu)",
                        " block._apply(lambda x: x.pin_memory(device=devices.device))",
                    )
                    .replace(
                        "diff_model.middle_block.register_forward_pre_hook(send_me_to_gpu)",
                        "diff_model.middle_block._apply(lambda x: x.pin_memory(device=devices.device))",
                    )
                )
                return source

            monkey.patch_sources(apply_pin_memory)
            monkey.patch_premodule(load_smart_lowvram)

        with monkey_zoo("modules.processing") as monkey:

            def process_images_inner_wrapper(func, module):
                @wraps(func)
                def process_images_inner(*args, **kwargs):
                    from modules import lowvram

                    with lowvram.calc_wrapper():
                        result = func(*args, **kwargs)
                    lowvram.calc_sync()
                    return result

                return process_images_inner

            monkey.patch_function("process_images_inner", process_images_inner_wrapper)

        with monkey_zoo("modules.sd_models") as monkey:
            def apply_pin_memory(source, filename):
                source = (
                    source.replace(
                        "module.to(torch.float8_e4m3fn)",
                        "module.to(torch.float8_e4m3fn)._apply(lambda x: x.pin_memory(device=devices.device) if devices.device.type != 'cpu' and not x.is_sparse and x.device.type == 'cpu' else x)",
                    )
                )
                return source

            monkey.patch_sources(apply_pin_memory)
