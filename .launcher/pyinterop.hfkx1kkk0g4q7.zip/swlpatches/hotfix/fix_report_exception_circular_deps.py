﻿import sys
from functools import wraps
from swlutils.hook import monkey_zoo


class FixReportExceptionCircularDepsHotfix:
    name = 'fix_report_exception_circular_deps'

    def patch(self):
        with monkey_zoo('modules.errors') as monkey:
            def hotfix(func, module):
                if 'format_exception' in module.__dict__:
                    return None

                @wraps(func)
                def wrapper(*args, **kwargs):
                    if 'modules.sysinfo' not in sys.modules:
                        return
                    return func(*args, **kwargs)

                return wrapper

            monkey.patch_function('report_exception', hotfix)
