import sys
from functools import wraps
from swlutils.hook import monkey_zoo
from inspect import signature


class ExtensionInstalledByNameHotfix:
    name = 'extension_installed_by_name'

    def patch(self):
        with monkey_zoo('modules.ui_extensions') as monkey:
            def hotfix(func, module):
                if func is not None:
                    return None

                if 'normalize_git_url' not in module.__dict__:
                    return None

                def get_extension_dirname_from_url(url):
                    *parts, last_part = url.split('/')
                    return module.normalize_git_url(last_part)

                return get_extension_dirname_from_url
            monkey.patch_function('get_extension_dirname_from_url', hotfix, add_if_not_exists=True)

            def source_patch(source, filename):
                source = source.replace('installed_extension_urls = {normalize_git_url(extension.remote): extension.name for extension in extensions.extensions}', 'installed_extensions = {extension.name for extension in extensions.extensions}; installed_extensions_urls = {normalize_git_url(extension.remote) for extension in extensions.extensions}')
                source = source.replace('existing = installed_extension_urls.get(normalize_git_url(url), None)', 'existing = get_extension_dirname_from_url(url) in installed_extensions or normalize_git_url(url) in installed_extensions_urls')
                source = source.replace('installed = get_installed(ext)', 'installed = ext.name in {extension.name for extension in extensions.extensions} or (ext.remote is not None and ext.remote in {normalize_git_url(extension.remote) for extension in extensions.extensions})')
                return source

            monkey.patch_sources(source_patch)
