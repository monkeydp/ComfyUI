﻿import sys
from functools import wraps
from swlutils.hook import monkey_zoo
from inspect import signature


def get_free_memory(dev, module):
    if not hasattr(dev, 'type'):
        return 0, 0
    
    dev_index = 0 if not hasattr(dev, 'index') else dev.index
    if dev.type == 'cpu' or dev.type == 'mps':
        import psutil
        mem_free_total = psutil.virtual_memory().available
        mem_free_torch = mem_free_total
    else:
        if dev.type == 'cuda':
            stats = module.torch.cuda.memory_stats(dev_index)
            mem_active = stats['active_bytes.all.current']
            mem_reserved = stats['reserved_bytes.all.current']
            mem_free_cuda, _ = module.torch.cuda.mem_get_info(dev_index)
            mem_free_torch = mem_reserved - mem_active
            mem_free_total = mem_free_cuda + mem_free_torch
        elif dev.type == 'xpu':
            stats = module.torch.xpu.memory_stats(dev_index)
            mem_active = stats['active_bytes.all.current']
            mem_allocated = stats['allocated_bytes.all.current']
            mem_reserved = stats['reserved_bytes.all.current']
            mem_free_torch = mem_reserved - mem_active
            mem_free_total = module.torch.xpu.get_device_properties(dev_index).total_memory - mem_allocated
        else:
            return 0, 0

    return (mem_free_total, mem_free_torch)


def calculate_module_memory_usage(module):
    """calculate the memory usage of a module and its children"""
    return sum(p.numel() * p.element_size() for p in module.parameters())


def test_medvram(model, module):
    if module.devices.device == module.devices.cpu:
        return False
    model_size = calculate_module_memory_usage(model)
    mem_dev, _ = get_free_memory(module.devices.device, module)
    print(f"Medvram Eval: Model size: {model_size}, Device memory: {mem_dev}")
    # mem_cpu, _ = get_free_memory(module.devices.cpu, module)
    return model_size > mem_dev


def test_lowvram(model, module):
    if module.devices.device == module.devices.cpu:
        return False
    model_size = calculate_module_memory_usage(model.model.diffusion_model)
    mem_dev, _ = get_free_memory(module.devices.device, module)
    print(f"Lowvram Eval: Model size: {model_size}, Device memory: {mem_dev}")
    # mem_cpu, _ = get_free_memory(module.devices.cpu, module)
    return model_size > mem_dev


class AutoLowvramHotfix:
    name = 'auto_lowvram'

    def patch(self):
        with monkey_zoo('modules.lowvram') as monkey:
            def patch_isneeded_factory(func, module):
                def is_needed(sd_model):
                    return test_medvram(sd_model, module)
                return is_needed
            monkey.patch_function('is_needed', patch_isneeded_factory)
            
            def patch_apply(func, module):
                def apply(sd_model):
                    medvram_needed = test_medvram(sd_model, module)
                    lowvram_needed = test_lowvram(sd_model, module)
                    module.shared.parallel_processing_allowed = not medvram_needed
                    module.shared.cmd_opts.medvram = medvram_needed
                    module.shared.cmd_opts.lowvram = lowvram_needed
                
                    if medvram_needed:
                        module.setup_for_low_vram(sd_model, not lowvram_needed)
                    else:
                        sd_model.lowvram = False
                return apply
            monkey.patch_function('apply', patch_apply)
