﻿import sys
from functools import wraps
from swlutils.hook import monkey_zoo


class IpexMemAllocSlicingHotFix:
    name = 'ipex_mem_alloc_slicing'

    def patch(self):
        with monkey_zoo('torch.nn.functional') as monkey:
            def hotfix(func, module):
                torch = getattr(module, 'torch', sys.modules['torch'])

                # Splitting SDP attention calculation to smaller chunks
                # Heuristic (VRAM / 8) is tuned for A770 16G and A750 8G
                # ARC_SINGLE_ALLOCATION_LIMIT = min(torch.xpu.get_device_properties(module.shared.cmd_opts.device_id).total_memory // 8, 2 ** 32)
                SINGLE_ALLOCATION_LIMIT = {}

                @wraps(func)
                def torch_xpu_scaled_dot_product_attention(
                    query, key, value, attn_mask=None, dropout_p=0.0, is_causal=False, *args, **kwargs
                ):
                    if query.device.type != 'xpu':
                        return func(query, key, value, attn_mask=attn_mask, dropout_p=dropout_p, is_causal=is_causal, *args, **kwargs)

                    if query.device.index not in SINGLE_ALLOCATION_LIMIT:
                        SINGLE_ALLOCATION_LIMIT[query.device.index] = min(torch.xpu.get_device_properties(query.device.index).total_memory // 8, 2 ** 32 - 1)

                    single_allocation_limit = SINGLE_ALLOCATION_LIMIT[query.device.index]

                    # cast to same dtype first
                    key = key.to(query.dtype)
                    value = value.to(query.dtype)
                    if attn_mask is not None and attn_mask.dtype != torch.bool:
                        attn_mask = attn_mask.to(query.dtype)

                    N = query.shape[:-2]  # Batch size
                    L = query.size(-2)  # Target sequence length
                    E = query.size(-1)  # Embedding dimension of the query and key
                    S = key.size(-2)  # Source sequence length
                    Ev = value.size(-1)  # Embedding dimension of the value

                    total_batch_size = torch.numel(torch.empty(N))
                    batch_size_limit = max(1, single_allocation_limit // (L * S * query.element_size()))

                    if total_batch_size <= batch_size_limit:
                        return func(
                            query,
                            key,
                            value,
                            attn_mask=attn_mask,
                            dropout_p=dropout_p,
                            is_causal=is_causal,
                            *args, **kwargs
                        )

                    query = torch.reshape(query, (-1, L, E))
                    key = torch.reshape(key, (-1, S, E))
                    value = torch.reshape(value, (-1, S, Ev))
                    if attn_mask is not None:
                        attn_mask = attn_mask.view(-1, L, S)
                    chunk_count = (total_batch_size + batch_size_limit - 1) // batch_size_limit
                    outputs = []
                    for i in range(chunk_count):
                        attn_mask_chunk = (
                            None
                            if attn_mask is None
                            else attn_mask[i * batch_size_limit: (i + 1) * batch_size_limit, :, :]
                        )
                        chunk_output = func(
                            query[i * batch_size_limit: (i + 1) * batch_size_limit, :, :],
                            key[i * batch_size_limit: (i + 1) * batch_size_limit, :, :],
                            value[i * batch_size_limit: (i + 1) * batch_size_limit, :, :],
                            attn_mask=attn_mask_chunk,
                            dropout_p=dropout_p,
                            is_causal=is_causal,
                            *args, **kwargs
                        )
                        outputs.append(chunk_output)
                    result = torch.cat(outputs, dim=0)
                    return torch.reshape(result, (*N, L, Ev))

                return torch_xpu_scaled_dot_product_attention

            monkey.patch_function('scaled_dot_product_attention', hotfix)
