from functools import wraps
from swlutils.hook import monkey_zoo

class IpexAntialiasInterpolateHotFix:
    name = 'ipex_antialias_interpolate'

    def patch(self):
        with monkey_zoo('torch.nn.functional') as monkey:
            def wrap_interpolate(func, module):
                @wraps(func)
                def wrapper(input, size=None, scale_factor=None, mode='nearest', align_corners=None, recompute_scale_factor=None, antialias=False):
                    # xpu doesn't support 'aten::_upsample_bicubic2d_aa.out' or 'aten::_upsample_bilinear2d_aa.out'
                    # https://github.com/intel/intel-extension-for-pytorch/issues/705
                    if input.device.type == 'xpu' and antialias and mode in ['bicubic', 'bilinear']:
                        orig_dtype = input.dtype
                        orig_device = input.device
                        res = func(input.float().cpu(), size=size, scale_factor=scale_factor, mode=mode, align_corners=align_corners, recompute_scale_factor=recompute_scale_factor, antialias=False).to(orig_dtype).to(orig_device)
                        print(f"Upsample with antialiasing is not supported on XPU, falling back to CPU")
                        return res
                    return func(input, size=size, scale_factor=scale_factor, mode=mode, align_corners=align_corners, recompute_scale_factor=recompute_scale_factor, antialias=antialias)
                return wrapper
            monkey.patch_function('interpolate', wrap_interpolate)
