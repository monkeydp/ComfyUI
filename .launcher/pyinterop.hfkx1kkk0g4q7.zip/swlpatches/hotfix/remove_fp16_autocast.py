from swlutils.hook import monkey_zoo
import sys
import contextlib


def is_strict_fp16(module):
    if hasattr(module, "dtype") and module.dtype != module.torch.float16:
        return False
    if hasattr(module, "dtype_vae") and module.dtype_vae != module.torch.float16:
        return False
    if hasattr(module, "dtype_unet") and module.dtype_unet != module.torch.float16:
        return False
    if hasattr(module, "dtype_inference") and module.dtype_inference != module.torch.float16:
        return False
    return True


def patch_apply_model(orig_func, module):
    def apply_model(self, x_noisy, t, cond, **kwargs):
        """Always make sure inputs to unet are in correct dtype."""
        devices = sys.modules.get("modules.devices", None)
        torch = sys.modules.get("torch", None)
        if devices is not None and torch is not None and hasattr(devices, "dtype_unet"):
            if isinstance(cond, dict):
                for y in cond.keys():
                    if isinstance(cond[y], list):
                        cond[y] = [
                            x.to(devices.dtype_unet) if isinstance(x, torch.Tensor) else x
                            for x in cond[y]
                        ]
                    else:
                        cond[y] = (
                            cond[y].to(devices.dtype_unet)
                            if isinstance(cond[y], torch.Tensor)
                            else cond[y]
                        )

            with devices.autocast():
                result = orig_func(
                    self,
                    x_noisy.to(devices.dtype_unet),
                    t.to(devices.dtype_unet),
                    cond,
                    **kwargs
                )
                if getattr(devices, "unet_need_upcast", False):
                    return result.float()
                else:
                    return result
        else:
            return orig_func(self, x_noisy, t, cond, **kwargs)
    return apply_model


class RemoveFp16AutocastHotfix:
    name = "remove_fp16_autocast"

    def patch(self):
        with monkey_zoo("modules.devices") as monkey:
            def patch_cond_cast_unet(func, module):
                def wrapper(input, *args, **kwargs):
                    if (
                        input.dtype != module.torch.float16
                        and getattr(module, "dtype_unet", module.dtype) == module.torch.float16
                        and not getattr(module, 'unet_need_upcast', False)
                    ):
                        return input.to(module.torch.float16)
                    return func(input, *args, **kwargs)
                return wrapper
            monkey.patch_function("cond_cast_unet", patch_cond_cast_unet)

            def patch_autocast(func, module):
                def wrapper(*args, **kwargs):
                    if is_strict_fp16(module):
                        return contextlib.nullcontext()
                    return func(*args, **kwargs)
                return wrapper

            monkey.patch_function("autocast", patch_autocast)

        with monkey_zoo("modules.shared_init") as monkey:
            def patch_sgm_ldm(func, module):
                def wrapper(*args, **kwargs):
                    result = func(*args, **kwargs)
                    devices = sys.modules.get("modules.devices", None)
                    torch = sys.modules.get("torch", None)
                    if devices is not None and torch is not None and is_strict_fp16(devices):
                        import sgm.modules.diffusionmodules.util as sgm_util
                        import ldm.modules.diffusionmodules.util as ldm_util
                        sgm_util.GroupNorm32 = torch.nn.GroupNorm
                        ldm_util.GroupNorm32 = torch.nn.GroupNorm
                return wrapper
            monkey.patch_function("initialize", patch_sgm_ldm)

        with monkey_zoo("modules.sd_models") as monkey:
            def patch_repair_config(func, module):
                def wrapper(sd_config, *args, **kwargs):
                    result = func(sd_config, *args, **kwargs)
                    devices = sys.modules.get("modules.devices", None)
                    if devices is not None and is_strict_fp16(devices) and hasattr(sd_config.model.params, 'unet_config'):
                        sd_config.model.params.unet_config.params.use_fp16 = True
                    return result
                return wrapper
            monkey.patch_function("repair_config", patch_repair_config)

        with monkey_zoo('ldm.modules.diffusionmodules.util') as monkey:
            def patch_timestep_embedding(func, module):
                def wrapper_timestep_embedding(timesteps, *args, **kwargs):
                    result = func(timesteps, *args, **kwargs)
                    torch = sys.modules.get("torch", None)
                    devices = sys.modules.get("modules.devices", None)
                    if devices is not None and torch is not None and hasattr(devices, "dtype_unet"): 
                        if getattr(devices, 'unet_need_upcast', False) and timesteps.dtype == module.torch.int64:
                            return result.to(torch.float32)
                        return result.to(devices.dtype_unet)
                    return result
                return wrapper_timestep_embedding
            monkey.patch_function("timestep_embedding", patch_timestep_embedding)

        with monkey_zoo('sgm.modules.diffusionmodules.util') as monkey:
            def patch_timestep_embedding(func, module):
                def wrapper_timestep_embedding(timesteps, *args, **kwargs):
                    result = func(timesteps, *args, **kwargs)
                    torch = sys.modules.get("torch", None)
                    devices = sys.modules.get("modules.devices", None)
                    if (
                        devices is not None
                        and torch is not None
                        and hasattr(devices, "dtype_unet")
                    ):
                        if (
                            getattr(devices, "unet_need_upcast", False)
                            and timesteps.dtype == module.torch.int64
                        ):
                            return result.to(torch.float32)
                        return result.to(devices.dtype_unet)
                    return result
                return wrapper_timestep_embedding
            monkey.patch_function("timestep_embedding", patch_timestep_embedding)

        with monkey_zoo('ldm.models.diffusion.ddpm') as monkey:
            def patch_fix_dtype(module):
                if hasattr(module, "LatentDiffusion"):
                    if hasattr(module.LatentDiffusion, "apply_model"):
                        module.LatentDiffusion.apply_model = patch_apply_model(module.LatentDiffusion.apply_model, module)
            monkey.patch_module(patch_fix_dtype)

        with monkey_zoo("sgm.modules.diffusionmodules.wrappers") as monkey:
            def patch_fix_dtype(module):
                if hasattr(module, "OpenAIWrapper"):
                    if hasattr(module.OpenAIWrapper, "apply_model"):
                        module.OpenAIWrapper.apply_model = patch_apply_model(
                            module.OpenAIWrapper.apply_model, module
                        )
            monkey.patch_module(patch_fix_dtype)

        with monkey_zoo("modules.models.diffusion.ddpm_edit") as monkey:
            def patch_fix_dtype(module):
                if hasattr(module, "LatentDiffusion"):
                    if hasattr(module.LatentDiffusion, "apply_model"):
                        module.LatentDiffusion.apply_model = patch_apply_model(
                            module.LatentDiffusion.apply_model, module
                        )
            monkey.patch_module(patch_fix_dtype)
