from swlutils.hook import monkey_zoo


class TorchZludaTimerHotfix:
    name = 'torch_zluda_timer'

    def patch(self):
        with monkey_zoo("torch.utils.cpp_extension") as monkey:
            def zluda_patch(source, filename):
                source = source.replace(
                    "HIP_HOME = _join_rocm_home('hip') if ROCM_HOME else None",
                    'HIP_HOME = ROCM_HOME',
                )
                source = source.replace(
"""    elif IS_WINDOWS:
        raise""", 
"""    elif IS_WINDOWS and False:
        raise""")
                return source
            monkey.patch_sources(zluda_patch)
