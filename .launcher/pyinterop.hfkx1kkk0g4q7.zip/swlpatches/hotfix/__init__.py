from swlutils.exception import capture_exception
from .torch2x_unpickle_new_meta import Torch2xUnpickleNewMetaPatch
from .bitsandbytes_cudasetup import BitsAndBytesCudaSetupHotfix
from .gradio_client_dataset import GradioClientDatasetHotfix
from .lcm_sampler import LCMSamplerHotfix
from .fix_report_exception_circular_deps import FixReportExceptionCircularDepsHotfix
from .extension_installed_by_name import ExtensionInstalledByNameHotfix
from .disable_initialization_ref_comparison import DisableInitializationRefComparisonHotFix
from .ipex_mem_alloc_slicing import IpexMemAllocSlicingHotFix
from .ipex_antialias_interpolate import IpexAntialiasInterpolateHotFix
from .fix_float64_model import FixFloat64ModelHotfix
from .auto_lowvram import AutoLowvramHotfix
from .async_model_mover import AsyncModelMoverHotfix
from .torch_zluda_timer import TorchZludaTimerHotfix
from .rearrange_accelerate import RearrangeAccelerateHotfix
from .disable_ldm_checkpointing import DisableLDMCheckpointingHotfix
from .cache_is_sdxl_inpaint import CacheIsSdxlInpaintHotfix
from .prevent_extra_bias_backup import PreventExtraBiasBackupHotfix
from .remove_fp16_autocast import RemoveFp16AutocastHotfix
from .fix_timestep_device import FixTimestepDeviceHotfix
from .unblock_live_preview import UnblockLivePreviewHotfix
from .disable_google_blockly import DisableGoogleBlocklyHotfix
from .einx_register import EinxRegisterHotfix

ACTIVE_PATCHES = [
    Torch2xUnpickleNewMetaPatch(),
    BitsAndBytesCudaSetupHotfix(),
    GradioClientDatasetHotfix(),
    LCMSamplerHotfix(),
    FixReportExceptionCircularDepsHotfix(),
    DisableInitializationRefComparisonHotFix(),
    ExtensionInstalledByNameHotfix(),
    IpexMemAllocSlicingHotFix(),
    IpexAntialiasInterpolateHotFix(),
    FixFloat64ModelHotfix(),
    AutoLowvramHotfix(),
    AsyncModelMoverHotfix(),
    TorchZludaTimerHotfix(),
    RearrangeAccelerateHotfix(),
    DisableLDMCheckpointingHotfix(),
    CacheIsSdxlInpaintHotfix(),
    PreventExtraBiasBackupHotfix(),
    RemoveFp16AutocastHotfix(),
    FixTimestepDeviceHotfix(),
    UnblockLivePreviewHotfix(),
    DisableGoogleBlocklyHotfix(),
    EinxRegisterHotfix(),
]


def patch(enabled_hotfixes):
    enabled_hotfixes = set(enabled_hotfixes)
    for p in ACTIVE_PATCHES:
        if p.name in enabled_hotfixes:
            try:
                p.patch()
            except Exception:
                capture_exception()
