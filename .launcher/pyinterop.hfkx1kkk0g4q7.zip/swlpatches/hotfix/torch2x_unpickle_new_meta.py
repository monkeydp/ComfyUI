﻿# https://github.com/continue-revolution/sd-webui-animatediff/issues/313

import ast
from swlutils.hook import monkey_zoo


class Torch2xUnpickleNewMetaPatch:
    name = 'torch2x_unpickle_new_meta'

    def patch(self):
        with monkey_zoo('modules.safe') as monkey:
            def safe_pickler_patch(code_object):
                code_object.co_consts.replace_primitive(r"^([^/]+)/((data/\d+)|version|(data\.pkl))$",
                                              r"^([^/]+)/((data/\d+)|version|(data\.pkl)|byteorder|\.data/serialization_id)$")
            monkey.patch_bytecode(safe_pickler_patch)
