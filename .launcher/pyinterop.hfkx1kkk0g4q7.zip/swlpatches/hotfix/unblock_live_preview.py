from functools import wraps
from swlutils.hook import monkey_zoo
from contextlib import nullcontext


class UnblockLivePreviewHotfix:
    name = "unblock_live_preview"

    def patch(self):
        with monkey_zoo("modules.sd_samplers_common") as monkey:

            def premodule(module):
                module.lp_stream = None
                module.live_preview_stream_context = nullcontext()
            monkey.patch_premodule(premodule)

            def patch_single_sample_to_image(func, module):
                @wraps(func)
                def wrapper(sample, approximation=None, *args, **kwargs):
                    x_sample = module.samples_to_images_tensor(sample.unsqueeze(0), approximation)[0] * 0.5 + 0.5
                    x_sample = module.torch.clamp(x_sample, min=0.0, max=1.0)
                    x_sample = 255. * x_sample.permute(1, 2, 0)
                    return x_sample.to(device='cpu', dtype=module.torch.uint8, non_blocking=True)
                return wrapper
            monkey.patch_function("single_sample_to_image", patch_single_sample_to_image)

            def patch_sample_to_image(func, module):
                @wraps(func)
                def wrapper(*args, **kwargs):
                    with module.live_preview_stream_context:
                        result = func(*args, **kwargs)
                    if module.lp_stream is not None:
                        module.lp_stream.synchronize()
                    return module.Image.fromarray(result.numpy())
                return wrapper
            monkey.patch_function("sample_to_image", patch_sample_to_image)

            def patch_samples_to_image_grid(func, module):
                @wraps(func)
                def wrapper(samples, approximation=None, *args, **kwargs):
                    with module.live_preview_stream_context:
                        sample_tensors = [
                            module.single_sample_to_image(
                                sample,
                                approximation,
                                non_blocking=module.lp_stream is not None,
                            )
                            for sample in samples
                        ]
                    if module.lp_stream is not None:
                        module.lp_stream.synchronize()
                    return module.images.image_grid(
                        [
                            module.Image.fromarray(sample.numpy())
                            for sample in sample_tensors
                        ]
                    )
                return wrapper
            monkey.patch_function("samples_to_image_grid", patch_samples_to_image_grid)

            def postmodule(module):
                if module.torch.cuda.is_available():
                    module.lp_stream = module.torch.cuda.Stream()
                    module.live_preview_stream_context = module.torch.cuda.stream(
                        module.lp_stream
                    )
            monkey.patch_module(postmodule)

        with monkey_zoo("modules.sd_samplers") as monkey:
            def patch_monkey(module):
                module.samples_to_image_grid = module.sd_samplers_common.samples_to_image_grid
                module.sample_to_image = module.sd_samplers_common.sample_to_image
            monkey.patch_module(patch_monkey)
