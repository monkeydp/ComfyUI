from swlutils.hook import monkey_zoo


class DisableLDMCheckpointingHotfix:
    name = "disable_ldm_checkpointing"

    def patch(self):
        with monkey_zoo("ldm.modules.attention") as monkey:
            def unwrap_checkpointing(module):
                if hasattr(module, "BasicTransformerBlock"):
                    if hasattr(module.BasicTransformerBlock, "_forward"):
                        module.BasicTransformerBlock.forward = module.BasicTransformerBlock._forward
            monkey.patch_module(unwrap_checkpointing)

        with monkey_zoo("ldm.modules.diffusionmodules.openaimodel") as monkey:
            def unwrap_checkpointing(module):
                if hasattr(module, "ResBlock"):
                    if hasattr(module.ResBlock, "_forward"):
                        module.ResBlock.forward = module.ResBlock._forward
                if hasattr(module, "AttentionBlock"):
                    if hasattr(module.AttentionBlock, "_forward"):
                        module.AttentionBlock.forward = module.AttentionBlock._forward
            monkey.patch_module(unwrap_checkpointing)
