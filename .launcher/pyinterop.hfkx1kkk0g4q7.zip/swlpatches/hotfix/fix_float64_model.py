﻿from functools import wraps
from swlutils.hook import monkey_zoo


class FixFloat64ModelHotfix:
    name = 'fix_float64_model'

    def patch(self):
        with monkey_zoo('modules.sd_models') as monkey:
            def hotfix(func, module):
                @wraps(func)
                def wrapper(*args, **kwargs):
                    pl_sd = func(*args, **kwargs)
                    for k, v in pl_sd.items():
                        if not isinstance(v, module.torch.Tensor):
                            continue
                        if hasattr(v.device, 'type') and v.device.type != 'cpu':
                            continue
                        if v.dtype != module.torch.float64:
                            continue
                        pl_sd[k] = v.float()
                    return pl_sd
                return wrapper
            monkey.patch_function('get_state_dict_from_checkpoint', hotfix)
