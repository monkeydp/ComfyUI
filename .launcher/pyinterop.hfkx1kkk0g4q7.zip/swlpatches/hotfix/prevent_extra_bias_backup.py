from swlutils.hook import monkey_zoo


class PreventExtraBiasBackupHotfix:
    name = "prevent_extra_bias_backup"

    def patch(self):
        with monkey_zoo("extensions-builtin.Lora.networks") as monkey:
            def source_patch(source, filename):
                source = source.replace(
                    "if bias_backup is None:",
                    "if bias_backup is None and wanted_names != ():",
                )
                return source

            monkey.patch_sources(source_patch)
