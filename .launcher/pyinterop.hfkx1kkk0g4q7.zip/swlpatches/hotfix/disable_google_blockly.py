import functools
from swlutils.hook import monkey_zoo


class DisableGoogleBlocklyHotfix:
    name = 'disable_google_blockly'

    def patch(self):
        with monkey_zoo('modules_forge.google_blockly') as monkey:
            def _hook_initialization(func, module):
                @functools.wraps(func)
                def _wrapper(*args, **kwargs):
                    print("Google Blockly Modules Disabled")
                    return
                return _wrapper
            monkey.patch_function('initialization', _hook_initialization)
