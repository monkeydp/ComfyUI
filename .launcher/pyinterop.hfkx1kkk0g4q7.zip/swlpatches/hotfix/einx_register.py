﻿import sys
from swlutils.hook import monkey_zoo


class EinxRegisterHotfix:
    name = 'einx_register'

    def patch(self):
        source_snippet_from_1 = """
def register_for_module(module_name, backend_factory):
    with lock:
        if module_name in sys.modules:
            # Module is already imported -> create backend now
            register(backend_factory())
        else:
            # Module is not yet imported -> register factory
            if not module_name in backend_factories:
                backend_factories[module_name] = []
            backend_factories[module_name].append(backend_factory)
"""

        source_snippet_to_1 = """
def register_for_module(module_name, backend_factory):
    with lock:
        if module_name in sys.modules:
            if sys.modules[module_name] is None:
                return
            # Module is already imported -> create backend now
            try:
                register(backend_factory())
            except Exception as e:
                print(f"Error while registering backend for module {module_name}: {e}")
        else:
            # Module is not yet imported -> register factory
            if not module_name in backend_factories:
                backend_factories[module_name] = []
            backend_factories[module_name].append(backend_factory)
"""

        source_snippet_from_2 = """
def _update():
    for module_name in list(backend_factories.keys()):
        if module_name in sys.modules:
            for factory in list(backend_factories[module_name]):
                register(factory())
            del backend_factories[module_name]
"""

        source_snippet_to_2 = """
def _update():
    for module_name in list(backend_factories.keys()):
        if module_name in sys.modules:
            if sys.modules[module_name] is None:
                continue
            for factory in list(backend_factories[module_name]):
                try:
                    register(factory())
                except Exception as e:
                    print(f"Error while registering backend for module {module_name}: {e}")
            del backend_factories[module_name]
"""
        
        
        with monkey_zoo('einx.backend.register') as monkey:
            def source_patch(source, filename):
                source = source.replace(source_snippet_from_1, source_snippet_to_1)
                source = source.replace(source_snippet_from_2, source_snippet_to_2)
                return source

            monkey.patch_sources(source_patch)
