﻿from swlutils.hook import monkey_zoo


class GradioClientDatasetHotfix:
    name = 'gradio_client_dataset'

    def patch(self):
        with monkey_zoo('gradio_client.serializing') as monkey:
            def hotfix(seri):
                if 'COMPONENT_MAPPING' not in seri.__dict__:
                    return
                if 'StringSerializable' not in seri.__dict__:
                    return
                if 'dataset' in seri.COMPONENT_MAPPING:
                    return
                seri.COMPONENT_MAPPING['dataset'] = seri.StringSerializable

            monkey.patch_module(hotfix)
