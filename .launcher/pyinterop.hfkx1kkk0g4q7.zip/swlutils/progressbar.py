import struct
from threading import Thread
from queue import Queue
from swlutils.ipc import encode_7bit_string
from swlutils.exception import capture_exception
from swlutils.throttle import throttle


class ProgressBarManagerInternal(Thread):
    def __init__(self, pipe):
        super().__init__()
        self.pipe = pipe
        self.daemon = True
        self.queue = Queue()

    @classmethod
    def from_comm_manager(cls, comm_manager):
        try:
            progress_manager_pipe = comm_manager.acquire("2BC170FF-441F-4620-BAAB-44A470E3CAB6")
            progress_manager = cls(progress_manager_pipe)
            return progress_manager
        except Exception:
            capture_exception()
            return None

    def set_progress(self, pid, indeterminate=False, maxp=0, name=None):
        msg = struct.pack('<HQ?d', 1, pid, indeterminate, maxp or 0) + encode_7bit_string(name)
        self.pipe.write(msg)

    def remove_progress(self, pid):
        msg = struct.pack('<HQ', 2, pid)
        self.pipe.write(msg)

    def set_left_text(self, pid, text=None):
        msg = struct.pack('<HQ', 3, pid) + encode_7bit_string(text)
        self.pipe.write(msg)

    def set_right_text(self, pid, text=None):
        msg = struct.pack('<HQ', 4, pid) + encode_7bit_string(text)
        self.pipe.write(msg)

    def set_progress_value(self, pid, value):
        msg = struct.pack('<HQd', 5, pid, value)
        self.pipe.write(msg)

    def run(self):
        while True:
            try:
                fn_name, *args = self.queue.get(block=True)
                if fn_name in ['set_progress', 'remove_progress', 'set_left_text', 'set_right_text',
                               'set_progress_value']:
                    getattr(self, fn_name)(*args)
                self.queue.task_done()
            except Exception:
                capture_exception()
                pass


class ProgressBarManager:
    def __init__(self, internal):
        internal.start()
        self.internal = internal

    @classmethod
    def from_comm_manager(cls, comm_manager):
        internal = ProgressBarManagerInternal.from_comm_manager(comm_manager)
        return cls(internal)

    def set_progress(self, pid, indeterminate=False, maxp=0, name=None):
        self.internal.queue.put(('set_progress', pid, indeterminate, maxp, name))

    def remove_progress(self, pid):
        self.internal.queue.put(('remove_progress', pid))

    def set_left_text(self, pid, text=None):
        self.internal.queue.put(('set_left_text', pid, text))

    @throttle(interval=200, key='pid')
    def set_right_text(self, pid, text=None):
        self.internal.queue.put(('set_right_text', pid, text))

    @throttle(interval=50, key='pid')
    def set_progress_value(self, pid, value):
        self.internal.queue.put(('set_progress_value', pid, value))


class Progress:
    manager = None

    def __init__(self, name, max_value=100, *, indeterminate=None):
        self._name = name
        self._max = max_value if max_value is not None else 0
        if indeterminate is None:
            self._indeterminate = False if max_value is not None else True
        else:
            self._indeterminate = indeterminate
        self._left = None
        self._right = None
        self._value = 0

    def __enter__(self):
        if self.manager is None:
            return self
        try:
            self.manager.set_progress(id(self), self._indeterminate, self._max, self.name)
        except Exception:
            capture_exception()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.manager is None:
            return
        try:
            self.manager.remove_progress(id(self))
        except Exception:
            capture_exception()

    @property
    def name(self):
        return self._name

    @name.setter
    def name(self, value):
        self._name = value
        if self.manager is None:
            return
        try:
            self.manager.set_progress(id(self), self._indeterminate, self._max, self._name)
        except Exception:
            capture_exception()
            pass

    @property
    def max(self):
        return self._max

    @max.setter
    def max(self, value):
        self._max = value
        if self.manager is None:
            return
        try:
            self.manager.set_progress(id(self), self._indeterminate, self._max, self._name)
        except Exception:
            capture_exception()
            pass

    @property
    def indeterminate(self):
        return self._indeterminate

    @indeterminate.setter
    def indeterminate(self, value):
        self._indeterminate = value
        if self.manager is None:
            return
        try:
            self.manager.set_progress(id(self), self._indeterminate, self._max, self._name)
        except Exception:
            capture_exception()

    @property
    def left(self):
        return self._left

    @left.setter
    def left(self, value):
        self._left = value
        if self.manager is None:
            return
        try:
            self.manager.set_left_text(id(self), self._left)
        except Exception:
            capture_exception()

    @property
    def right(self):
        return self._right

    @right.setter
    def right(self, value):
        self._right = value
        if self.manager is None:
            return
        try:
            self.manager.set_right_text(id(self), self._right)
        except Exception:
            capture_exception()

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        self._value = value
        if self.manager is None:
            return
        try:
            self.manager.set_progress_value(id(self), self._value)
        except Exception:
            capture_exception()
