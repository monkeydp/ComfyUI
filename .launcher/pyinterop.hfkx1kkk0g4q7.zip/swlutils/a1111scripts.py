import functools
from .hook import monkey_zoo


injected = False
preinstalled_callbacks = list()


def install():
    global injected, preinstalled_callbacks

    def install_preinstalled_callbacks(script_callbacks):
        global injected, preinstalled_callbacks

        def install_ee_callbacks():
            global injected, preinstalled_callbacks
            for (callback_name, callback, name) in preinstalled_callbacks:
                if callback_name in script_callbacks.callback_map:
                    filename = name if name is not None else "launcher enhanced experience"
                    script_callbacks.callback_map[callback_name].append(
                        script_callbacks.ScriptCallback(filename, callback))
            injected = True

        old_clear_callbacks = script_callbacks.__dict__.get('clear_callbacks', None)

        if old_clear_callbacks is not None:
            @functools.wraps(old_clear_callbacks)
            def new_clear_callbacks():
                old_clear_callbacks()
                install_ee_callbacks()

            script_callbacks.__dict__['clear_callbacks'] = new_clear_callbacks

        install_ee_callbacks()
    with monkey_zoo('modules.script_callbacks') as monkey:
        monkey.patch_module(install_preinstalled_callbacks)


def add_callback(callback_name, callback, name=None):
    global injected, preinstalled_callbacks
    if injected:
        from modules.script_callbacks import callback_map, ScriptCallback
        # vendor_add_callback(callback_map[callback_name], callback)
        if callback_name in callback_map:
            filename = name if name is not None else "launcher enhanced experience"
            callback_map[callback_name].append(ScriptCallback(filename, callback))

    preinstalled_callbacks.append((callback_name, callback, name))


def on_app_started(callback, name=None):
    """register a function to be called when the webui started, the gradio `Block` component and
    fastapi `FastAPI` object are passed as the arguments"""
    add_callback('callbacks_app_started', callback, name)


def on_before_reload(callback, name=None):
    """register a function to be called just before the server reloads."""
    add_callback('callbacks_on_reload', callback, name)


def on_model_loaded(callback, name=None):
    """register a function to be called when the stable diffusion model is created; the model is
    passed as an argument; this function is also called when the script is reloaded. """
    add_callback('callbacks_model_loaded', callback, name)


def on_ui_tabs(callback, name=None):
    """register a function to be called when the UI is creating new tabs.
    The function must either return a None, which means no new tabs to be added, or a list, where
    each element is a tuple:
        (gradio_component, title, elem_id)

    gradio_component is a gradio component to be used for contents of the tab (usually gr.Blocks)
    title is tab text displayed to user in the UI
    elem_id is HTML id for the tab
    """
    add_callback('callbacks_ui_tabs', callback, name)


def on_ui_train_tabs(callback, name=None):
    """register a function to be called when the UI is creating new tabs for the train tab.
    Create your new tabs with gr.Tab.
    """
    add_callback('callbacks_ui_train_tabs', callback, name)


def on_ui_settings(callback, name=None):
    """register a function to be called before UI settings are populated; add your settings
    by using shared.opts.add_option(shared.OptionInfo(...)) """
    add_callback('callbacks_ui_settings', callback, name)


def on_before_image_saved(callback, name=None):
    """register a function to be called before an image is saved to a file.
    The callback is called with one argument:
        - params: ImageSaveParams - parameters the image is to be saved with. You can change fields in this object.
    """
    add_callback('callbacks_before_image_saved', callback, name)


def on_image_saved(callback, name=None):
    """register a function to be called after an image is saved to a file.
    The callback is called with one argument:
        - params: ImageSaveParams - parameters the image was saved with. Changing fields in this object does nothing.
    """
    add_callback('callbacks_image_saved', callback, name)


def on_cfg_denoiser(callback, name=None):
    """register a function to be called in the kdiffussion cfg_denoiser method after building the inner model inputs.
    The callback is called with one argument:
        - params: CFGDenoiserParams - parameters to be passed to the inner model and sampling state details.
    """
    add_callback('callbacks_cfg_denoiser', callback, name)


def on_cfg_denoised(callback, name=None):
    """register a function to be called in the kdiffussion cfg_denoiser method after building the inner model inputs.
    The callback is called with one argument:
        - params: CFGDenoisedParams - parameters to be passed to the inner model and sampling state details.
    """
    add_callback('callbacks_cfg_denoised', callback, name)


def on_cfg_after_cfg(callback, name=None):
    """register a function to be called in the kdiffussion cfg_denoiser method after cfg calculations are completed.
    The callback is called with one argument:
        - params: AfterCFGCallbackParams - parameters to be passed to the script for post-processing after cfg calculation.
    """
    add_callback('callbacks_cfg_after_cfg', callback, name)


def on_before_component(callback, name=None):
    """register a function to be called before a component is created.
    The callback is called with arguments:
        - component - gradio component that is about to be created.
        - **kwargs - args to gradio.components.IOComponent.__init__ function

    Use elem_id/label fields of kwargs to figure out which component it is.
    This can be useful to inject your own components somewhere in the middle of vanilla UI.
    """
    add_callback('callbacks_before_component', callback, name)


def on_after_component(callback, name=None):
    """register a function to be called after a component is created. See on_before_component for more."""
    add_callback('callbacks_after_component', callback, name)


def on_image_grid(callback, name=None):
    """register a function to be called before making an image grid.
    The callback is called with one argument:
       - params: ImageGridLoopParams - parameters to be used for grid creation. Can be modified.
    """
    add_callback('callbacks_image_grid', callback, name)


def on_infotext_pasted(callback, name=None):
    """register a function to be called before applying an infotext.
    The callback is called with two arguments:
       - infotext: str - raw infotext.
       - result: Dict[str, any] - parsed infotext parameters.
    """
    add_callback('callbacks_infotext_pasted', callback, name)


def on_script_unloaded(callback, name=None):
    """register a function to be called before the script is unloaded. Any hooks/hijacks/monkeying about that
    the script did should be reverted here"""

    add_callback('callbacks_script_unloaded', callback, name)


def on_before_ui(callback, name=None):
    """register a function to be called before the UI is created."""

    add_callback('callbacks_before_ui', callback, name)


def on_list_optimizers(callback, name=None):
    """register a function to be called when UI is making a list of cross attention optimization options.
    The function will be called with one argument, a list, and shall add objects of type modules.sd_hijack_optimizations.SdOptimization
    to it."""

    add_callback('callbacks_list_optimizers', callback, name)


def on_list_unets(callback, name=None):
    """register a function to be called when UI is making a list of alternative options for unet.
    The function will be called with one argument, a list, and shall add objects of type modules.sd_unet.SdUnetOption to it."""

    add_callback('callbacks_list_unets', callback, name)
