﻿from inspect import signature
from functools import cache

FuncArgNotFound = object()


class FuncArgAnalyzer:
    def __init__(self, func):
        self.sig = signature(func)
        self.sig_keys = list(self.sig.parameters.keys())
        self.sig_params = list(self.sig.parameters.values())

    def get_arg_value_by_name(self, name, args, kwargs):
        if name in kwargs:
            return kwargs[name]
        else:
            idx = self.get_arg_index_by_name(name)
            if idx is FuncArgNotFound:
                return FuncArgNotFound
            if idx >= len(args):
                return FuncArgNotFound
            return args[idx]

    def set_arg_value_by_name(self, name, value, args, kwargs):
        if name in kwargs:
            kwargs[name] = value
        else:
            idx = self.get_arg_index_by_name(name)
            if idx is not FuncArgNotFound and idx < len(args):
                args[idx] = value
                return
            kwargs[name] = value

    @cache
    def get_arg_index_by_name(self, name):
        if name not in self.sig_keys:
            return FuncArgNotFound
        idx = self.sig_keys.index(name)
        if self.sig_params[idx].kind == self.sig_params[idx].KEYWORD_ONLY:
            return FuncArgNotFound
        return idx

    def has_arg(self, name):
        return name in self.sig_keys
