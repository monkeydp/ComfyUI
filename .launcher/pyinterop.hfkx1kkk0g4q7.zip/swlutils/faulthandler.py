﻿import faulthandler as fh

from .exception import capture_exception


def install_faulthandler(comm_manager):
    try:
        fdread, fdwrite = comm_manager.acquire_fd("32A93F99-B347-4BF8-8042-64CB3433B906")
        fh.disable()
        fh.enable(file=fdwrite, all_threads=False)
    except RuntimeError:
        return
    except:
        capture_exception()
