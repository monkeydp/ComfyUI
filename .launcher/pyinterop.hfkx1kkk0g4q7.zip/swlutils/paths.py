﻿import os

module_path = os.path.dirname(os.path.realpath(__file__))
ee_root = os.path.dirname(module_path)
if ee_root.endswith('.zip'):
    launcher_root = os.path.dirname(ee_root)
else:
    launcher_root = os.path.dirname(os.path.dirname(ee_root))
is_unpacked = not ee_root.endswith('.zip')
# resource_path = os.path.join(ee_root, 'resources') if is_unpacked else os.getenv('EE_RESOURCE_BUNDLE_PATH', os.path.join(launcher_root, 'resources.y96czryk8krv.zip'))
resource_path = os.path.join(ee_root, '~resources') if is_unpacked else '~resources'
