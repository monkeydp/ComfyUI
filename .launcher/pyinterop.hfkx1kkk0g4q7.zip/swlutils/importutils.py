﻿import sys
import os


def exec_from_path(path):
    try:
        env = {}
        with open(path, 'r') as f:
            code = f.read()
        exec(code, env)
        return env
    except:
        return None


def load_source_directly(module_name):
    module_parts = module_name.split(".")
    module_path = os.path.join(*module_parts) + ".py"
    for path in sys.path:
        full_path = os.path.join(path, module_path)
        if os.path.exists(full_path):
            return exec_from_path(full_path)
    return None


def get_version(package):
    try:
        from importlib.metadata import version
        return version(package)
    except:
        return None


def version_in_blacklist(package, blacklist):
    version = get_version(package)
    if version is None:
        return False
    return version in blacklist


def version_not_in_blacklist(package, blacklist):
    version = get_version(package)
    if version is None:
        return False
    return version not in blacklist


def check_version_fulfills(package, requirement):
    try:
        from importlib.metadata import version
        from packaging.version import parse
        version_now = parse(version(package))
        version_prev = parse(requirement)
        return version_now >= version_prev
    except ImportError:
        pass
    except:
        return False

    return False
