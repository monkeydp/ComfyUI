from queue import Queue
import struct
from threading import Thread
from swlutils.ipc import encode_7bit_string, encode_7bit_utf8_bytes
from .exception import capture_exception
import types


def extract_strings(code_obj):
    strings = set()
    obj_queue = [code_obj]
    
    while len(obj_queue) > 0:
        code = obj_queue.pop()
        for const in code.co_consts:
            if isinstance(const, str):
                try:
                    strings.add(const.encode("utf-8"))
                except:
                    pass
            elif isinstance(const, types.CodeType):
                obj_queue.append(const)
    
    return strings

class AuditHandlerInternal(Thread):
    def __init__(self, pipe):
        super().__init__()
        self.pipe = pipe
        self.daemon = True
        self.queue = Queue()

    @classmethod
    def from_comm_manager(cls, comm_manager):
        try:
            audit_handler_pipe = comm_manager.acquire("92F44EDD-C26F-4C3D-8DEE-2FD260051019")
            audit_handler = cls(audit_handler_pipe)
            return audit_handler
        except Exception:
            capture_exception()
            return None

    def compile(self, source, filename):
        if source is None:
            return None
        if not isinstance(source, bytes):
            return None
        return (
            struct.pack("<H", 1)
            + encode_7bit_utf8_bytes(source)
            + encode_7bit_string(filename)
        )

    def http_client_connect(self, client, host, port):
        return (
            struct.pack("<H", 2)
            + encode_7bit_string(host)
            + struct.pack("<H", port)
        )

    def exec(self, code_object):
        strings = extract_strings(code_object)
        if len(strings) == 0:
            return None
        return (
            struct.pack("<H", 3)
            + struct.pack("<Q", len(strings))
            + b"".join(encode_7bit_utf8_bytes(string) for string in strings)
        )

    def import_(self, module, filename, sys_path, sys_metapath, sys_pathhooks):
        return (
            struct.pack("<H", 4)
            + encode_7bit_string(module)
        )

    def run(self):
        while True:
            try:
                evt_name, args = self.queue.get(block=True)
                evt_name = evt_name.replace(".", "_").replace("-", "_").replace("/", "_")
                if evt_name == 'import':
                    evt_name = 'import_'
                if hasattr(self, evt_name):
                    msg = getattr(self, evt_name)(*args)
                    if msg is not None:
                        self.pipe.write(msg)
                self.queue.task_done()
            except Exception:
                capture_exception()
                pass


class AuditHandler:

    def __init__(self, internal):
        internal.start()
        self.internal = internal

    @classmethod
    def from_comm_manager(cls, comm_manager):
        internal = AuditHandlerInternal.from_comm_manager(comm_manager)
        if internal is None:
            return None
        return cls(internal)

    def report(self, evt, args):
        self.internal.queue.put((evt, args))
