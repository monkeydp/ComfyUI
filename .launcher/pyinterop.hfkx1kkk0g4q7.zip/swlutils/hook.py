﻿import os
import ast
import sys
import importlib.util
from importlib import import_module
from types import ModuleType
from contextlib import contextmanager, redirect_stdout, nullcontext
from importlib.abc import Loader, MetaPathFinder
from importlib.machinery import SourceFileLoader
from typing import Callable, Union
from io import StringIO
from swlutils.exception import capture_exception
from swlutils.mutable import CodeWrapper

old_spec_from_file_location = importlib.util.spec_from_file_location


class Monkey:
    def __init__(self):
        self.premodule_patches = list()
        self.module_patches = list()
        self.function_patches = list()
        self.source_patches = list()
        self.ast_patches = list()
        self.bytecode_patches = list()
        self.output_prohibition = list()
        self.import_injections = list()
        pass

    @property
    def active(self):
        return (
            len(self.premodule_patches) > 0
            or len(self.module_patches) > 0
            or len(self.function_patches) > 0
            or len(self.source_patches) > 0
            or len(self.ast_patches) > 0
            or len(self.bytecode_patches) > 0
            or len(self.output_prohibition) > 0
            or len(self.import_injections) > 0
        )

    @property
    def has_cache_side_effect(self):
        return len(self.source_patches) > 0 or len(self.ast_patches) > 0

    def patch_function(
        self, function_name: str, hooker, priority=100, add_if_not_exists: bool = False
    ):
        self.function_patches.append(
            (function_name, hooker, priority, add_if_not_exists)
        )

    def patch_premodule(self, hooker, priority=100):
        self.premodule_patches.append((hooker, priority))

    def patch_module(self, hooker, priority=100):
        self.module_patches.append((hooker, priority))

    def patch_sources(self, hooker, priority=100):
        self.source_patches.append((hooker, priority))

    def patch_ast(self, hooker, priority=100):
        self.ast_patches.append((hooker, priority))

    def patch_bytecode(self, hooker, priority=100):
        self.bytecode_patches.append((hooker, priority))

    def prohibit_output(self, method=None):
        self.output_prohibition.append(method)

    def inject_import(self, package, content=None, alias=None, priority=100):
        self.import_injections.append((package, content, alias, priority))

    def eval_source(self, source: str, filename: str):
        for hooker, _ in sorted(self.source_patches, key=lambda x: x[1]):
            try:
                out_tuple, *_ = hooker(source, filename), None
                if isinstance(out_tuple, str):
                    source = out_tuple
                elif isinstance(out_tuple, tuple):
                    if len(out_tuple) == 1:
                        source = out_tuple[0]
                    elif len(out_tuple) == 2:
                        source, filename = out_tuple
                    else:
                        raise ValueError("Invalid source patch return value")
                else:
                    raise ValueError("Invalid source patch return type")
            except Exception:
                capture_exception()
        return source, filename

    def eval_ast(self, tree):
        for hooker, _ in sorted(self.ast_patches, key=lambda x: x[1]):
            try:
                if isinstance(hooker, ast.NodeTransformer):
                    tree = hooker.visit(tree)
                elif isinstance(hooker, ast.NodeVisitor):
                    hooker.visit(tree)
                else:
                    tree = hooker(tree)
            except Exception:
                capture_exception()
        return tree

    def eval_bytecode(self, code_object):
        code_wrapper = CodeWrapper(code_object)
        for hooker, _ in sorted(self.bytecode_patches, key=lambda x: x[1]):
            try:
                hooker(code_wrapper)
            except Exception:
                capture_exception()
        return code_wrapper.conclude()

    def eval_premodule(self, module):
        for hooker, _ in sorted(self.premodule_patches, key=lambda x: x[1]):
            try:
                hooker(module)
            except Exception:
                capture_exception()

    def eval_module(self, module):
        for hooker, _ in sorted(self.module_patches, key=lambda x: x[1]):
            try:
                hooker(module)
            except Exception:
                capture_exception()

    def eval_function(self, module):
        for function_name, hooker, _, add_if_not_exists in sorted(
            self.function_patches, key=lambda x: x[2]
        ):
            try:
                if add_if_not_exists or function_name in module.__dict__:
                    _orig = module.__dict__.get(function_name, None)
                    replacement = hooker(_orig, module)
                    if replacement is not None:
                        module.__dict__[function_name] = replacement
            except Exception:
                capture_exception()

    def eval_prohibit_output(self, module):
        for method in self.output_prohibition:
            if method is not None and method in module.__dict__:

                def hooker(orig):
                    def wrapper(*args, **kwargs):
                        with redirect_stdout(StringIO()):
                            return orig(*args, **kwargs)

                    return wrapper

                _orig = module.__dict__.get(method, None)
                module.__dict__[method] = hooker(_orig)

    def eval_import_injection(self, module):
        for package, content, alias, _ in sorted(
            self.import_injections, key=lambda x: x[3]
        ):
            try:
                if content is None and alias is None and "." in package:
                    module_parts = package.split(".")
                    constructed_name = ""
                    constructed_tree = module.__dict__
                    for part in module_parts:
                        constructed_name += (
                            part if constructed_name == "" else "." + part
                        )
                        if part not in constructed_tree:
                            component = importlib.import_module(constructed_name)
                            constructed_tree[part] = component
                        constructed_tree = constructed_tree[part].__dict__
                else:
                    submodule = importlib.import_module(package)
                    if content is not None:
                        submodule = getattr(submodule, content)
                    alias_name = (
                        alias
                        if alias is not None
                        else content if content is not None else package
                    )
                    module.__dict__[alias_name] = submodule
            except Exception:
                capture_exception()


class MonkeyZoo:
    def __init__(self):
        self.monkeys = dict()
        self.aliases_fallback = dict()

    def __getitem__(self, module: Union[str, ModuleType]):
        fullname = module.__name__ if isinstance(module, ModuleType) else module
        monkey = self.monkeys.get(fullname.casefold(), None)
        return monkey

    def __contains__(self, item):
        return item.casefold() in self.monkeys

    @contextmanager
    def __call__(self, module: Union[str, ModuleType]):
        fullname = module.__name__ if isinstance(module, ModuleType) else module
        fullname = fullname.casefold()
        monkey = self.monkeys.get(fullname, Monkey())
        yield monkey
        if monkey.active:
            self.monkeys[fullname] = monkey
        else:
            self.monkeys.pop(fullname, None)

    def alias_if_not_exists(self, module: str, alias: str):
        self.aliases_fallback[module.casefold()] = alias.casefold()


monkey_zoo = MonkeyZoo()


class LoadingSkipper:
    def __init__(self):
        self.currently_loading = list()

    def __contains__(self, module: Union[str, ModuleType]):
        fullname = module.__name__ if isinstance(module, ModuleType) else module
        return fullname in self.currently_loading

    @contextmanager
    def __call__(self, module: Union[str, ModuleType]):
        fullname = module.__name__ if isinstance(module, ModuleType) else module
        self.currently_loading.append(fullname)
        try:
            yield
        finally:
            self.currently_loading.pop()


class HookedMetaPathFinder(MetaPathFinder):
    def __init__(self, zoo):
        self.cache = {}
        self.currently_loading = LoadingSkipper()
        self.zoo = zoo

    def find_spec(self, fullname, path, target=None):
        if fullname in self.currently_loading:
            return None

        if fullname in self.cache:
            return self.cache[fullname]

        if fullname.startswith("swlutils.") or fullname.startswith("swlpatches."):
            return None

        if fullname in self.zoo:
            with self.currently_loading(fullname):
                spec = importlib.util.find_spec(fullname)

            if (
                spec is not None
                and hasattr(spec, "loader")
                and isinstance(spec.loader, SourceFileLoader)
                and hasattr(spec.loader, "path")
            ):
                spec.loader = MonkeySourceFileLoader(
                    filename=getattr(spec.loader, "path"),
                    meta_path_finder=self,
                    loader=spec.loader,
                    monkey=self.zoo[fullname],
                )
                self.cache[fullname] = spec
                return spec

        if fullname.casefold() in self.zoo.aliases_fallback:
            alias = self.zoo.aliases_fallback[fullname.casefold()]

            with self.currently_loading(fullname):
                spec = importlib.util.find_spec(fullname)
            if spec is None:
                with self.currently_loading(alias):
                    spec = importlib.util.find_spec(alias)

            if spec is not None:
                if (
                    (fullname in self.zoo or alias in self.zoo)
                    and hasattr(spec, "loader")
                    and isinstance(spec.loader, SourceFileLoader)
                    and hasattr(spec.loader, "path")
                ):
                    spec.loader = MonkeySourceFileLoader(
                        filename=getattr(spec.loader, "path"),
                        meta_path_finder=self,
                        loader=spec.loader,
                        monkey=self.zoo[alias],
                    )
                    self.cache[fullname] = spec
                    return spec
                else:
                    self.cache[fullname] = spec
                    return spec

        return None

    def invalidate_caches(self):
        self.cache.clear()


class MonkeySourceFileLoader(Loader):
    def __init__(
        self,
        filename,
        meta_path_finder,
        loader,
        monkey,
    ):
        self.filename = filename
        self.meta_path_finder = meta_path_finder
        self.loader = loader
        self.monkey = monkey

    def create_module(self, spec):
        return None

    def get_code(self, fullname=None):
        if not self.monkey.has_cache_side_effect:
            code_object = self.loader.get_code(fullname)
            code_object = self.monkey.eval_bytecode(code_object)
            return code_object
        filename = self.filename
        with open(filename, mode="rb") as file:
            source = importlib.util.decode_source(file.read())
        source, filename = self.monkey.eval_source(source, filename)
        tree = ast.parse(source, filename, "exec")
        tree = self.monkey.eval_ast(tree)
        ast.fix_missing_locations(tree)
        code_object = compile(tree, filename, "exec")
        code_object = self.monkey.eval_bytecode(code_object)
        return code_object

    def exec_module(self, module):
        code_object = self.get_code(module.__name__)
        with (
            self.meta_path_finder.currently_loading(module.__name__)
            if self.meta_path_finder is not None
            else nullcontext()
        ):
            self.monkey.eval_premodule(module)
            with (
                redirect_stdout(StringIO())
                if None in self.monkey.output_prohibition
                else nullcontext()
            ):
                self.monkey.eval_import_injection(module)
                exec(code_object, module.__dict__)
            self.monkey.eval_function(module)
            self.monkey.eval_module(module)
            self.monkey.eval_prohibit_output(module)


def spec_from_file_location_wrapper(func):
    def wrapper(*args, **kwargs):

        if (
            len(args) > 0
            and isinstance(args[0], str)
            and (os.sep + "prestartup_script") in args[0]
        ):
            args_list = list(args)
            args_list[0] = ".".join(args_list[0].split(os.sep)[-2:])
            args = tuple(args_list)

        spec = func(*args, **kwargs)
        if (
            spec is not None
            and spec.name in monkey_zoo
            and hasattr(spec, "loader")
            and isinstance(spec.loader, SourceFileLoader)
            and hasattr(spec.loader, "path")
        ):
            spec.loader = MonkeySourceFileLoader(
                filename=getattr(spec.loader, "path"),
                meta_path_finder=None,
                loader=spec.loader,
                monkey=monkey_zoo[spec.name],
            )
        return spec

    return wrapper


sys.meta_path.insert(0, HookedMetaPathFinder(monkey_zoo))
importlib.util.spec_from_file_location = spec_from_file_location_wrapper(
    old_spec_from_file_location
)


# compat


def register_hook(module: str, function: str, hooker: Callable, force: bool = False):
    with monkey_zoo(module) as monkey:
        monkey.patch_function(function, hooker, add_if_not_exists=force)


def register_customize_hook(module: str, hooker: Callable):
    with monkey_zoo(module) as monkey:
        monkey.patch_module(hooker)
