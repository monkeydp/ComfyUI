﻿prepends_scripts = []
appends_scripts = []

prepends_styles = []
appends_styles = []

extra_static_path = []
extra_static_content = []

def apply_scripts(head_str):
    return '\n'.join(prepends_scripts) + '\n' + head_str + '\n' + '\n'.join(appends_scripts)


def apply_styles(head_str):
    return '\n'.join(prepends_styles) + '\n' + head_str + '\n' + '\n'.join(appends_styles)
