﻿import struct
from os import O_APPEND, O_TEXT, O_RDONLY, getenv
import json
from msvcrt import open_osfhandle, get_osfhandle
from mmap import mmap, ACCESS_READ
import uuid
from io import IOBase


COMM_MANAGER_PIPE_NAME = getenv("SITE_COMM_MANAGER_PIPE")


def mode_to_flags(mode):
    if mode == "w+":
        return O_APPEND | O_TEXT
    elif mode == "wb+":
        return O_APPEND
    elif mode == "r":
        return O_RDONLY | O_TEXT
    elif mode == "rb":
        return O_RDONLY
    raise ValueError("Invalid mode: " + mode)


def retrieve_blob(map_id):
    uuid, length = map_id[:32], int(map_id[32:], 16)
    with mmap(0, length, uuid, ACCESS_READ) as mmapdata:
        return mmapdata.read(length)


def retrieve_text(map_id):
    return retrieve_blob(map_id).decode("utf-8")


def retrieve_json(map_id):
    return json.loads(retrieve_text(map_id))


def open_pipe(handle, mode="w+"):
    fd = open_osfhandle(handle, mode_to_flags(mode))
    return open(fd, mode, buffering=0)


def encode_7bit(num):
    result = bytearray()
    while num >= 0x80:
        result.append(num & 0x7F | 0x80)
        num >>= 7
    result.append(num)
    return result


def encode_7bit_string(string):
    encoded = string.encode("utf-8")
    return encode_7bit(len(encoded)) + encoded


def encode_7bit_utf8_bytes(data):
    return encode_7bit(len(data)) + data


class IORWPair(IOBase):
    def __init__(self, reader, writer):
        self.reader = reader
        self.writer = writer

    def readable(self):
        return self.reader.readable()

    def writable(self):
        return self.writer.writable()

    def seekable(self):
        return self.reader.seekable()

    def readinto(self, b):
        if not self.readable():
            raise IOError("Stream is not readable")
        return self.reader.readinto(b)

    def read(self, size=-1):
        if not self.readable():
            raise IOError("Stream is not readable")
        if size is None:
            size = -1
        return self.reader.read(size)

    def readfull(self, size):
        if not self.readable():
            raise IOError("Stream is not readable")
        if size is None:
            raise ValueError("size must be specified")
        read_counter = 0
        result = bytearray()
        while read_counter < size:
            data = self.reader.read(size - read_counter)
            if len(data) == 0:
                raise EOFError("Unexpected EOF")
            result.extend(data)
            read_counter += len(data)
        return result

    def write(self, b):
        if not self.writable():
            raise IOError("Stream is not writable")
        return self.writer.write(b)

    def writefull(self, b):
        if not self.writable():
            raise IOError("Stream is not writable")
        write_counter = 0
        while write_counter < len(b):
            write_counter += self.writer.write(b[write_counter:])

    def flush(self):
        return self.writer.flush()

    def close(self):
        try:
            self.writer.close()
        finally:
            self.reader.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            self.writer.close()
        finally:
            self.reader.close()

    @property
    def closed(self):
        return self.writer.closed


def comm_manager_available():
    return COMM_MANAGER_PIPE_NAME is not None


class CommManager:
    def __init__(self):
        pipe_str = "\\\\.\\pipe\\" + COMM_MANAGER_PIPE_NAME
        self.pipe = open(pipe_str, 'wb+')

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.pipe.close()

    def acquire_raw(self, guid):
        if isinstance(guid, str):
            guid = uuid.UUID(guid)
        self.pipe.seek(0)
        self.pipe.write(guid.bytes_le)
        result, = struct.unpack('<I', self.pipe.read(4))
        if result != 0:
            raise RuntimeError("Failed to create pipe, error code: " + str(result))
        hread, hwrite = struct.unpack('<QQ', self.pipe.read(16))
        return hread, hwrite

    def acquire_fd(self, guid, /, text=False):
        hread, hwrite = self.acquire_raw(guid)
        return open_osfhandle(hread, O_RDONLY | O_TEXT if text else O_RDONLY), open_osfhandle(hwrite, O_APPEND | O_TEXT if text else O_APPEND)

    def acquire_separated(self, guid, /, text=False, buffering=0):
        fdread, fdwrite = self.acquire_fd(guid, text=text)
        return open(fdread, "r" if text else "rb", buffering=buffering), open(fdwrite, "w+" if text else "wb+", buffering=buffering)

    def acquire(self, guid):
        fpread, fpwrite = self.acquire_separated(guid)
        return IORWPair(fpread, fpwrite)
