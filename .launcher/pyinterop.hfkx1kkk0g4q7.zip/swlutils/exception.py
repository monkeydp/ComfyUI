﻿from os import getenv, environ
from sys import stderr, exc_info

HAS_SENTRY = False

try:
    from swlvendors.sentry_sdk import init as sentry_init
    from swlvendors.sentry_sdk import set_user as sentry_set_user
    from swlvendors.sentry_sdk import set_context as sentry_set_context
    from swlvendors.sentry_sdk import capture_exception as sentry_capture_exception

    HAS_SENTRY = True
except:
    pass


def sentry_before_send(event, hint):
    if event.get('level') == 'error':
        if event.get('exception'):
            for exception in event['exception']['values']:
                if exception.get('type') == 'starlette.requests.ClientDisconnect':
                    return None
                if exception.get("type") == "ClientConnectorDNSError":
                    return None
                if exception.get("type") == "ClientConnectorError":
                    return None
    return event


def get_error_sample_rate(ee_opts):
    if ee_opts.get('sentry_error_sample_rate_override') is not None:
        return ee_opts['sentry_error_sample_rate_override']
    return 0.0008


def get_tracing_sample_rate(ee_opts):
    if ee_opts.get("sentry_tracing_sample_rate_override") is not None:
        return ee_opts["sentry_tracing_sample_rate_override"]
    return 0.00005


def init_sentry(ee_opts):
    if not HAS_SENTRY:
        return False

    fork_type, identity = ee_opts['fork_type'], ee_opts['identity']

    integrations = []

    from swlvendors.sentry_sdk.integrations.argv import ArgvIntegration
    from swlvendors.sentry_sdk.integrations.atexit import AtexitIntegration
    from swlvendors.sentry_sdk.integrations.dedupe import DedupeIntegration
    from swlvendors.sentry_sdk.integrations.excepthook import ExcepthookIntegration
    from swlvendors.sentry_sdk.integrations.logging import LoggingIntegration
    from swlvendors.sentry_sdk.integrations.modules import ModulesIntegration
    from swlvendors.sentry_sdk.integrations.stdlib import StdlibIntegration
    from swlvendors.sentry_sdk.integrations.threading import ThreadingIntegration

    integrations.append(ArgvIntegration())
    integrations.append(AtexitIntegration(callback=lambda x, y: None))
    integrations.append(DedupeIntegration())
    integrations.append(ExcepthookIntegration())
    # integrations.append(LoggingIntegration())
    integrations.append(ModulesIntegration())
    integrations.append(StdlibIntegration())
    integrations.append(ThreadingIntegration())

    try:
        from swlvendors.sentry_sdk.integrations.starlette import StarletteIntegration
        integrations.append(StarletteIntegration(transaction_style="endpoint"))
    except:
        pass

    try:
        from swlvendors.sentry_sdk.integrations.fastapi import FastApiIntegration
        integrations.append(FastApiIntegration(transaction_style="endpoint"))
    except:
        pass

    try:
        from swlvendors.sentry_sdk.integrations.httpx import HttpxIntegration
        integrations.append(HttpxIntegration())
    except:
        pass

    try:
        from swlvendors.sentry_sdk.integrations.aiohttp import AioHttpIntegration
        integrations.append(AioHttpIntegration(transaction_style="method_and_path_pattern"))
    except:
        pass

    try:
        from swlvendors.sentry_sdk.integrations.asyncio import AsyncioIntegration
        integrations.append(AsyncioIntegration())
    except:
        pass

    sentry_init(
        dsn="https://b64b00fb2dcf4edb0903112903b343a3@sentry.oystermercury.top/10",
        max_breadcrumbs=50,
        environment=str(fork_type),
        sample_rate=get_error_sample_rate(ee_opts),
        traces_sample_rate=get_tracing_sample_rate(ee_opts),
        auto_enabling_integrations=False,
        default_integrations=False,
        send_default_pii=True,
        # max_value_length=4 * 1024,
        integrations=integrations,
        before_send=sentry_before_send,
        debug=False,  # getenv("EE_DEBUG") == "1",
    )

    sentry_set_user({"id": identity, "ip_address": "{{auto}}"})

    # trim off this because it is too long
    filtered_ee_opts = {k: v for k, v in ee_opts.items() if k != 'hf_mirror'}
    filtered_ee_opts['hf_mirror'] = ee_opts.get('hf_mirror', None) is not None

    extended_sysinfo = {}
    try:
        import ctypes
        extended_sysinfo['ASCII Code page'] = ctypes.cdll.kernel32.GetACP()
        extended_sysinfo['OEM Code page'] = ctypes.cdll.kernel32.GetOEMCP()
    except:
        pass

    sentry_set_context("EE Options", filtered_ee_opts)
    sentry_set_context("Environment Variables", dict(environ))
    sentry_set_context("Extended System Info", extended_sysinfo)

    return True


def capture_exception(e=None, /, submit_report=True):
    if getenv('EE_DEBUG') == '1':
        from traceback import print_exception
        if e is None:
            print_exception(*exc_info(), file=stderr)
        else:
            print_exception(e, file=stderr)
    if submit_report:
        client_capture_exception(e)


def client_capture_exception(e=None):
    if not HAS_SENTRY:
        return
    if e is None:
        sentry_capture_exception()
    else:
        sentry_capture_exception(e)


class UserCanceledException(Exception):
    pass
