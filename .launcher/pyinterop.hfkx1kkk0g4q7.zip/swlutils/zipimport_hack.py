﻿try:
    import os
    import sys
    import zipimport
    first_item = zipimport._zip_searchorder[0]
    integrity_check = len(first_item) == 3 and first_item[0] == os.path.sep + "__init__.pyc" and first_item[1] and \
                      first_item[2]
    if not integrity_check:
        raise Exception("Integrity check failed")

    cache_tag = sys.implementation.cache_tag

    tmp_searchorder = list(zipimport._zip_searchorder)

    tmp_searchorder.insert(0, (f'.{cache_tag}.pyc', True, False))
    tmp_searchorder.insert(0, (f'.{cache_tag}.opt-1.pyc', True, False))
    tmp_searchorder.insert(0, (f'.{cache_tag}.opt-2.pyc', True, False))
    tmp_searchorder.insert(0, (f'{os.path.sep}__init__.{cache_tag}.pyc', True, True))
    tmp_searchorder.insert(0, (f'{os.path.sep}__init__.{cache_tag}.opt-1.pyc', True, True))
    tmp_searchorder.insert(0, (f'{os.path.sep}__init__.{cache_tag}.opt-2.pyc', True, True))

    zipimport._zip_searchorder = tuple(tmp_searchorder)

except Exception:
    from os import getenv
    if getenv('EE_DEBUG') == '1':
        from traceback import print_exc
        print_exc()
    pass
