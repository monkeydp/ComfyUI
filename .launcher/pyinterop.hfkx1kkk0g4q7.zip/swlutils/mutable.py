﻿import types


# noinspection PyBroadException
class TupleWrapper:

    def __init__(self, tup, field_name=None, parent=None):
        self.tup = tup
        self.field_name = field_name
        self.parent = parent
        self._overrides = None

    def __setitem__(self, key, value):
        if self._overrides is None:
            self._overrides = list(self.tup)
        self._overrides[key] = value
        if self.field_name and self.parent:
            setattr(self.parent, self.field_name, self)

    def __getitem__(self, item):
        if self._overrides is not None and item in self._overrides:
            return self._overrides[item]
        return self.tup[item]

    def __iter__(self):
        if self._overrides is not None:
            return iter(self._overrides)
        return iter(self.tup)

    def __len__(self):
        if self._overrides is not None:
            return len(self._overrides)
        return len(self.tup)

    def replace_primitive(self, original, replacement):
        for i, item in enumerate(self.tup):
            if item == original:
                self[i] = replacement

    def replace(self, predicate, replacement, /, only_first=False):
        for i, item in enumerate(self.tup):
            if predicate(item):
                item = CodeWrapper(item) if isinstance(item, types.CodeType) else item
                item = TupleWrapper(item) if isinstance(item, tuple) else item
                result = replacement(item)
                if isinstance(result, TupleWrapper):
                    self[i] = result.conclude()
                elif isinstance(result, CodeWrapper):
                    self[i] = result.conclude()
                else:
                    self[i] = result
                if only_first:
                    return
                
    def replace_method_noop(self, method_name, /, only_first=False):
        for i, item in enumerate(self.tup):
            if isinstance(item, types.CodeType) and item.co_name == method_name:
                generated_module = compile(f"def {method_name}(*args, **kwargs): pass", "<generated>", "exec")
                generated_code = generated_module.co_consts[0]
                self[i] = generated_code
                if only_first:
                    return

    def operate(self, predicate, /, only_first=False):
        can_operate = (types.CodeType, tuple)

        for i, item in enumerate(self):
            if not isinstance(item, can_operate):
                continue
            if predicate(item):
                item = CodeWrapper(item) if isinstance(item, types.CodeType) else item
                item = TupleWrapper(item) if isinstance(item, tuple) else item
                try:
                    yield item
                finally:
                    if isinstance(item, TupleWrapper):
                        self[i] = item.conclude()
                    elif isinstance(item, CodeWrapper):
                        self[i] = item.conclude()
                if only_first:
                    return

    def conclude(self):
        if self._overrides is not None:
            return tuple(self._overrides)
        return self.tup


class CodeWrapper:
    def __init__(self, code):
        self._code = code
        self._overrides = {}

    def __setattr__(self, key, value):
        if key in ('_code', '_overrides'):
            self.__dict__[key] = value
            return
        self._overrides[key] = value

    def __getattr__(self, key):
        if key in self._overrides:
            return self._overrides[key]
        attr = getattr(self._code, key)
        if isinstance(attr, tuple):
            return TupleWrapper(attr, field_name=key, parent=self)
        return attr

    def conclude(self):
        if len(self._overrides) == 0:
            return self._code

        for key, value in self._overrides.items():
            if isinstance(value, TupleWrapper):
                self._overrides[key] = value.conclude()
        return self._code.replace(**self._overrides)
