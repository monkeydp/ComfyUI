﻿from zipfile import ZipFile
import datetime
import time
import os
from .paths import is_unpacked, resource_path, ee_root
from contextlib import contextmanager

CHUNK_SIZE = 1 * 1024 * 1024


def zipinfo_to_epoch(zipinfo_date_time):
    dt = datetime.datetime(*zipinfo_date_time)
    return dt.timestamp()


@contextmanager
def open_resource_context():
    if is_unpacked:
        yield
    else:
        with ZipFile(ee_root) as z:
            yield z


def get_last_changed_time(ctx, path):
    if is_unpacked:
        path = path.replace('/', os.sep)
        return os.path.getmtime(os.path.join(resource_path, path))
    else:
        return zipinfo_to_epoch(ctx.getinfo(f"{resource_path}/{path}").date_time)


def get_resource_generator(ctx, path):
    if is_unpacked:
        path = path.replace('/', os.sep)
        with open(os.path.join(resource_path, path), 'rb') as f:
            while chunk := f.read(CHUNK_SIZE):
                yield chunk
    else:
        with ctx.open(f"{resource_path}/{path}") as f:
            while chunk := f.read(CHUNK_SIZE):
                yield chunk


def open_resource(ctx, path):
    if is_unpacked:
        path = path.replace('/', os.sep)
        return open(os.path.join(resource_path, path), 'rb')
    else:
        return ctx.open(f"{resource_path}/{path}")

