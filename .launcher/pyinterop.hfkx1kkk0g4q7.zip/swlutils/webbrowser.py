from swlutils.ipc import encode_7bit_string
from swlutils.exception import capture_exception


class WebBrowser:
    def __init__(self, pipe):
        self.pipe = pipe

    @classmethod
    def from_comm_manager(cls, comm_manager):
        try:
            web_browser_pipe = comm_manager.acquire("CC7CF2D6-D04B-4457-AAD3-9E99F31AAB95")
            web_browser = cls(web_browser_pipe)
            return web_browser
        except:
            capture_exception()
            return None

    def open(self, url):
        self.pipe.writefull(encode_7bit_string(url))
