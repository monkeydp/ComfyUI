﻿import time
from inspect import signature
from swlutils.funcinspect import FuncArgAnalyzer, FuncArgNotFound


def throttle(interval, key=None):
    def inner(func):
        # Store the time the function was last called
        last_called = {}
        func_analyzer = FuncArgAnalyzer(func)

        def wrapper(*args, **kwargs):
            nonlocal last_called, func_analyzer
            if key is not None:
                key_ = func_analyzer.get_arg_value_by_name(key, args, kwargs)
            else:
                key_ = FuncArgNotFound
            if key_ not in last_called:
                last_called[key_] = 0
            now = time.monotonic_ns()
            elapsed = now - last_called[key_]
            if elapsed >= interval * 1e6:
                last_called[key_] = now
                return func(*args, **kwargs)

        return wrapper
    return inner
