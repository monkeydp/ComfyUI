﻿import struct
from swlutils.exception import UserCanceledException
from swlutils.ipc import encode_7bit_string


class FileOperation:
    pipe = None

    @classmethod
    def attach_comm_manager(cls, comm_manager):
        try:
            cls.pipe = comm_manager.acquire("0B970922-ED6B-459A-B1B8-887A5776905B")
        except Exception:
            capture_exception()

    def __init__(self):
        if self.pipe is None:
            raise Exception("FileOperation is not attached")
        self.class_id = id(self)

    def __enter__(self):
        self.pipe.write(struct.pack("<HQ", 0, self.class_id))
        return_val = self.pipe.readfull(4)
        result, = struct.unpack("<i", return_val)
        if result != 0:
            raise Exception(f"Failed to create FileOperation: {result}")
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.pipe.write(struct.pack("<HQ", 1, self.class_id))
        return_val = self.pipe.readfull(4)
        result, = struct.unpack("<i", return_val)
        if result != 0:
            raise Exception(f"Failed to destroy FileOperation: {result}")

    def perform(self):
        self.pipe.write(struct.pack("<HQ", 2, self.class_id))
        return_val = self.pipe.readfull(4)
        result, = struct.unpack("<i", return_val)
        if result == -2147467260:
            raise UserCanceledException()
        elif result != 0:
            raise Exception(f"Failed to perform FileOperation: {result}")

    def delete(self, path):
        self.pipe.write(struct.pack("<HQ", 3, self.class_id))
        self.pipe.writefull(encode_7bit_string(path))
        return_val = self.pipe.readfull(4)
        result, = struct.unpack("<i", return_val)
        if result != 0:
            raise Exception(f"Failed to enqueue delete to FileOperation: {result}")
