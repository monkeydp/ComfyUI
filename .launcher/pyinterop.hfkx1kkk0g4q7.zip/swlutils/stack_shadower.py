﻿import ast
import sys
import importlib.util
from zipimport import zipimporter
from types import ModuleType
from contextlib import contextmanager, redirect_stdout, nullcontext
from importlib.abc import Loader, MetaPathFinder
from pathlib import Path
from typing import Callable, Union


class LoadingSkipper:
    def __init__(self):
        self.currently_loading = list()

    def __contains__(self, module: Union[str, ModuleType]):
        fullname = module.__name__ if isinstance(module, ModuleType) else module
        return fullname in self.currently_loading

    @contextmanager
    def __call__(self, module: Union[str, ModuleType]):
        fullname = module.__name__ if isinstance(module, ModuleType) else module
        self.currently_loading.append(fullname)
        try:
            yield
        finally:
            self.currently_loading.pop()


class HookedMetaPathFinder(MetaPathFinder):
    def __init__(self):
        self.cache = {}
        self.currently_loading = LoadingSkipper()

    def find_spec(self, fullname, path, target=None):
        if fullname in self.currently_loading:
            return None

        if fullname in self.cache:
            return self.cache[fullname]

        if (fullname.startswith("swlutils.") or
                fullname.startswith("swlpatches.") or
                    fullname.startswith("swlscripts.") or
                        fullname.startswith("swlvendors.") or
                            fullname == 'swlinitializer'):
            with self.currently_loading(fullname):
                spec = importlib.util.find_spec(fullname)

            if spec is None:
                return None

            if hasattr(spec, "origin") and not spec.origin.endswith(".py"):
                return None

            if not hasattr(spec, "loader") or not isinstance(spec.loader, zipimporter):
                return None

            spec.loader = StackShadowerSourceLoader(
                fullname=fullname,
                source=spec.loader.get_source(fullname),
                meta_path_finder=self,
            )
            self.cache[fullname] = spec
            return spec

        return None

    def invalidate_caches(self):
        self.cache.clear()


def _normalize_line_endings(source):
    source = source.replace(b'\r\n', b'\n')
    source = source.replace(b'\r', b'\n')
    return source


class StackShadowerSourceLoader(Loader):
    def __init__(
            self,
            fullname,
            source,
            meta_path_finder,
    ):
        # self.fullname = fullname[3:]
        self.source = source
        self.meta_path_finder = meta_path_finder

    def create_module(self, spec):
        return None

    def get_code(self, fullname=None):
        fullname = fullname[3:]
        if fullname == 'utils.hook':
            filename = "<frozen importlib._bootstrap>"
        else:
            filename = f"<enhanced_experience {fullname}>"
        code_object = compile(_normalize_line_endings(self.source.encode('utf-8')),
                              filename,
                              "exec",
                              optimize=2,
                              dont_inherit=True)
        return code_object

    def exec_module(self, module):
        code_object = self.get_code(module.__name__)
        with self.meta_path_finder.currently_loading(module.__name__):
            exec(code_object, module.__dict__)


sys.meta_path.insert(0, HookedMetaPathFinder())
