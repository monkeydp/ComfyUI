﻿import sys
import importlib.util
from swlutils.importutils import load_source_directly


if __name__ == "__main__":
    try:
        from packaging import version
        ver = load_source_directly("torch.version")
        ver_current = version.parse(ver.get('__version__'))
        if ver_current.major >= 2:
            print("K")
            sys.exit(0)
        else:
            print("L")
            sys.exit(2)
    except Exception:
        print("F")
        sys.exit(1)
