﻿import sys
import importlib.util
from swlutils.importutils import load_source_directly


def has_package(package):
    try:
        spec = importlib.util.find_spec(package)
        return spec is not None
    except ImportError:
        return False


if __name__ == "__main__":
    if not has_package('torch'):
        print("T")
        sys.exit(0)
    try:
        if len(sys.argv) < 2:
            print("A")
            sys.exit(0)
        wants = sys.argv[1]
        ver = load_source_directly("torch.version")
        if wants == 'cuda':
            if ver.get('cuda') is not None:
                print("K")
                sys.exit(0)
            else:
                print("L")
                sys.exit(0)
        elif wants == 'hip':
            if ver.get('hip') is not None:
                print("K")
                sys.exit(0)
            else:
                print("L")
                sys.exit(0)
        elif wants == 'dml':
            if has_package("torch_directml"):
                print("K")
                sys.exit(0)
            else:
                print("L")
                sys.exit(0)
        elif wants == 'ipex':
            if has_package("intel_extension_for_pytorch"):
                print("K")
                sys.exit(0)
            else:
                print("L")
                sys.exit(0)
        elif wants == 'cpu':
            print("K")
            sys.exit(0)
        else:
            print("A")
            sys.exit(0)
    except Exception:
        print("F")
        sys.exit(0)
