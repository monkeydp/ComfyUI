﻿import sys
import importlib.util


def has_package(package):
    try:
        spec = importlib.util.find_spec(package)
        return spec is not None
    except ImportError:
        return False


if __name__ == "__main__":
    if not has_package('xformers.ops'):
        print("X")
        sys.exit(1)
    try:
        import xformers.ops

        try:
            try:
                from xformers import _C_flashattention  # type: ignore[attr-defined]
            except ImportError:
                import flash_attn
                from flash_attn.flash_attn_interface import flash_attn_cuda as _C_flashattention
        except ImportError:
            print("L")
            sys.exit(2)

        fw, bw = xformers.ops.MemoryEfficientAttentionFlashAttentionOp

        if fw.is_available() and bw.is_available() and 'varlen_fwd' in dir(_C_flashattention):
            print("K")
            sys.exit(0)
        else:
            print("L")
            sys.exit(2)
    except Exception:
        print("F")
        sys.exit(1)
