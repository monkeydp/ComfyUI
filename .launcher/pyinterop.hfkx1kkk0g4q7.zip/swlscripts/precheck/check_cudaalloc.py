﻿import sys
import importlib.util
from swlutils.importutils import load_source_directly


if __name__ == "__main__":
    try:
        from packaging import version
        ver = load_source_directly("torch.version")
        if ver.get('cuda') is None:
            print("L")
            sys.exit(2)
        ver_current_cuda = version.parse(ver.get('cuda'))
        ver_current_torch = version.parse(ver.get('__version__'))
        if ver_current_cuda >= version.parse("11.4") and ver_current_torch.major >= 2:
            print("K")
            sys.exit(0)
        else:
            print("L")
            sys.exit(2)
    except Exception:
        print("F")
        sys.exit(1)
