const original_lines = {};
const translated_lines = {};

window.getTranslation = (t) => t;

(function(){
    const thisScript = document.currentScript;
    const defaultNs = thisScript?.dataset?.namespace ?? "automatic11111";

    function gradioApp() {
        const elems = document.getElementsByTagName('gradio-app');
        const elem = elems.length == 0 ? document : elems[0];
        return elem.shadowRoot ? elem.shadowRoot : elem;
    }
    
    const re_num = /^[\.\d]+$/;
    const re_emoji =
        /^[\p{Extended_Pictographic}\u{1F3FB}-\u{1F3FF}\u{1F9B0}-\u{1F9B3}]+$/u;

    const ignore_ids_for_localization = {
        setting_sd_hypernetwork: "OPTION",
        setting_sd_model_checkpoint: "OPTION",
        setting_realesrgan_enabled_models: "OPTION",
        modelmerger_primary_model_name: "OPTION",
        modelmerger_secondary_model_name: "OPTION",
        modelmerger_tertiary_model_name: "OPTION",
        train_embedding: "OPTION",
        train_hypernetwork: "OPTION",
        txt2img_styles: "OPTION",
        img2img_styles: "OPTION",
        // setting_random_artist_categories: "SPAN",
        // setting_face_restoration_model: "SPAN",
        // setting_realesrgan_enabled_models: "SPAN",
        // extras_upscaler_1: "SPAN",
        // extras_upscaler_2: "SPAN",
    };

    const ignore_closest_classes_for_localization = [
        'autocompleteResults',
        'gradio-json',
        'gradio-code',
        'codemirror-wrapper',
        'progress-text',
    ]
    
    document.addEventListener("DOMContentLoaded", function () {
        const {Tolgee, BackendFetch} = window["@tolgee/web"];
        const tolgee = Tolgee()
            .use(
                BackendFetch({
                    prefix: "https://langs-v2.oystermercury.top/novelai-dev/stable-diffusion-webui/released/compact",
                })
            )
            .init({
                language: "zh-Hans",
                ns: ["", defaultNs],
                defaultNs,
                fallbackNs: [""],
                observerOptions: {
                    targetElement: gradioApp(),
                    tagAttributes: {
                        textarea: ["placeholder"],
                        input: ["placeholder"],
                        "*": ["title"],
                    },
                    highlightWidth: 1.5,
                    passToParent: (node) => {
                        if (
                            node instanceof HTMLOptionElement ||
                            node instanceof HTMLOptGroupElement
                        )
                            return true;
                        if (
                            node instanceof HTMLSpanElement &&
                            node.parentElement instanceof HTMLLabelElement
                        )
                            return true;
                        if (
                            (node instanceof HTMLLabelElement ||
                                node instanceof HTMLDivElement) &&
                            !node.classList.contains("gr-block")
                        ) {
                            return (
                                node.querySelector(".gr-block") === null &&
                                node.closest(".gr-block") !== null
                            );
                        }
                        return false;
                    },
                },
            });

        function nodesUnder(el) {
            let n,
                a = [],
                walk = document.createTreeWalker(
                    el,
                    NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
                    {
                        acceptNode(node) {
                            return node.nodeType === 3 ||
                            node.placeholder ||
                            node.title
                                ? NodeFilter.FILTER_ACCEPT
                                : NodeFilter.FILTER_SKIP;
                        },
                    }
                );
            while ((n = walk.nextNode())) a.push(n);
            return a;
        }

        function canBeTranslated(node, text) {
            if (!text) return false;
            if (!node.parentElement) return false;

            const parentType = node.parentElement.nodeName;
            if (
                parentType === "SCRIPT" ||
                parentType === "STYLE" ||
                parentType === "TEXTAREA"
            )
                return false;

            if (parentType === "OPTION" || parentType === "SPAN") {
                let pnode = node;
                for (let level = 0; level < 4; level++) {
                    pnode = pnode.parentElement;
                    if (!pnode) break;

                    if (ignore_ids_for_localization[pnode.id] === parentType)
                        return false;
                }
            }

            if (re_num.test(text)) return false;
            if (re_emoji.test(text)) return false;
            let containingElement = node.nodeType === 1 ? node : node.parentElement;
            for (let className of ignore_closest_classes_for_localization) {
                if (containingElement.classList.contains(className)) return false;
                if (containingElement.closest(`.${className}`)) return false;
            }

            if (containingElement.closest('table#available_extensions') || containingElement.closest('table#extensions')) {
                if (containingElement.classList.contains("extension-tag")) return true;
                if (containingElement.classList.contains("extension_status")) return true;
                if (containingElement.closest('table thead th')) return true;
                if (containingElement.nodeName !== 'INPUT' &&
                    containingElement.nodeName !== 'BUTTON' &&
                    containingElement.nodeName !== 'TH') return false;

            }
            return true;
        }

        function getTranslation(text, add = false) {
            if (!text) return undefined;

            if (translated_lines[text] === undefined) {
                original_lines[text] = 1;
            }

            const key = text.match(/[\u200B-\u200D\uFEFF]{4,}$/)
                ? tolgee.unwrap(text).keys[0].key
                : text;

            const tl = tolgee.t(key, window.localization?.[key] || key);
            const unwrappedTl =
                tl !== undefined
                    ? tl.replace(/[\u200B-\u200D\uFEFF]{4,}$/, "")
                    : undefined;

            if (tl !== undefined && key !== unwrappedTl) {
                translated_lines[unwrappedTl] = 1;
            }

            if (!tolgee.isDev() || !add) {
                if (tl === text || tl === key || (!add && unwrappedTl === key)) return undefined; // ignore same code
                return tl;
            } else {
                if (tl.match(/[\u200B-\u200D\uFEFF]{4,}$/)) {
                    return tl !== text ? tl : undefined;
                } else {
                    return tolgee.wrap({key, translation: tl, defaultValue: key})
                }
            }
        }

        function processTextNode(node, add = false) {
            let text = node.textContent.trim();

            if (!canBeTranslated(node, text)) return;

            const tl = getTranslation(text, add);
            if (tl !== undefined) {
                node.textContent = tl;
            }
        }

        function processNode(node, add = false, stop = false) {
            if (node.nodeType === 3) {
                processTextNode(node, add);
                return;
            }

            if (node.title) {
                const tl = getTranslation(node.title, add);
                if (tl !== undefined) {
                    node.title = tl;
                }
            }

            if (node.placeholder) {
                const tl = getTranslation(node.placeholder, add);
                if (tl !== undefined) {
                    node.placeholder = tl;
                }
            }

            if (!stop) {
                for (const n of nodesUnder(node)) {
                    processNode(n, add, true);
                }
            }
        }

        window.addEventListener("load", async function () {
            await tolgee.run();

            let observer = new MutationObserver(function (m) {
                for (const mutation of m) {
                    if (mutation.type === 'attributes') {
                        processNode(mutation.target, false, true);
                    } else {
                        for (const node of mutation.addedNodes) {
                            processNode(node, true);
                        }
                    }
                }
            });
            const root = gradioApp();

            processNode(root, true);
            observer.observe(root, {
                childList: true,
                subtree: true,
                attributes: true,
                attributeFilter: ["placeholder", "title"],
            });
            
            window.getTranslation = getTranslation;

            if (tolgee.isDev()) {
                tolgee.on("update", () => {
                    processNode(root);
                });
            }
        });
    });
})();

function dumpTranslations() {
    const dumped = {};
    
    if (!window.localization) {
        return {};
    }
    
    if (localization.rtl) {
        dumped.rtl = true;
    }

    Object.keys(original_lines).forEach(function (text) {
        if (dumped[text] !== undefined) return;

        dumped[text] = localization[text] || text;
    });

    return dumped;
}

function download_localization() {
    const text = JSON.stringify(dumpTranslations(), null, 4);

    const element = document.createElement("a");
    element.setAttribute(
        "href",
        "data:text/plain;charset=utf-8," + encodeURIComponent(text)
    );
    element.setAttribute("download", "localization.json");
    element.style.display = "none";
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
}
