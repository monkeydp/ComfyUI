﻿(function () {
    const {Tolgee, BackendFetch, FormatSimple} = window["@tolgee/web"];
    const tolgee = Tolgee()
        .use(FormatSimple())
        .use(
            BackendFetch({
                prefix: "https://langs-v2.oystermercury.top/novelai-dev/comfyui/released/compact",
            })
        )
        .init({
            language: "zh-Hans",
            observerOptions: {
                tagAttributes: {
                    textarea: ["placeholder"],
                    input: ["placeholder"],
                    "*": ["title"],
                },
                fullKeyEncode: true,
                highlightWidth: 1.5,
            },
        });


    const localizeKv = {};

    const TOLGEE_WRAPPED_ONLY_DATA_ATTRIBUTE = 'data-tolgee-key-only';

    window.t = tolgee.t;

    const reEmoji = /([\u2700-\u27BF]|[\uE000-\uF8FF]|\uD83C[\uDC00-\uDFFF]|\uD83D[\uDC00-\uDFFF]|[\u2011-\u26FF]|\uD83E[\uDD10-\uDDFF])/g;
    const reConvertToInput = /^Convert (.*) to input$/i;
    const reConvertToWidget = /^Convert (.*) to widget$/i;

    function contentToKey(content) {
        if (!content) return 'null';
        let key = content.replace(reEmoji, '').trim()
            .replace(/\s+/g, "_")
            .replace(/\//g, '.')
            .toLowerCase();
        if (key.startsWith('_')) {
            key = key.slice(1);
        }
        if (key.endsWith('.')) {
            return key.slice(0, -1);
        }
        return key;
    }

    function optional(obj, prop, fallback = undefined) {
        if (typeof obj === 'object' && obj) {
            if (Array.isArray(prop)) {
                let result = obj
                for (const p of prop) {
                    if (result == null) {
                        return fallback;
                    }
                    if (p in result) {
                        result = result[p];
                    } else {
                        return fallback;
                    }
                }
                return result;
            }

            if (prop in obj) {
                return obj[prop];
            }
        }
        return fallback;
    }

    const lg = window.LiteGraph;

    const lgc = window.LGraphCanvas;
    const lgn = window.LGraphNode;


    lgn.prototype.addInput = new Proxy(lgn.prototype.addInput, {
        apply(target, thisArg, argumentsList) {
            const [name] = argumentsList;
            const node = thisArg.constructor;
            const nodeCategoryHandle = contentToKey(node.category);
            const nodeHandle = contentToKey(node.type);
            const key = `node.${nodeCategoryHandle}.${nodeHandle}.input.${contentToKey(name)}.name`;
            const input = target.apply(thisArg, argumentsList);
            const fallback = name;
            localizeKv[key] = fallback;
            // if (!input['label']) input['label'] = tolgee.t(key, fallback);
            if (!input['label'] || input['label'] === fallback) {
                Object.defineProperty(input, 'label', {
                    get() {
                        return tolgee.t(key, fallback, {
                            noWrap: true
                        });
                    },
                    set(value) {
                        if (value === fallback || !value) {
                            return value;
                        }
                        Object.defineProperty(input, 'label', {
                            value: value,
                            enumerable: true,
                            configurable: true,
                            writable: true,
                        });
                        return value;
                    },
                    enumerable: false,
                    configurable: true,
                });
            }
            Object.defineProperty(input, '_lc_key', {
                value: key,
                enumerable: false,
                writable: false,
                configurable: true,
            });
            Object.defineProperty(input, '_lc_key_parent', {
                value: `node.${nodeCategoryHandle}.${nodeHandle}.input`,
                enumerable: false,
                writable: false,
                configurable: true,
            });
            Object.defineProperty(input, '_lc_processed', {
                value: true,
                enumerable: false,
                writable: false,
                configurable: true,
            });
            return input;
        }
    });

    lgn.prototype.addOutput = new Proxy(lgn.prototype.addOutput, {
        apply(target, thisArg, argumentsList) {
            const [name] = argumentsList;
            const node = thisArg.constructor;
            const nodeCategoryHandle = contentToKey(node.category);
            const nodeHandle = contentToKey(node.type);
            const key = `node.${nodeCategoryHandle}.${nodeHandle}.output.${contentToKey(name)}.name`;
            const output = target.apply(thisArg, argumentsList);
            const fallback = name;
            localizeKv[key] = fallback;
            if (!output['label'] || output['label'] === fallback) {
                Object.defineProperty(output, 'label', {
                    get() {
                        return tolgee.t(key, fallback, {
                            noWrap: true
                        });
                    },
                    set(value) {
                        if (value === fallback || !value) {
                            return value;
                        }
                        Object.defineProperty(output, 'label', {
                            value: value,
                            enumerable: true,
                            configurable: true,
                            writable: true,
                        });
                        return value;
                    },
                    enumerable: false,
                    configurable: true,
                });
            }
            Object.defineProperty(output, '_lc_key', {
                value: key,
                enumerable: false,
                writable: false,
                configurable: true,
            });
            Object.defineProperty(output, '_lc_key_parent', {
                value: `node.${nodeCategoryHandle}.${nodeHandle}.output`,
                enumerable: false,
                writable: false,
                configurable: true,
            });
            Object.defineProperty(output, '_lc_processed', {
                value: true,
                enumerable: false,
                writable: false,
                configurable: true,
            });
            return output;
        }
    });

    lgn.prototype.addWidget = new Proxy(lgn.prototype.addWidget, {
        apply(target, thisArg, argumentsList) {
            const [type, name] = argumentsList;
            const node = thisArg.constructor;
            const nodeCategoryHandle = contentToKey(node.category);
            const nodeHandle = contentToKey(node.type);
            const key = `node.${nodeCategoryHandle}.${nodeHandle}.input.${contentToKey(name)}.name`;
            const input = target.apply(thisArg, argumentsList);
            const fallback = name;
            localizeKv[key] = fallback;
            if (!input['label'] || input['label'] === fallback) {
                Object.defineProperty(input, 'label', {
                    get() {
                        return tolgee.t(key, fallback, {
                            noWrap: true
                        });
                    },
                    set(value) {
                        if (value === fallback || !value) {
                            return value;
                        }
                        Object.defineProperty(input, 'label', {
                            value: value,
                            enumerable: true,
                            configurable: true,
                            writable: true,
                        });
                        return value;
                    },
                    enumerable: false,
                    configurable: true,
                });
            }
            Object.defineProperty(input, '_lc_key', {
                value: key,
                enumerable: false,
                writable: false,
                configurable: true,
            });
            Object.defineProperty(input, '_lc_key_parent', {
                value: `node.${nodeCategoryHandle}.${nodeHandle}.input`,
                enumerable: false,
                writable: false,
                configurable: true,
            });
            Object.defineProperty(input, '_lc_processed', {
                value: true,
                enumerable: false,
                writable: false,
                configurable: true,
            });
            return input;
        }
    });

    lgn.prototype.configure = new Proxy(lgn.prototype.configure, {
        apply(target, thisArg, argumentsList) {
            const [info] = argumentsList;
            const node = thisArg.constructor;
            const nodeCategoryHandle = contentToKey(node.category);
            const nodeHandle = contentToKey(node.type);
            const result = target.apply(thisArg, argumentsList);

            if (thisArg.inputs) {
                for (const input of thisArg.inputs) {
                    const key = `node.${nodeCategoryHandle}.${nodeHandle}.input.${contentToKey(input.name)}.name`;
                    const fallback = input.name;
                    localizeKv[key] = fallback;
                    if (!input['label'] || input['label'] === fallback) {
                        Object.defineProperty(input, 'label', {
                            get() {
                                return tolgee.t(key, fallback, {
                                    noWrap: true
                                });
                            },
                            set(value) {
                                if (value === fallback || !value) {
                                    return value;
                                }
                                Object.defineProperty(input, 'label', {
                                    value: value,
                                    enumerable: true,
                                    configurable: true,
                                    writable: true,
                                });
                                return value;
                            },
                            enumerable: false,
                            configurable: true,
                        });
                    }
                    Object.defineProperty(input, '_lc_key', {
                        value: key,
                        enumerable: false,
                        writable: false,
                        configurable: true,
                    });
                    Object.defineProperty(input, '_lc_key_parent', {
                        value: `node.${nodeCategoryHandle}.${nodeHandle}.input`,
                        enumerable: false,
                        writable: false,
                        configurable: true,
                    });
                    Object.defineProperty(input, '_lc_processed', {
                        value: true,
                        enumerable: false,
                        writable: false,
                        configurable: true,
                    });
                }
            }

            if (thisArg.outputs) {
                for (const output of thisArg.outputs) {
                    const key = `node.${nodeCategoryHandle}.${nodeHandle}.output.${contentToKey(output.name)}.name`;
                    const fallback = output.name;
                    localizeKv[key] = fallback;
                    if (!output['label'] || output['label'] === fallback) {
                        Object.defineProperty(output, 'label', {
                            get() {
                                return tolgee.t(key, fallback, {
                                    noWrap: true
                                });
                            },
                            set(value) {
                                if (value === fallback || !value) {
                                    return value;
                                }
                                Object.defineProperty(output, 'label', {
                                    value: value,
                                    enumerable: true,
                                    configurable: true,
                                    writable: true,
                                });
                                return value;
                            },
                            enumerable: false,
                            configurable: true,
                        });
                    }
                    Object.defineProperty(output, '_lc_key', {
                        value: key,
                        enumerable: false,
                        writable: false,
                        configurable: true,
                    });
                    Object.defineProperty(output, '_lc_key_parent', {
                        value: `node.${nodeCategoryHandle}.${nodeHandle}.output`,
                        enumerable: false,
                        writable: false,
                        configurable: true,
                    });
                    Object.defineProperty(output, '_lc_processed', {
                        value: true,
                        enumerable: false,
                        writable: false,
                        configurable: true,
                    });
                }
            }

            if (thisArg.widgets) {
                for (const widget of thisArg.widgets) {
                    const key = `node.${nodeCategoryHandle}.${nodeHandle}.input.${contentToKey(widget.name)}.name`;
                    const fallback = widget.name;
                    localizeKv[key] = fallback;
                    if (!widget['label'] || widget['label'] === fallback) {
                        Object.defineProperty(widget, 'label', {
                            get() {
                                return tolgee.t(key, fallback, {
                                    noWrap: true
                                });
                            },
                            set(value) {
                                if (value === fallback || !value) {
                                    return value;
                                }
                                Object.defineProperty(widget, 'label', {
                                    value: value,
                                    enumerable: true,
                                    configurable: true,
                                    writable: true,
                                });
                                return value;
                            },
                            enumerable: false,
                            configurable: true,
                        });
                    }
                    Object.defineProperty(widget, '_lc_key', {
                        value: key,
                        enumerable: false,
                        writable: false,
                        configurable: true,
                    });
                    Object.defineProperty(widget, '_lc_key_parent', {
                        value: `node.${nodeCategoryHandle}.${nodeHandle}.input`,
                        enumerable: false,
                        writable: false,
                        configurable: true,
                    });
                    Object.defineProperty(widget, '_lc_processed', {
                        value: true,
                        enumerable: false,
                        writable: false,
                        configurable: true,
                    });
                }
            }

            return result;
        }
    });

    lgn.prototype.getTitle = new Proxy(lgn.prototype.getTitle, {
        apply(target, thisArg, argumentsList) {
            const node = thisArg.constructor;
            const nodeCategoryHandle = contentToKey(node.category);
            const nodeHandle = contentToKey(node.type);
            const key = `node.${nodeCategoryHandle}.${nodeHandle}.title`;
            if (thisArg.title === node.title) {
                localizeKv[key] = node.title;
                return tolgee.t(key, node.title, {noWrap: true});
            }
            return target.apply(thisArg, argumentsList);
        }
    })


    lgn.prototype.getPropertyInfo = new Proxy(lgn.prototype.getPropertyInfo, {
        apply(target, thisArg, argumentsList) {
            const [propertyName] = argumentsList;
            const result = target.apply(thisArg, argumentsList);

            const nodeCategoryHandle = contentToKey(thisArg.constructor.category);
            const nodeHandle = contentToKey(thisArg.constructor.type);
            const keyHandle = contentToKey(propertyName);
            const fallback = propertyName;

            Object.defineProperty(result, '_lc_key', {
                value: `node.${nodeCategoryHandle}.${nodeHandle}.properties.${keyHandle}`,
                enumerable: false,
                writable: false,
                configurable: true,
            })

            Object.defineProperty(result, '_lc_key_parent', {
                value: `node.${nodeCategoryHandle}.${nodeHandle}.properties`,
                enumerable: false,
                writable: false,
                configurable: true,
            })

            localizeKv[result['_lc_key']] = fallback;
            if (!result['label'] || result['label'] === fallback) {
                
                Object.defineProperty(result, 'label', {
                    get() {
                        return tolgee.t(result['_lc_key'], fallback, {
                            noWrap: true
                        });
                    },
                    set(value) {
                        if (value === fallback || !value) {
                            return value;
                        }
                        Object.defineProperty(result, 'label', {
                            value: value,
                            enumerable: true,
                            configurable: true,
                            writable: true,
                        });
                        return value;
                    },
                    enumerable: false,
                    configurable: true,
                });
            }

            return result;
        }
    });

    // context.canvas_menu.*
    lgc.prototype.getCanvasMenuOptions = new Proxy(lgc.prototype.getCanvasMenuOptions, {
        apply(target, thisArg, argumentsList) {
            const result = target.apply(thisArg, argumentsList);
            for (const item of result) {
                if (item == null) {
                    continue;
                }

                if (typeof item === 'string') {
                    continue;
                }

                if (optional(item, ['_lc_processed'])) {
                    continue;
                }

                const fallback = item['title'] || item['content'];
                item['_lc_key'] = `context.canvas_menu.${contentToKey(item['content'])}`;
                item['_lc_key_parent'] = `context.canvas_menu`;
                item['_lc_processed'] = true;
                localizeKv[item['_lc_key']] = fallback;
                item['title'] = tolgee.t(item['_lc_key'], fallback);
            }
            return result;
        }
    });

    lgc.prototype.getNodeMenuOptions = new Proxy(lgc.prototype.getNodeMenuOptions, {
        apply(target, thisArg, argumentsList) {
            const [node] = argumentsList;

            const newNode = {...node}
            const nodeCategoryHandle = contentToKey(node.constructor.category);
            const nodeHandle = contentToKey(node.constructor.type);

            const getExtraMenuOptions = node['getExtraMenuOptions'];

            if (getExtraMenuOptions) {
                node['getExtraMenuOptions'] = new Proxy(getExtraMenuOptions, {
                    apply(target, thisArg, argumentsList) {
                        const [lgcInstance, optionsExisting] = argumentsList

                        const optionsWrapper = new Proxy(optionsExisting, {
                            set: function (target, property, value, receiver) {
                                target[property] = value;
                                if (optional(value, 'content')) {
                                    if (value == null) {
                                        return true;
                                    }

                                    if (optional(value, ['_lc_processed'])) {
                                        return true;
                                    }

                                    if (typeof value === 'string') {
                                        const key = `context.node_menu.extra_menu.${contentToKey(value)}`;
                                        localizeKv[key] = value;
                                        target[property] = {
                                            content: value,
                                            _lc_processed: true,
                                            _lc_key: key,
                                            _lc_key_parent: `context.node_menu.extra_menu`,
                                            title: tolgee.t(key, value),
                                        }


                                        return true;
                                    }

                                    if (reConvertToInput.test(value['content'])) {
                                        const match = reConvertToInput.exec(value['content']);
                                        const converted_field_name = contentToKey(match[1])

                                        const fallback = 'Convert {slot} as input';
                                        value['_lc_key'] = `context.node_menu.widgetinputs.convert_to_input`;
                                        value['_lc_key_parent'] = `context.node_menu.widgetinputs`;
                                        value['_lc_processed'] = true;

                                        const fieldSlotKey = `node.${nodeCategoryHandle}.${nodeHandle}.input.${converted_field_name}.name`;
                                        localizeKv[fieldSlotKey] = match[1];
                                        const fieldSlot = tolgee.t(fieldSlotKey, match[1]);
                                        localizeKv[value['_lc_key']] = fallback;
                                        value['title'] = tolgee.t(value['_lc_key'], fallback, {
                                            slot: fieldSlot,
                                        });
                                        return true;
                                    }

                                    if (reConvertToWidget.test(value['content'])) {
                                        const match = reConvertToWidget.exec(value['content']);
                                        const converted_field_name = contentToKey(match[1])

                                        const fallback = 'Convert {slot} as widget';
                                        value['_lc_key'] = `context.node_menu.widgetinputs.convert_to_widget`;
                                        value['_lc_key_parent'] = `context.node_menu.widgetinputs`;
                                        value['_lc_processed'] = true;

                                        const fieldSlotKey = `node.${nodeCategoryHandle}.${nodeHandle}.input.${converted_field_name}.name`;
                                        localizeKv[fieldSlotKey] = match[1];
                                        const fieldSlot = tolgee.t(fieldSlotKey, match[1]);
                                        localizeKv[value['_lc_key']] = fallback;
                                        value['title'] = tolgee.t(value['_lc_key'], fallback, {
                                            slot: fieldSlot,
                                        });
                                        return true;
                                    }


                                    const fallback = value['title'] || value['content'];
                                    value['_lc_key'] = `context.node_menu.extra_menu.${contentToKey(value['content'])}`;
                                    value['_lc_key_parent'] = `context.node_menu.extra_menu`;
                                    value['_lc_processed'] = true;
                                    localizeKv[value['_lc_key']] = fallback;
                                    value['title'] = tolgee.t(value['_lc_key'], fallback);
                                }
                                return true;
                            }
                        });

                        const result = target.apply(thisArg, [lgcInstance, optionsWrapper, ...argumentsList.slice(2)]);
                        return result;
                    }
                });
            }

            try {
                const result = target.apply(thisArg, argumentsList);
                for (const [i, item] of result.entries()) {
                    if (item == null) {
                        continue;
                    }

                    if (typeof item === 'string') {
                        continue;
                        const key = `context.node_menu.common.${contentToKey(item)}`;
                        localizeKv[key] = item;
                        result[i] = {
                            content: item,
                            _lc_processed: true,
                            _lc_key: key,
                            _lc_key_parent: `context.node_menu.common`,
                            title: tolgee.t(key, item),
                        }
                    }

                    if (optional(item, ['_lc_processed'])) {
                        continue;
                    }

                    const fallback = item['title'] || item['content'];
                    item['_lc_key'] = `context.node_menu.common.${contentToKey(item['content'])}`;
                    item['_lc_key_parent'] = `context.node_menu.common`;
                    item['_lc_processed'] = true;
                    localizeKv[item['_lc_key']] = fallback;
                    item['title'] = tolgee.t(item['_lc_key'], fallback);
                }

                return result;
            } finally {
                if (getExtraMenuOptions) {
                    node['getExtraMenuOptions'] = getExtraMenuOptions;
                }
            }
        }
    });

    function handleContextMenu(menu, key) {
        for (const [i, item] of menu.entries()) {
            if (item == null) {
                // sep
                continue;
            }
            if (typeof item === 'string') {
                continue;
                // string
                localizeKv[`${key}.${contentToKey(item)}`] = item;
                menu[i] = {
                    content: item,
                    _lc_processed: true,
                    _lc_key: `${key}.${contentToKey(item)}`,
                    _lc_key_parent: key,
                    title: tolgee.t(`${key}.${contentToKey(item)}`, item),
                }
                continue;
            }
            // object
            if (!item['_lc_processed']) {
                const keyHandle = item['value'] || item['content'];
                if (!keyHandle) continue;
                const itemKey = `${key}.${contentToKey(keyHandle)}`;
                const fallback = item['title'] || item['content'];
                item['_lc_key'] = itemKey;
                item['_lc_key_parent'] = key;
                localizeKv[itemKey] = fallback;
                item['title'] = tolgee.t(itemKey, fallback);

                if (Array.isArray(optional(item, ['submenu', 'options']))) {
                    handleContextMenu(item['submenu']['options'], itemKey);
                }

                item['_lc_processed'] = true;
            }
        }
    }

    lg.ContextMenu = new Proxy(lg.ContextMenu, {
        apply(target, thisArg, argumentsList) {
            const [items, options] = argumentsList;
            let key = 'context._unstructured'
            let subkey = null

            if (optional(options, ['_lc_key'])) {
                key = options['_lc_key'];
            } else if (optional(options, ['event', 'target', 'value', '_lc_key'])) {
                key = options['event']['target']['value']['_lc_key'];
            } else if (optional(options, ['parentMenu', '_lc_key'])) {
                key = `${options['parentMenu']['_lc_key']}._unstructured`;
            } else if (Array.isArray(items) && items.find(item => optional(item, ['_lc_key_parent']))) {
                key = items.find(item => optional(item, ['_lc_key_parent']))['_lc_key_parent'];
            }

            if (optional(options, ['extra', 'type']) && optional(options, 'title')) {
                const nodeCategoryHandle = contentToKey(optional(options, ['extra', 'constructor', 'category']));
                const nodeHandle = contentToKey(optional(options, ['extra', 'constructor', 'type']));

                if (options['extra']['type'] === options['title']) {
                    subkey = `node.${nodeCategoryHandle}.${nodeHandle}.main_context`
                } else if ((Array.isArray(options['extra']['inputs']) &&
                        options['extra']['inputs'].some(n => n.type === optional(options, 'title'))) ||
                    (Array.isArray(options['extra']['outputs']) &&
                        options['extra']['outputs'].some(n => n.type === options['title']))) {
                    if (key === 'context._unstructured')
                        key = 'context.slot_menu'
                    const typeHandle = contentToKey(options['title'])
                    subkey = `node.${nodeCategoryHandle}.${nodeHandle}.slot_context.${typeHandle}`
                }
            }


            if (key === 'context.node_menu.common.properties') {
                const instance = target.apply(thisArg, argumentsList);

                Object.defineProperty(thisArg, '_lc_key', {
                    value: key,
                    writable: false,
                })

                Object.defineProperty(thisArg, '_lc_processed', {
                    value: true,
                    writable: false,
                })

                return instance;
            }

            if (options) {
                // menu title
                if (options['title'] && !options['_lc_processed_title']) {
                    options['_lc_processed_title'] = true;
                    const fallback = options['title'];
                    localizeKv[`${subkey || key}._title`] = fallback;
                    options['title'] = tolgee.t(`${subkey || key}._title`, fallback);
                }
            }

            if (Array.isArray(items)) {
                handleContextMenu(items, key);
            }

            const instance = target.apply(thisArg, argumentsList);

            Object.defineProperty(thisArg, '_lc_key', {
                value: key,
                writable: false,
            })

            Object.defineProperty(thisArg, '_lc_subkey', {
                value: key,
                writable: false,
            })

            Object.defineProperty(thisArg, '_lc_processed', {
                value: true,
                writable: false,
            })

            return instance;
        }
    });

    let elementTranslationQueue = []

    function handleElementTextContent(element, key) {
        localizeKv[key] = element.textContent;
        element.textContent = tolgee.t(key, element.textContent);
        element['_lc_processed'] = true;
        element['_lc_key'] = key;
    }

    function handleElementTitle(element, key) {
        localizeKv[key] = element.title;
        element.title = tolgee.t(key, element.title);
        element['_lc_processed_title'] = true;
        element['_lc_key_title'] = key;
        element['_lc_processed'] = true;
    }

    function queueHandleElementTextContent(element, key) {
        if (elementTranslationQueue == null) {
            handleElementTextContent(element, key);
        } else {
            elementTranslationQueue.push(() => handleElementTextContent(element, key));
        }
    }

    function queueHandleElementTitle(element, key) {
        if (elementTranslationQueue == null) {
            handleElementTitle(element, key);
        } else {
            elementTranslationQueue.push(() => handleElementTitle(element, key));
        }
    }

    window['_lc_hooks'] = {
        ui_el(element) {
            switch (optional(element, 'id')) {
                case 'queue-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.queue_button');
                    return;
                case 'autoQueueCheckbox':
                    queueHandleElementTitle(element, 'ui.sidebar.auto_queue.hint');
                    return;
                case 'queue-front-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.queue_front_button');
                    return;
                case 'comfy-view-queue-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.view_queue_button');
                    return;
                case 'comfy-view-history-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.view_history_button');
                    return;
                case 'comfy-save-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.save_button');
                    return;
                case 'comfy-dev-save-api-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.save_api_button');
                    return;
                case 'comfy-load-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.load_button');
                    return;
                case 'comfy-refresh-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.refresh_button');
                    return;
                case 'comfy-clipspace-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.clip_space_button');
                    return;
                case 'comfy-clear-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.clear_button');
                    return;
                case 'comfy-load-default-button':
                    queueHandleElementTextContent(element, 'ui.sidebar.load_default_button');
                    return;
            }

            if (element instanceof HTMLLabelElement) {
                switch (element.innerText.trim()) {
                    case 'Extra options':
                        queueHandleElementTextContent(element.childNodes[0], 'ui.sidebar.extra_options');
                        return;
                    case 'Batch count':
                        queueHandleElementTextContent(element, 'ui.sidebar.batch_count');
                        return;
                    case 'Auto Queue':
                        queueHandleElementTextContent(element, 'ui.sidebar.auto_queue');
                        return;
                }
                
                const labelFor = element.getAttribute('for');
                
                if (labelFor) {
                    queueHandleElementTextContent(element, `ui.label.${contentToKey(labelFor)}`);
                    return;
                }
            }

            return;
        },
    };

    window.addEventListener('DOMContentLoaded', async () => {
        await tolgee.run();
        let queue = elementTranslationQueue;
        elementTranslationQueue = null;
        for (const closure of queue) {
            closure();
        }
    });


    window.exportLocalization = function () {
        const jsonData = JSON.stringify(localizeKv, null, 2);
        const blob = new Blob([jsonData], {type: 'application/json'});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'localization.json';
        a.click();
    };
})()
