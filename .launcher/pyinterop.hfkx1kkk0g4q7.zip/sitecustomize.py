# noinspection PyBroadException
try:
    import swlutils.zipimport_hack
    import swlutils.stack_shadower
    import swlinitializer
except Exception:
    from swlutils.exception import capture_exception
    capture_exception()
    pass
