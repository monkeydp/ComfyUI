import swlvendors.sentry_sdk
from swlvendors.sentry_sdk.integrations import Integration
from swlvendors.sentry_sdk.scope import add_global_event_processor
from swlvendors.sentry_sdk.utils import _get_installed_modules

from swlvendors.sentry_sdk._types import TYPE_CHECKING

if TYPE_CHECKING:
    from typing import Any
    from swlvendors.sentry_sdk._types import Event


class ModulesIntegration(Integration):
    identifier = "modules"

    @staticmethod
    def setup_once():
        # type: () -> None
        @add_global_event_processor
        def processor(event, hint):
            # type: (Event, Any) -> Event
            if event.get("type") == "transaction":
                return event

            if swlvendors.sentry_sdk.get_client().get_integration(ModulesIntegration) is None:
                return event

            event["modules"] = _get_installed_modules()
            return event
